process.env.SUPABASE_URL ||= 'http://localhost:54321';
process.env.SUPABASE_SERVICE_ROLE_KEY ||= 'dummy-service';
process.env.SUPABASE_ANON_KEY ||= 'dummy-anon';

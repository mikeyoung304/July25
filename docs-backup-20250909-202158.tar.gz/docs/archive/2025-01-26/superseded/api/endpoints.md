# API Endpoints Reference

**Base URL**: `http://localhost:3001` (development) | `https://july25.onrender.com` (production)

## 🔐 Authentication

All API endpoints require:
- **Authorization Header**: `Bearer <supabase-jwt-token>`
- **Restaurant ID Header**: `X-Restaurant-ID: <restaurant-uuid>`

## 📊 Health & Monitoring

### Health Check
```http
GET /health
```
Returns basic server health status.

**Response**:
```json
{
  "status": "ok",
  "timestamp": "2025-07-13T10:00:00Z"
}
```

### Detailed Status
```http
GET /api/v1/status
```
Returns detailed system status including database connectivity.

**Response**:
```json
{
  "status": "healthy",
  "version": "1.0.0",
  "services": {
    "database": "connected",
    "ai": "ready",
    "websocket": "active"
  }
}
```

## 🍔 Menu Management

### Get Full Menu
```http
GET /api/v1/menu
```
Returns complete menu with categories and items.

**Response**:
```json
{
  "categories": [
    {
      "id": "123",
      "name": "Burgers",
      "items": [
        {
          "id": "456",
          "name": "Bacon Burger",
          "price": 12.00,
          "description": "Juicy burger with crispy bacon"
        }
      ]
    }
  ]
}
```

### Get All Menu Items
```http
GET /api/v1/menu/items
```
Returns flat list of all menu items.

### Get Single Menu Item
```http
GET /api/v1/menu/items/:id
```
Returns details for a specific menu item.

### Get Menu Categories
```http
GET /api/v1/menu/categories
```
Returns all menu categories.

### Sync Menu to AI
```http
POST /api/v1/menu/sync-ai
```
Uploads current menu to AI service for voice ordering.

## 📝 Order Management

### List Orders
```http
GET /api/v1/orders
```

**Query Parameters**:
- `status`: Filter by order status (pending, in_progress, ready, completed, cancelled)
- `date`: Filter by date (YYYY-MM-DD)
- `limit`: Number of results (default: 50)
- `offset`: Pagination offset

**Response**:
```json
{
  "orders": [
    {
      "id": "789",
      "order_number": "A001",
      "status": "pending",
      "total_amount": 25.50,
      "created_at": "2025-07-13T10:00:00Z",
      "items": [...]
    }
  ],
  "total": 100,
  "limit": 50,
  "offset": 0
}
```

### Create Order
```http
POST /api/v1/orders
```

**Request Body**:
```json
{
  "order_type": "dine_in",
  "table_id": "table-123",
  "items": [
    {
      "menu_item_id": "456",
      "quantity": 2,
      "modifiers": ["no pickles", "extra cheese"],
      "special_instructions": "Well done"
    }
  ]
}
```

### Get Single Order
```http
GET /api/v1/orders/:id
```
Returns complete order details including all items.

### Update Order Status
```http
PATCH /api/v1/orders/:id/status
```

**Request Body**:
```json
{
  "status": "in_progress"
}
```

**Valid Status Values**:
- `pending` - Just created, awaiting kitchen
- `in_progress` - Kitchen preparing
- `ready` - Ready for pickup/serve
- `completed` - Delivered/picked up
- `cancelled` - Order cancelled

### Process Voice Order
```http
POST /api/v1/orders/voice
```
Creates order from voice transcript.

**Request Body**:
```json
{
  "transcript": "I'll have two bacon burgers and a large coke",
  "order_type": "drive_thru"
}
```

## 🪑 Table Management

### List Tables
```http
GET /api/v1/tables
```
Returns all tables for the restaurant.

### Get Table
```http
GET /api/v1/tables/:id
```
Returns specific table details.

### Update Table
```http
PATCH /api/v1/tables/:id
```

**Request Body**:
```json
{
  "status": "occupied",
  "current_order_id": "order-123"
}
```

## 🏢 Floor Plan

> **Note**: Floor plan endpoints are documented but not yet implemented in the current version.

## 🤖 AI/Voice Services

**IMPORTANT**: All AI services are integrated directly in the backend using OpenAI APIs. The backend handles authentication, restaurant context, and rate limiting.

### Voice Chat (WebSocket)
```http
POST /api/v1/ai/voice-chat
```
Real-time voice conversation with AI assistant. Handles streaming audio.

### Test TTS
```http
POST /api/v1/ai/test-tts
```
Test text-to-speech conversion with sample text.

**Request Body**:
```json
{
  "text": "Welcome to our restaurant!"
}
```

### Transcribe Audio
```http
POST /api/v1/ai/transcribe
```
Converts audio to text via OpenAI's Whisper integration.

**Request**: Multipart form data with audio file
- **Headers**: `Authorization: Bearer <token>`, `X-Restaurant-ID: <uuid>`
- **Body**: Form data with `audio` field

**Processing**: Uses OpenAI Whisper API for transcription

**Response**:
```json
{
  "success": true,
  "text": "I'll have a bacon burger please",
  "transcript": "I'll have a bacon burger please",
  "duration": 2.5,
  "restaurantId": "11111111-1111-1111-1111-111111111111"
}
```

### Chat with AI Assistant
```http
POST /api/v1/ai/chat
```
Natural language chat with AI assistant via OpenAI.

**Request Body**:
```json
{
  "message": "What desserts do you have?"
}
```

**Processing**: Uses OpenAI GPT models with restaurant menu context

**Response**:
```json
{
  "success": true,
  "message": "We have chocolate cake, apple pie, and ice cream!",
  "restaurantId": "11111111-1111-1111-1111-111111111111"
}
```

### Parse Order from Text
```http
POST /api/v1/ai/parse-order
```
Extracts structured order from natural language via OpenAI.

**Request Body**:
```json
{
  "text": "Two burgers, one with no pickles, and a large fries"
}
```

**OpenAI Proxy**: Uses OpenAI's order parsing capabilities

**Response**:
```json
{
  "success": true,
  "items": [
    {
      "name": "Burger",
      "quantity": 2,
      "modifiers": ["no pickles (1)"]
    },
    {
      "name": "Fries",
      "quantity": 1,
      "size": "large"
    }
  ],
  "restaurantId": "11111111-1111-1111-1111-111111111111",
  "parsedBy": "user-123"
}
```

### Sync Menu to AI
```http
POST /api/v1/ai/menu
```
Syncs current menu from OpenAI (replaces upload functionality).

**Request Body**: Empty (uses restaurant context from headers)

**OpenAI Integration**: Fetches menu from OpenAI's `/api/menu` endpoint

**Response**:
```json
{
  "success": true,
  "message": "Menu synced from OpenAI successfully",
  "restaurantId": "11111111-1111-1111-1111-111111111111"
}
```

### Get Current AI Menu
```http
GET /api/v1/ai/menu
```
Returns currently loaded menu for AI processing.

**Response**:
```json
{
  "restaurantId": "11111111-1111-1111-1111-111111111111",
  "menu": [
    {
      "id": "item-1",
      "name": "Burger",
      "price": 9.00,
      "category": "Mains"
    }
  ]
}
```

### AI Health Check
```http
GET /api/v1/ai/health
```
Checks AI service health including OpenAI connectivity.

**Response**:
```json
{
  "status": "ok",
  "hasMenu": true,
  "menuItems": 25,
  "buildPanelStatus": "connected"
}
```

## 🔄 WebSocket Events

**Connection URL**: `ws://localhost:3001` (development)

### Client → Server Events

#### Join Restaurant
```json
{
  "type": "join-restaurant",
  "restaurantId": "11111111-1111-1111-1111-111111111111"
}
```

#### Voice Stream Start
```json
{
  "type": "voice-start",
  "mode": "kiosk"
}
```

#### Voice Audio Data
Binary audio data chunks sent during recording.

### Server → Client Events

#### Order Updated
```json
{
  "type": "order-updated",
  "order": {
    "id": "123",
    "status": "ready",
    "order_number": "A001"
  }
}
```

#### New Order
```json
{
  "type": "new-order",
  "order": {
    "id": "456",
    "order_number": "A002",
    "items": [...]
  }
}
```

#### Voice Response
```json
{
  "type": "voice-response",
  "transcript": "I'll have a burger",
  "response": "Great! I've added a burger to your order.",
  "items": [
    {
      "name": "Burger",
      "price": 9.00,
      "quantity": 1
    }
  ],
  "restaurantId": "11111111-1111-1111-1111-111111111111"
}
```

## 🔧 CURL Examples

### AI Endpoints

#### Chat with AI Assistant
```bash
curl -X POST http://localhost:3001/api/v1/ai/chat \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-jwt-token>" \
  -H "X-Restaurant-ID: 11111111-1111-1111-1111-111111111111" \
  -d '{
    "message": "What are your most popular burgers?"
  }'
```

#### Transcribe Audio File
```bash
curl -X POST http://localhost:3001/api/v1/ai/transcribe \
  -H "Authorization: Bearer <your-jwt-token>" \
  -H "X-Restaurant-ID: 11111111-1111-1111-1111-111111111111" \
  -F "audio=@recording.webm"
```

#### Parse Order from Text
```bash
curl -X POST http://localhost:3001/api/v1/ai/parse-order \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-jwt-token>" \
  -H "X-Restaurant-ID: 11111111-1111-1111-1111-111111111111" \
  -d '{
    "text": "I would like two cheeseburgers, one without pickles, and a large fries"
  }'
```

#### Sync Menu from OpenAI
```bash
curl -X POST http://localhost:3001/api/v1/ai/menu \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-jwt-token>" \
  -H "X-Restaurant-ID: 11111111-1111-1111-1111-111111111111"
```

### Order Management

#### Create Voice Order
```bash
curl -X POST http://localhost:3001/api/v1/orders/voice \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-jwt-token>" \
  -H "X-Restaurant-ID: 11111111-1111-1111-1111-111111111111" \
  -d '{
    "transcript": "Two bacon burgers and a large coke",
    "order_type": "drive_thru"
  }'
```

#### Update Order Status
```bash
curl -X PATCH http://localhost:3001/api/v1/orders/order-123/status \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <your-jwt-token>" \
  -H "X-Restaurant-ID: 11111111-1111-1111-1111-111111111111" \
  -d '{
    "status": "ready"
  }'
```

### Health Checks

#### System Health
```bash
curl http://localhost:3001/health
```

#### AI Service Health
```bash
curl -H "Authorization: Bearer <your-jwt-token>" \
     http://localhost:3001/api/v1/ai/health
```

## 💳 Payment Processing

### Create Payment Intent
```http
POST /api/v1/payments/create-intent
```
Creates a payment intent for Square payment processing.

**Request Body**:
```json
{
  "amount": 2500,
  "currency": "USD",
  "orderId": "order-123"
}
```

### Process Payment
```http
POST /api/v1/payments/process
```
Processes payment with tokenized card details.

### Get Payment Status
```http
GET /api/v1/payments/:paymentId/status
```
Returns current payment status.

### Refund Payment
```http
POST /api/v1/payments/:paymentId/refund
```
Initiates a refund for a processed payment.

**Request Body**:
```json
{
  "amount": 1000,
  "reason": "Customer request"
}
```

## 🏢 Restaurant Management

### Get Restaurant Details
```http
GET /api/v1/restaurant
```
Returns current restaurant details including settings and configuration.

### Update Restaurant Settings
```http
PATCH /api/v1/restaurant/settings
```
Updates restaurant configuration.

**Request Body**:
```json
{
  "name": "Restaurant Name",
  "timezone": "America/New_York",
  "operating_hours": {
    "monday": { "open": "09:00", "close": "22:00" }
  }
}
```

### Get Restaurant Staff
```http
GET /api/v1/restaurant/staff
```
Returns list of staff members with roles.

## 📊 Analytics (Coming Soon)

### Order Analytics
```http
GET /api/v1/analytics/orders
```

### Revenue Reports
```http
GET /api/v1/analytics/revenue
```

### Popular Items
```http
GET /api/v1/analytics/popular-items
```

## 🔒 Error Responses

All errors follow this format:

```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid order data",
    "details": {
      "field": "items",
      "issue": "Items array cannot be empty"
    }
  }
}
```

**Common Error Codes**:
- `UNAUTHORIZED` - Missing or invalid auth token
- `FORBIDDEN` - No access to resource
- `NOT_FOUND` - Resource doesn't exist
- `VALIDATION_ERROR` - Invalid request data
- `OPENAI_ERROR` - OpenAI service unavailable or error
- `INTERNAL_ERROR` - Server error

**OpenAI-Specific Errors**:
```json
{
  "error": "OpenAI chat failed: Connection timeout",
  "message": "Service temporarily unavailable"
}
```

## 📈 Rate Limits

**Production Limits**:
- **General API**: 1000 requests per 15 minutes
- **AI Service**: 50 requests per 5 minutes
- **Voice Transcription**: 20 requests per minute
- **Voice Orders**: 100 requests per minute
- **Authentication**: 5 attempts per 15 minutes
- **Health Checks**: 30 requests per minute
- **WebSocket**: 1 connection per client

**Note**: Rate limiting is disabled in local development but enforced on production deployments.

## 🔧 Environment Variables

**OpenAI Integration**:
- `OPENAI_URL` - OpenAI service URL (default: http://localhost:3003)

**Core Services**:
- `DATABASE_URL` - PostgreSQL connection string
- `PORT` - Server port (default: 3001)
- `FRONTEND_URL` - Frontend URL for CORS
- `NODE_ENV` - Environment (development/production)

**Authentication**:
- `JWT_SECRET` - JWT signing secret
- `ALLOWED_ORIGINS` - Comma-separated allowed CORS origins

---

**Note**: All endpoints return JSON with `Content-Type: application/json` unless otherwise specified.
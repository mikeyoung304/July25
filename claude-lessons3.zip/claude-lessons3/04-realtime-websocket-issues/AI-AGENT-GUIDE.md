---
category: "realtime-websocket"
category_id: "04"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, memory-leaks, race-conditions, event-handlers, connection-pooling]
---
# AI Agent Guide - Real-Time Systems

**Audience:** AI agents (Claude, GPT-4, etc.) working on real-time WebSocket/WebRTC code
**Purpose:** Prevent repeating the 70+ hours of debugging that led to these lessons

---

## Priority Checklist: Check These FIRST

When working on real-time code (WebSocket, WebRTC, voice, state machines), **CHECK THESE BEFORE WRITING ANY CODE:**

### 1. Does Every Timer Have a Cleanup Method?

**BEFORE writing code, search for:**
```bash
rg "setInterval\(" --type ts
rg "setTimeout\(" --type ts
```

**FOR EACH MATCH, verify:**
- [ ] Timer reference is stored in a variable/property
- [ ] There's a cleanup method that calls `clearInterval` or `clearTimeout`
- [ ] Cleanup is called in shutdown/unmount/disconnect

**RED FLAGS:**
```typescript
❌ setInterval(() => { ... }, 60000); // No reference stored
❌ this.timer = setInterval(...);  // No clearInterval anywhere
❌ constructor() { setInterval(...); } // No shutdown method
```

**CORRECT:**
```typescript
✅ private timer: NodeJS.Timeout | null = null;
✅ this.timer = setInterval(...);
✅ shutdown() { if (this.timer) clearInterval(this.timer); }
```

---

### 2. Are Event Handlers Attached BEFORE Async Operations?

**BEFORE implementing WebRTC/WebSocket, check the sequence:**

```typescript
// ❌ WRONG ORDER
this.channel = createChannel();
await doSomethingAsync();  // Channel might open during this
this.channel.onmessage = handler;  // TOO LATE

// ✅ CORRECT ORDER
this.channel = createChannel();
this.channel.onmessage = handler;  // ATTACH FIRST
await doSomethingAsync();
```

**THE RULE:** Handler attachment MUST be synchronous, BEFORE any await/async.

---

### 3. Are Connection Attempts Guarded Against Races?

**BEFORE implementing connect() method, add guards:**

```typescript
class ConnectionService {
  private isConnecting = false;  // ✅ Guard flag
  private connectionPromise: Promise<void> | null = null;  // ✅ Promise tracking

  async connect(): Promise<void> {
    // ✅ Guard: Already connecting
    if (this.isConnecting && this.connectionPromise) {
      return this.connectionPromise;
    }

    // ✅ Guard: Already connected
    if (this.isConnected()) {
      return;
    }

    this.isConnecting = true;
    // ... connection logic ...
  }
}
```

**THE RULE:** Every async connection method needs `isConnecting` flag + promise tracking.

---

### 4. Do State Machines Have Timeouts?

**BEFORE implementing state machine, identify waiting states:**

```typescript
type State =
  | 'idle'           // ✅ Not waiting, no timeout needed
  | 'processing'     // ✅ Active work, no timeout needed
  | 'waiting_response'  // ❌ WAITING - NEEDS TIMEOUT
  | 'waiting_confirmation'  // ❌ WAITING - NEEDS TIMEOUT
```

**FOR EACH WAITING STATE, verify:**
- [ ] Timeout is set when entering state
- [ ] Timeout is cleared when leaving state
- [ ] Timeout duration is generous (10s+, not 1s)
- [ ] Timeout handler resets to safe state

**THE RULE:** Any state that waits for external events needs a timeout.

---

### 5. Is There a Graceful Shutdown Path?

**BEFORE finalizing any module, verify:**
- [ ] All timers cleared
- [ ] All event listeners removed
- [ ] All connections closed
- [ ] Shutdown integrated with server shutdown (if server-side)
- [ ] Shutdown integrated with component unmount (if client-side)

**THE RULE:** If you create it, you must clean it up.

---

## Anti-Pattern Detection: Fast Scanners

### Scan 1: Timer Leaks
```bash
# Find potential timer leaks
rg "setInterval\(" -A 5 -B 5 --type ts | rg -v "clearInterval"

# Any matches are SUSPICIOUS - investigate further
```

### Scan 2: Event Handler Timing
```bash
# Find potential race conditions
rg "createDataChannel|new WebSocket" -A 10 --type ts | rg "onmessage|onopen"

# Verify onmessage comes BEFORE onopen in code
```

### Scan 3: Unguarded Connections
```bash
# Find potentially unguarded connect methods
rg "async connect\(\)" -A 3 --type ts | rg -v "if.*isConnecting"

# Any matches are SUSPICIOUS - need guard flags
```

### Scan 4: State Machines Without Timeouts
```bash
# Find state machines
rg "type.*State.*=|interface.*State" -A 10 --type ts | rg "waiting|pending"

# For each "waiting" state, verify setTimeout exists in same file
```

---

## Code Review Protocol for AI Agents

When reviewing or writing real-time code, follow this protocol:

### Phase 1: Static Analysis (2 minutes)
1. Run all 4 scans above
2. Note all suspicious matches
3. For each match, determine: Safe or Needs Fix

### Phase 2: Pattern Verification (3 minutes)
For each real-time component, verify:

**Timers:**
- [ ] Reference stored
- [ ] Cleanup method exists
- [ ] Called in shutdown

**Handlers:**
- [ ] Attached before async
- [ ] Defensive fallbacks present
- [ ] Comprehensive logging

**Connections:**
- [ ] Guard flags present
- [ ] Promise tracking present
- [ ] Cleanup before reconnect

**State Machines:**
- [ ] Timeouts for waiting states
- [ ] Cleanup on transitions
- [ ] Emergency reset method

### Phase 3: Test Plan (5 minutes)
For each component, write or verify tests for:

**Timers:**
```typescript
test('cleanup clears timer', () => {
  const service = new Service();
  service.shutdown();
  expect(service['timer']).toBeNull();
});
```

**Handlers:**
```typescript
test('receives messages immediately after open', () => {
  // Simulate 0ms delay between open and message
  // Verify message received
});
```

**Connections:**
```typescript
test('concurrent connects await same promise', async () => {
  const [p1, p2, p3] = [service.connect(), service.connect(), service.connect()];
  await Promise.all([p1, p2, p3]);
  expect(connectSpy).toHaveBeenCalledTimes(1);
});
```

**State Machines:**
```typescript
test('timeout resets state after 10s', () => {
  jest.useFakeTimers();
  machine.transitionToWaiting();
  jest.advanceTimersByTime(10000);
  expect(machine.state).toBe('idle');
});
```

---

## Common Mistakes AI Agents Make

### Mistake 1: "It looks fine to me"
**Symptom:** Code review doesn't catch subtle timing issues
**Why:** AI agents read code linearly, miss async timing races
**Fix:** Always check handler attachment vs. async operation order

### Mistake 2: "Adding a setTimeout will fix it"
**Symptom:** Suggesting arbitrary delays as "fixes"
**Why:** Delays don't fix races, just make them less frequent
**Fix:** Use proper synchronization (guards, promises, handlers-before-async)

### Mistake 3: "This cleanup isn't critical"
**Symptom:** Skipping cleanup methods for "small" timers
**Why:** All leaks accumulate over time, no matter how small
**Fix:** EVERY timer needs cleanup, no exceptions

### Mistake 4: "The user will restart the server"
**Symptom:** Dismissing memory leaks as "not production issues"
**Why:** Users expect stable services, restarts cost money/time
**Fix:** Design for 30+ day uptime from day one

### Mistake 5: "Let's refactor this into separate files"
**Symptom:** Splitting monolithic code without considering timing
**Why:** Refactoring can introduce races (see voice transcription incident)
**Fix:** When splitting event-driven code, verify handler timing after refactor

---

## Decision Trees for AI Agents

### Should I add a setTimeout?
```
Is this to fix a race condition?
├─ YES: ❌ NO! Fix the race, don't hide it
└─ NO: Is this a timeout guard for waiting state?
   ├─ YES: ✅ OK, but make it generous (10s+)
   └─ NO: Is this for UI debouncing?
      ├─ YES: ✅ OK, document why
      └─ NO: ❌ Probably not needed
```

### Should I add an interval?
```
Is there a better way (events, webhooks, push)?
├─ YES: ❌ Use that instead
└─ NO: Am I prepared to implement cleanup?
   ├─ YES: ✅ OK, write cleanup FIRST
   └─ NO: ❌ Don't add interval yet
```

### Should I split this into separate files?
```
Is this event-driven code (WebSocket, WebRTC)?
├─ YES: Will handler attachment timing change?
│  ├─ YES: ❌ Risky, test thoroughly
│  └─ NO: ✅ Safe to split
└─ NO: ✅ Safe to split
```

### Should I add a guard flag?
```
Is this a method that can be called multiple times?
├─ NO: ❌ Not needed
└─ YES: Does it do async I/O (network, file)?
   ├─ NO: Maybe not needed (check if idempotent)
   └─ YES: Is it a connection or state change?
      ├─ YES: ✅ REQUIRED
      └─ NO: ✅ Probably needed
```

---

## Testing Guidance for AI Agents

### What to Test First (Priority Order)

1. **Timer Cleanup** (catches 40% of bugs)
```typescript
test('cleanup clears all timers', () => {
  const clearIntervalSpy = jest.spyOn(global, 'clearInterval');
  const service = new Service();
  service.shutdown();
  expect(clearIntervalSpy).toHaveBeenCalled();
});
```

2. **Concurrent Connection Attempts** (catches 25% of bugs)
```typescript
test('concurrent connects are guarded', async () => {
  const [p1, p2, p3] = [service.connect(), service.connect(), service.connect()];
  await Promise.all([p1, p2, p3]);
  expect(actualConnections).toBe(1);
});
```

3. **State Machine Timeouts** (catches 15% of bugs)
```typescript
test('timeout resets stuck state', () => {
  jest.useFakeTimers();
  machine.enterWaitingState();
  jest.advanceTimersByTime(10000);
  expect(machine.state).toBe('idle');
});
```

4. **Handler Timing** (catches 10% of bugs)
```typescript
test('handler receives immediate messages', () => {
  const messages: string[] = [];
  connection.on('message', (msg) => messages.push(msg));
  connection.connect();
  // Simulate immediate message (0ms delay)
  simulateMessage('test');
  expect(messages).toContain('test');
});
```

5. **Memory Leaks** (catches 10% of bugs)
```typescript
test('repeated start/stop does not leak', () => {
  for (let i = 0; i < 100; i++) {
    service.start();
    service.stop();
  }
  expect(process._getActiveHandles().length).toBeLessThan(5);
});
```

### Test Templates for Copy-Paste

```typescript
// Timer cleanup test template
describe('Timer Cleanup', () => {
  test('clears interval on shutdown', () => {
    const service = new Service();
    expect(service['timer']).not.toBeNull();
    service.shutdown();
    expect(service['timer']).toBeNull();
  });

  test('prevents duplicate intervals', () => {
    const service = new Service();
    service.start();
    service.start(); // Second call
    expect(service['timer']).not.toBeNull();
    // Should only have ONE timer
  });
});

// Connection guard test template
describe('Connection Guards', () => {
  test('concurrent connects await same promise', async () => {
    const connectSpy = jest.spyOn(service as any, 'doConnect');
    await Promise.all([
      service.connect(),
      service.connect(),
      service.connect()
    ]);
    expect(connectSpy).toHaveBeenCalledTimes(1);
  });

  test('connect while reconnecting is skipped', async () => {
    service['isReconnecting'] = true;
    await service.connect();
    expect(service['isConnected']).toBe(false);
  });
});

// State timeout test template
describe('State Timeouts', () => {
  beforeEach(() => {
    jest.useFakeTimers();
  });

  afterEach(() => {
    jest.useRealTimers();
  });

  test('timeout resets state after duration', () => {
    machine.enterWaitingState();
    expect(machine.state).toBe('waiting');

    jest.advanceTimersByTime(10000);
    expect(machine.state).toBe('idle');
  });

  test('successful transition clears timeout', () => {
    const clearTimeoutSpy = jest.spyOn(global, 'clearTimeout');
    machine.enterWaitingState();
    machine.successfulTransition();
    expect(clearTimeoutSpy).toHaveBeenCalled();
  });
});
```

---

## Dangerous Patterns to NEVER Suggest

### ❌ NEVER: Arbitrary Delays as "Fixes"
```typescript
// ❌ BAD - AI agents often suggest this
setTimeout(() => {
  this.channel.onmessage = handler;
}, 100); // "Give it time to open"

// ✅ GOOD - Fix the race
this.channel.onmessage = handler;  // Attach BEFORE open
```

### ❌ NEVER: Unbounded Caches
```typescript
// ❌ BAD
const cache = {};
function addToCache(key, value) {
  cache[key] = value; // Grows forever
}

// ✅ GOOD
const cache = new Map();
const MAX_SIZE = 1000;
function addToCache(key, value) {
  if (cache.size >= MAX_SIZE) {
    const firstKey = cache.keys().next().value;
    cache.delete(firstKey);
  }
  cache.set(key, value);
}
```

### ❌ NEVER: Swallowing Errors in Cleanup
```typescript
// ❌ BAD
async shutdown() {
  try {
    await this.cleanup();
  } catch (e) {
    // Silent failure
  }
}

// ✅ GOOD
async shutdown() {
  try {
    await this.cleanup();
  } catch (e) {
    logger.error('Cleanup failed (continuing):', e);
    // Continue shutdown anyway
  }
}
```

### ❌ NEVER: Polling When Events Available
```typescript
// ❌ BAD - AI agents sometimes suggest polling
setInterval(() => {
  const state = await checkState();
  if (state.ready) { /* ... */ }
}, 1000);

// ✅ GOOD - Use events
socket.on('state.change', (state) => {
  if (state.ready) { /* ... */ }
});
```

---

## Communication Protocol: How to Report Issues to Humans

When you (AI agent) discover a real-time bug, report it like this:

### Bug Report Template
```markdown
## Real-Time Bug Detected

**Type:** [Timer Leak | Race Condition | Missing Timeout | Unguarded Connection]

**Location:** `path/to/file.ts:123`

**Issue:**
[Describe the specific problem in 1-2 sentences]

**Impact:**
[Memory leak | Connection failure | Stuck state | Duplicate operations]

**Evidence:**
```typescript
// Show the problematic code
```

**Fix:**
```typescript
// Show the corrected code
```

**Test:**
```typescript
// Show how to test the fix
```

**Confidence:** [High | Medium | Low]
**Estimated Fix Time:** [5 min | 30 min | 2 hours]
```

### Example Bug Report
```markdown
## Real-Time Bug Detected

**Type:** Timer Leak

**Location:** `server/src/voice/websocket-server.ts:32`

**Issue:**
setInterval created in constructor without storing reference or cleanup method.

**Impact:**
Memory leak of ~1 MB/day, prevents clean shutdown.

**Evidence:**
```typescript
constructor() {
  setInterval(() => this.cleanupInactiveSessions(), 60000); // ❌ No reference
}
```

**Fix:**
```typescript
private cleanupInterval: NodeJS.Timeout | null = null;

constructor() {
  this.cleanupInterval = setInterval(() => this.cleanupInactiveSessions(), 60000);
}

public shutdown(): void {
  if (this.cleanupInterval) {
    clearInterval(this.cleanupInterval);
    this.cleanupInterval = null;
  }
}
```

**Test:**
```typescript
test('cleanup clears interval', () => {
  const server = new VoiceWebSocketServer();
  server.shutdown();
  expect(server['cleanupInterval']).toBeNull();
});
```

**Confidence:** High
**Estimated Fix Time:** 5 minutes
```

---

## Memory Monitoring: Commands to Suggest

When investigating memory issues, suggest these commands:

### For Server-Side (Node.js)
```bash
# Check current memory usage
node -e "const used = process.memoryUsage(); console.log('Heap Used:', Math.round(used.heapUsed / 1024 / 1024), 'MB')"

# Check active handles (should be low)
node -e "console.log('Active handles:', process._getActiveHandles().length)"

# Check active timers
node -e "const handles = process._getActiveHandles(); const timers = handles.filter(h => h.constructor.name === 'Timeout'); console.log('Active timers:', timers.length)"

# Monitor memory growth over time
watch -n 10 'ps aux | grep node | grep -v grep | awk "{print \$6/1024\" MB\"}"'
```

### For Client-Side (Browser)
```javascript
// Check memory usage
performance.memory.usedJSHeapSize / 1024 / 1024 + ' MB'

// Take heap snapshot
// Chrome DevTools → Memory → Take Snapshot

// Check event listeners
getEventListeners(window)

// Check for detached DOM nodes
// Chrome DevTools → Memory → Take Snapshot → Search for "Detached"
```

---

## Final Checklist: Before Submitting Code

AI agents, before you mark a real-time implementation as "complete", verify:

- [ ] I ran all 4 anti-pattern scans
- [ ] I verified timer cleanup exists and is tested
- [ ] I verified handler timing is correct
- [ ] I verified connection guards exist
- [ ] I verified state timeouts exist (if applicable)
- [ ] I verified graceful shutdown integration
- [ ] I wrote tests for all of the above
- [ ] I checked the git history for similar past bugs
- [ ] I read the incident reports for this codebase
- [ ] I would bet $100 this won't cause a production incident

If you can't check all boxes, **ASK THE HUMAN** before proceeding.

---

## Resources for Learning

### Read These First (30 minutes)
1. `/Users/mikeyoung/CODING/rebuild-6.0/claude-lessons3/04-realtime-websocket-issues/README.md` - Executive summary
2. `/Users/mikeyoung/CODING/rebuild-6.0/claude-lessons3/04-realtime-websocket-issues/PATTERNS.md` - Correct patterns
3. `/Users/mikeyoung/CODING/rebuild-6.0/claude-lessons3/04-realtime-websocket-issues/QUICK-REFERENCE.md` - Fast lookup

### Read When Debugging (60 minutes)
1. `/Users/mikeyoung/CODING/rebuild-6.0/claude-lessons3/04-realtime-websocket-issues/INCIDENTS.md` - Deep-dive incident analysis
2. `/Users/mikeyoung/CODING/rebuild-6.0/docs/investigations/P0_MEMORY_LEAK_ANALYSIS.md` - Technical analysis
3. `/Users/mikeyoung/CODING/rebuild-6.0/claudelessons-v2/knowledge/incidents/CL-VOICE-*.md` - Specific incidents

### Reference While Coding (5 seconds)
1. Keep QUICK-REFERENCE.md open in separate window
2. Use PREVENTION.md code examples as templates
3. Copy test templates from AI-AGENT-GUIDE.md (this file)

---

**Remember:** These patterns were learned from 70+ hours of debugging and $20,000+ in engineering costs. Don't repeat those mistakes.

**When in doubt:** Ask a human. Better to ask than to cause a production incident.

---

**Last Updated:** 2025-11-19
**Audience:** AI Agents (Claude, GPT-4, etc.)
**Next Review:** 2026-02-19

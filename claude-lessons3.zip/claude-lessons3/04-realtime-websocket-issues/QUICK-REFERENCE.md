---
category: "realtime-websocket"
category_id: "04"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, memory-leaks, race-conditions, event-handlers, connection-pooling]
---
# Real-Time Quick Reference Card

**Context:** Fast lookup for real-time debugging and implementation patterns.

---

## WebSocket State Values

### Standard WebSocket ReadyState
```javascript
WebSocket.CONNECTING  // 0 - Connection not yet open
WebSocket.OPEN       // 1 - Connection open, ready to communicate
WebSocket.CLOSING    // 2 - Connection closing
WebSocket.CLOSED     // 3 - Connection closed

// Check state
if (ws.readyState === WebSocket.OPEN) {
  ws.send(data);
}
```

### Custom Connection State (Our Pattern)
```typescript
type ConnectionState = 'connecting' | 'connected' | 'disconnected' | 'error';

// Don't confuse with WebSocket readyState!
// This is our application-level state tracking
```

### Voice Turn State Machine
```typescript
type TurnState =
  | 'idle'              // Ready to record
  | 'recording'         // Mic active, capturing audio
  | 'committing'        // Sending audio to OpenAI
  | 'waiting_user_final' // Waiting for transcript
  | 'waiting_response';  // Waiting for AI response
```

---

## Common Race Condition Symptoms

### Symptom: "Cannot start recording in state: waiting_user_final"
**Cause:** State machine stuck, timeout didn't fire
**Check:**
```bash
# Look for:
logger.warn('Timeout waiting for transcript, resetting to idle')

# If not found, state machine has no timeout
```
**Fix:** Add 10-second timeout when entering waiting state

---

### Symptom: Infinite loading spinner in KDS
**Cause:** Duplicate WebSocket connection attempts
**Check:**
```javascript
// Add debug counter
if (import.meta.env.DEV) {
  window.__dbgWS = window.__dbgWS || { connectCount: 0 };
  window.__dbgWS.connectCount++;
  console.log(`WebSocket connect #${window.__dbgWS.connectCount}`);
}

// If connectCount > 1, you have a race condition
```
**Fix:** Add `isConnecting` guard flag

---

### Symptom: Voice transcription never appears
**Cause:** DataChannel `onmessage` handler attached too late
**Check:**
```bash
# Look for these events in console:
🔔 session.created
🔔 conversation.item.created

# If missing, events were lost before handler attached
```
**Fix:** Attach `onmessage` handler BEFORE channel opens

---

### Symptom: Memory usage slowly growing
**Cause:** Timer/interval never cleared
**Check:**
```bash
# Node.js
node -e "console.log(process._getActiveHandles().length)"
# Should be low (< 20), high number (> 50) indicates leaks

# Check for intervals specifically
node -e "console.log(process._getActiveHandles().filter(h => h.constructor.name === 'Timeout').length)"
```
**Fix:** Store interval reference, clear in shutdown

---

### Symptom: Process doesn't exit after SIGTERM
**Cause:** Active timers/listeners preventing exit
**Check:**
```bash
# Send SIGTERM
kill -TERM <pid>

# Wait 5 seconds
# If still running:
kill -9 <pid>  # Force kill

# Check logs for which cleanup failed
```
**Fix:** Integrate all cleanups with graceful shutdown

---

## Memory Leak Indicators

### Heap Growth Check
```bash
# Monitor memory usage
watch -n 5 'ps aux | grep node | grep -v grep | awk "{print \$6/1024\" MB\"}"'

# Acceptable: <5 MB growth per hour
# Warning: >10 MB growth per hour
# Critical: >50 MB growth per hour
```

### Active Handles Check
```javascript
// Add to server monitoring
setInterval(() => {
  const handles = process._getActiveHandles();
  console.log('Active handles:', handles.length);

  // Log handle types
  const types = handles.reduce((acc, h) => {
    const type = h.constructor.name;
    acc[type] = (acc[type] || 0) + 1;
    return acc;
  }, {});
  console.log('Handle types:', types);
}, 60000); // Every minute
```

### Expected Handle Counts
```
Normal operation:
- Server: 1
- Socket: 5-20 (depends on active connections)
- Timeout: 3-10 (heartbeats, scheduled tasks)
- FSWatcher: 0-5 (file watching in dev mode)

Warning signs:
- Timeout > 20 (potential interval leaks)
- Socket > 50 (potential connection leaks)
- Any number continuously growing
```

---

## Voice Ordering Debug Commands

### Check Voice Connection Status
```javascript
// In browser console
window.__voiceClient?.getStatus()
// Expected output:
{
  connectionState: 'connected',
  turnState: 'idle',
  transcriptMapSize: 0,
  hasDataChannel: true,
  dataChannelReady: true
}
```

### Force Reset Stuck State
```javascript
// Emergency escape hatch
window.__voiceClient?.forceReset()
// Should reset turnState to 'idle'
```

### Check Transcript Map
```javascript
// See if transcripts are being tracked
window.__voiceClient?._eventHandler?._transcriptMap.size
// Should increase during recording, decrease after completion
```

### Enable Debug Logging
```javascript
// Turn on verbose logging
window.__voiceClient?._config.debug = true;
// Now you'll see all events:
// 🔔 [VoiceEventHandler] session.created
// 🔔 [VoiceEventHandler] conversation.item.created
// 🔔 [VoiceEventHandler] transcript.delta
```

---

## WebSocket Debug Commands

### Check WebSocket Connection
```javascript
// In browser console
window.__wsService?.getStatus()
// Expected output:
{
  state: 'connected',
  reconnectAttempts: 0,
  isReconnecting: false,
  lastHeartbeat: 1700000000000
}
```

### Force Reconnect
```javascript
// Close and reconnect
window.__wsService?.disconnect()
window.__wsService?.connect()
```

### Check Subscription Count
```javascript
// See active subscriptions
window.__wsService?.getSubscriptions()
// Should show:
['order.created', 'order.updated', 'order.status.changed']
```

---

## Common Timing Windows

### Critical Timing Measurements
```
WebRTC DataChannel:
- Channel open → first event: 50-100ms
- Event arrival rate: 10-20 events in first 200ms
- Handler attachment delay (if wrong): 100-150ms
- SUCCESS REQUIREMENT: Handler BEFORE channel opens

KDS Initialization:
- Component mount → first render: 50ms
- loadOrders trigger → re-render: 20-50ms
- Connection establishment: 100-300ms
- RACE WINDOW: 150-350ms (if not guarded)

State Machine Timeouts:
- Normal transcript arrival: 500-1500ms
- Timeout threshold: 10,000ms (10 seconds)
- Margin of safety: 8.5+ seconds

Memory Cleanup:
- SIGTERM received → shutdown starts: 0ms
- HTTP server close: 50-100ms
- WebSocket cleanup: 100-3000ms
- Database disconnect: 50-2000ms
- TOTAL SHUTDOWN TIME: <10 seconds (or force exit)
```

---

## State Guard Pattern Checklist

```typescript
// ✅ Minimal viable guard pattern
class MyService {
  private isConnecting = false;
  private connectionPromise: Promise<void> | null = null;

  async connect(): Promise<void> {
    // Guard 1: Already connecting
    if (this.isConnecting && this.connectionPromise) {
      return this.connectionPromise;
    }

    // Guard 2: Already connected
    if (this.isConnected()) {
      return;
    }

    this.isConnecting = true;
    this.connectionPromise = (async () => {
      try {
        await this.doConnect();
      } finally {
        this.isConnecting = false;
        this.connectionPromise = null;
      }
    })();

    return this.connectionPromise;
  }
}
```

---

## Timer Cleanup Pattern Checklist

```typescript
// ✅ Minimal viable timer pattern
class MyService {
  private timer: NodeJS.Timeout | null = null;

  start(): void {
    // Guard: Prevent duplicate timers
    if (this.timer) return;

    this.timer = setInterval(() => {
      this.doWork();
    }, 60000);
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
}

// REMEMBER TO CALL stop() IN SHUTDOWN!
```

---

## Event Handler Pattern Checklist

```typescript
// ✅ Minimal viable handler pattern
class MyConnection {
  setupChannel(): void {
    if (!this.channel) return;

    // CRITICAL: Attach BEFORE async operations
    this.channel.onmessage = (event) => {
      this.handleMessage(event.data);
    };

    this.channel.onopen = () => {
      // Channel now open, but handler already attached
      this.emit('ready');
    };
  }
}
```

---

## State Timeout Pattern Checklist

```typescript
// ✅ Minimal viable timeout pattern
class MyStateMachine {
  private state: State = 'idle';
  private timeout: NodeJS.Timeout | null = null;

  transitionToWaiting(): void {
    this.state = 'waiting';

    // Start timeout
    this.timeout = setTimeout(() => {
      if (this.state === 'waiting') {
        this.state = 'idle'; // Reset
      }
    }, 10000); // 10 seconds
  }

  transitionToIdle(): void {
    // Clear timeout on success
    if (this.timeout) {
      clearTimeout(this.timeout);
      this.timeout = null;
    }
    this.state = 'idle';
  }
}
```

---

## Emergency Debugging Commands

### Check All Real-Time System Health
```javascript
// Paste this in browser console for full diagnosis
function diagnoseRealtime() {
  console.log('=== REAL-TIME SYSTEM DIAGNOSIS ===');

  // Voice ordering
  console.log('Voice Client:', {
    exists: !!window.__voiceClient,
    connectionState: window.__voiceClient?.getStatus().connectionState,
    turnState: window.__voiceClient?.getStatus().turnState,
    transcriptMapSize: window.__voiceClient?._eventHandler?._transcriptMap.size
  });

  // WebSocket
  console.log('WebSocket Service:', {
    exists: !!window.__wsService,
    state: window.__wsService?.getStatus().state,
    reconnectAttempts: window.__wsService?.getStatus().reconnectAttempts,
    subscriptions: window.__wsService?.getSubscriptions()
  });

  // Memory (server-side check via API)
  fetch('/api/v1/health/memory')
    .then(res => res.json())
    .then(data => console.log('Server Memory:', data));

  console.log('=== END DIAGNOSIS ===');
}

diagnoseRealtime();
```

### Force Clean Slate
```javascript
// Nuclear option: reset everything
function resetRealtime() {
  console.warn('RESETTING ALL REAL-TIME SYSTEMS');

  // Disconnect voice
  window.__voiceClient?.disconnect();

  // Disconnect WebSocket
  window.__wsService?.disconnect();

  // Clear local storage (if needed)
  // localStorage.clear();

  // Reload page
  setTimeout(() => location.reload(), 1000);
}
```

---

## Production Monitoring Queries

### Memory Growth Alert
```sql
-- Grafana/Prometheus query
rate(process_resident_memory_bytes[1h]) > 10000000  -- 10 MB/hour
```

### WebSocket Connection Health
```sql
-- Check connection success rate
(websocket_connections_successful / websocket_connections_attempted) < 0.95
```

### Voice Ordering Success Rate
```sql
-- Check voice success rate
(voice_orders_completed / voice_orders_started) < 0.90
```

### State Machine Timeouts
```sql
-- Alert on frequent timeouts
rate(voice_state_timeouts[5m]) > 0.1  -- More than 6/minute
```

---

## Quick Action Decision Tree

```
Voice ordering not working?
├─ Audio transmitting? (check stats)
│  ├─ YES: Check transcript events
│  │  ├─ NO events: Handler timing race
│  │  └─ Events received: State machine issue
│  └─ NO: Check microphone permissions
│
KDS infinite loading?
├─ Check connection count (window.__dbgWS)
│  ├─ Count > 1: Duplicate initialization
│  └─ Count = 1: Check subscriptions
│
Memory growing?
├─ Check active handles (process._getActiveHandles())
│  ├─ Timeouts growing: Interval leak
│  ├─ Sockets growing: Connection leak
│  └─ Stable but high: Check heap snapshot
│
Process won't exit?
├─ Send SIGTERM
│  ├─ Exits within 10s: Normal
│  └─ Doesn't exit: Check logs for stuck cleanup
│
State machine stuck?
├─ Check current state
│  ├─ waiting_user_final: No transcript received
│  ├─ waiting_response: No AI response
│  └─ Other: Logic bug
```

---

## Resource Limits Reference

### Memory Budgets
```
Development:  3GB (NODE_OPTIONS='--max-old-space-size=3072')
Production:   1GB target (hard limit 2GB)
Client Build: 3GB (vite.config.ts)

Per-Process:
- Voice WebSocket: ~50 MB
- KDS WebSocket: ~20 MB
- API Client: ~10 MB
- Per Connection: ~1 MB
```

### Connection Limits
```
WebSocket:    1 per client (+ reconnect attempts)
Voice WebRTC: 1 per client (ephemeral tokens)
HTTP:         100 concurrent (Express default)

Timeouts:
- Connection: 10 seconds
- Heartbeat:  30 seconds
- State:      10 seconds (voice), 15 seconds (AI response)
- Shutdown:   10 seconds total
```

---

**Last Updated:** 2025-11-19
**Print This:** Keep near your desk for fast debugging
**Next Review:** 2026-02-19

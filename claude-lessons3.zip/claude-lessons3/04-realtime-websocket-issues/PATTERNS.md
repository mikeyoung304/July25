---
category: "realtime-websocket"
category_id: "04"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "PATTERNS"
tags: [memory-leaks, race-conditions, event-handlers, connection-pooling]
---
# Real-Time Patterns - Proven Solutions

**Context:** Real-time WebSocket, WebRTC, and event-driven architecture patterns learned from 129 commits and 70+ hours debugging.

---

## Pattern 1: Timer/Interval Cleanup

### Problem
Timers created but never cleared accumulate indefinitely, causing memory leaks and preventing graceful shutdown.

### Anti-Pattern
```typescript
// ❌ BAD: No reference stored, cannot be cleared
class VoiceWebSocketServer {
  constructor() {
    setInterval(() => this.cleanupInactiveSessions(), 60000);
  }
}

// ❌ BAD: Module-level with no cleanup path
setInterval(() => {
  for (const [clientId, attempts] of suspiciousIPs.entries()) {
    if (attempts < 3) suspiciousIPs.delete(clientId);
  }
}, 60 * 60 * 1000);
```

### Correct Pattern
```typescript
// ✅ GOOD: Reference stored, cleanup method provided
class VoiceWebSocketServer {
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.cleanupInterval = setInterval(
      () => this.cleanupInactiveSessions(),
      60000
    );
  }

  public shutdown(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
    // Clean up all active sessions
    for (const sessionId of this.sessions.keys()) {
      this.stopSession(sessionId);
    }
  }
}

// ✅ GOOD: Module-level with explicit start/stop functions
let cleanupInterval: NodeJS.Timeout | null = null;

export function startRateLimiterCleanup(): void {
  if (cleanupInterval) return; // Prevent duplicates

  cleanupInterval = setInterval(() => {
    for (const [clientId, attempts] of suspiciousIPs.entries()) {
      if (attempts < 3) suspiciousIPs.delete(clientId);
    }
    logger.info('Rate limiter cleanup ran', {
      suspiciousCount: suspiciousIPs.size,
      blockedCount: blockedIPs.size
    });
  }, 60 * 60 * 1000);
}

export function stopRateLimiterCleanup(): void {
  if (cleanupInterval) {
    clearInterval(cleanupInterval);
    cleanupInterval = null;
  }
  suspiciousIPs.clear();
  blockedIPs.clear();
}
```

### Checklist
- [ ] Every `setInterval` has a stored reference
- [ ] Every `setTimeout` has a stored reference (if not one-shot)
- [ ] Cleanup method exists and is called on shutdown
- [ ] Cleanup sets reference to `null` after clearing
- [ ] Test verifies cleanup method clears the timer
- [ ] Integration with graceful shutdown system

---

## Pattern 2: Event Handler Attachment Timing

### Problem
WebRTC DataChannel sends events immediately upon opening. If `onmessage` handler is attached late, initial events are lost, causing cascade failures.

### The Timing Race (50-100ms Window)
```
T+0ms:   DataChannel opens
T+0ms:   OpenAI sends session.created event
T+10ms:  OpenAI sends conversation.item.created event
T+50ms:  Your handler finally attaches ❌ TOO LATE
Result:  Events lost forever, transcript map never initialized
```

### Anti-Pattern
```typescript
// ❌ BAD: Handler attached AFTER channel might already be open
class VoiceEventHandler {
  attachToDataChannel(dc: RTCDataChannel): void {
    // If dc.readyState is already 'open', we've lost initial events
    dc.onmessage = (event) => {
      this.handleMessage(event.data);
    };
  }
}

class WebRTCConnection {
  private setupDataChannel(): void {
    this.dc = this.pc.createDataChannel('oai-events');

    this.dc.onopen = () => {
      // Emit event to attach handler
      this.emit('dataChannelReady', this.dc); // ❌ TOO LATE
    };
  }
}
```

### Correct Pattern
```typescript
// ✅ GOOD: Handler attached BEFORE channel opens
class WebRTCConnection {
  private setupDataChannel(): void {
    if (!this.dc) return;

    // CRITICAL: Set onmessage BEFORE DataChannel opens
    this.dc.onmessage = (event: MessageEvent) => {
      // Forward to handler via event emission
      this.emit('dataChannelMessage', event.data);
    };

    this.dc.onopen = () => {
      if (this.config.debug) {
        logger.info('[WebRTCConnection] Data channel opened');
      }
      this.setConnectionState('connected');
      this.emit('dataChannelReady', this.dc);
    };

    this.dc.onerror = (event: Event) => {
      console.error('[WebRTCConnection] Data channel error:', event);
      this.emit('error', event);
    };

    this.dc.onclose = (event: Event) => {
      const closeEvent = event as any;
      console.error('[WebRTCConnection] Data channel closed:', {
        code: closeEvent.code,
        reason: closeEvent.reason,
        wasClean: closeEvent.wasClean
      });
      this.handleDisconnection();
    };
  }
}

// ✅ GOOD: Handler receives forwarded messages
class VoiceEventHandler {
  constructor(private config: WebRTCVoiceConfig) {
    // Handler ready before connection even starts
  }

  handleRawMessage(data: string): void {
    try {
      const event = JSON.parse(data);
      this.handleEvent(event);
    } catch (error) {
      logger.error('[VoiceEventHandler] Failed to parse message:', error);
    }
  }
}

// Wire them together
connection.on('dataChannelMessage', (data: string) => {
  eventHandler.handleRawMessage(data);
});
```

### Defensive Fallbacks
```typescript
// ✅ GOOD: Create transcript entries defensively
private handleTranscriptDelta(event: any, logPrefix: string): void {
  const itemId = event.item_id;

  // Defensive: Create entry if missing (in case conversation.item.created was lost)
  if (!this.transcriptMap.has(itemId)) {
    if (this.config.debug) {
      logger.warn(`${logPrefix} Creating missing transcript entry for ${itemId}`);
    }
    this.transcriptMap.set(itemId, {
      transcript: '',
      isFinal: false,
      timestamp: Date.now()
    });
  }

  // Now safe to append delta
  const entry = this.transcriptMap.get(itemId)!;
  entry.transcript += event.delta || '';
}
```

### Checklist
- [ ] Handler attached BEFORE any async operation
- [ ] Handler never relies on events being sent in specific order
- [ ] Defensive fallbacks for missed initialization events
- [ ] Comprehensive logging of all events (use `console.log` prefix for easy filtering)
- [ ] Test rapid connect/disconnect cycles

---

## Pattern 3: Connection Guard Flags

### Problem
Concurrent connection attempts create race conditions: duplicate subscriptions, inconsistent state, infinite loading.

### Anti-Pattern
```typescript
// ❌ BAD: No guard against concurrent calls
class WebSocketService {
  async connect(): Promise<void> {
    this.ws = new WebSocket(this.config.url);
    // If called twice concurrently, two sockets created
  }
}

// ❌ BAD: Re-render triggers re-initialization
useEffect(() => {
  initialize(); // Might be called multiple times
}, [someValue]); // Dependencies not stable
```

### Correct Pattern
```typescript
// ✅ GOOD: Guard flag prevents concurrent attempts
class WebSocketService {
  private ws: WebSocket | null = null;
  private isReconnecting = false;

  async connect(): Promise<void> {
    // Guard: Already connected
    if (this.ws && (
      this.ws.readyState === WebSocket.CONNECTING ||
      this.ws.readyState === WebSocket.OPEN
    )) {
      console.warn('[WebSocket] Already connected, skipping...');
      return;
    }

    // Guard: Reconnection in progress
    if (this.isReconnecting) {
      console.warn('[WebSocket] Reconnection in progress, skipping...');
      return;
    }

    this.isIntentionallyClosed = false;
    this.setConnectionState('connecting');

    try {
      // ... connection logic ...
    } catch (error) {
      logger.error('[WebSocket] Connection failed:', error);
      this.scheduleReconnect();
    }
  }

  private scheduleReconnect(): void {
    // Guard: Already reconnecting
    if (this.isReconnecting) return;

    this.isReconnecting = true;
    this.reconnectTimer = setTimeout(() => {
      this.isReconnecting = false;
      this.connect();
    }, this.config.reconnectInterval);
  }
}

// ✅ GOOD: Component-level connection guards
function KitchenDisplay() {
  const [isConnecting, setIsConnecting] = useState(false);
  const connectionPromiseRef = useRef<Promise<void> | null>(null);
  const isMountedRef = useRef(true);

  const initialize = useCallback(async () => {
    // Guard: Already connecting
    if (isConnecting) {
      console.warn('[KDS] Already connecting, awaiting existing...');
      return connectionPromiseRef.current;
    }

    // Guard: Not mounted
    if (!isMountedRef.current) {
      console.warn('[KDS] Component unmounted, skipping init');
      return;
    }

    setIsConnecting(true);
    const promise = (async () => {
      try {
        await websocketService.connect();
        await loadOrders();
      } finally {
        if (isMountedRef.current) {
          setIsConnecting(false);
          connectionPromiseRef.current = null;
        }
      }
    })();

    connectionPromiseRef.current = promise;
    return promise;
  }, []); // Empty deps - stable reference

  useEffect(() => {
    isMountedRef.current = true;
    initialize();

    return () => {
      isMountedRef.current = false;
      websocketService.disconnect();
    };
  }, []); // Empty deps - run once
}
```

### Checklist
- [ ] `isConnecting` flag prevents concurrent attempts
- [ ] `connectionPromise` allows awaiting existing connection
- [ ] `isMounted` flag prevents state updates after unmount
- [ ] `isReconnecting` flag prevents double-scheduling reconnects
- [ ] Stable callbacks (`useCallback([])` for functions in dependencies)
- [ ] Cleanup before initialization on reconnect
- [ ] Test rapid connect/disconnect/reconnect cycles

---

## Pattern 4: State Machine Timeout Guards

### Problem
State machines waiting for external events can deadlock forever if the event never arrives.

### Anti-Pattern
```typescript
// ❌ BAD: No timeout, can wait forever
type TurnState = 'idle' | 'recording' | 'waiting_user_final';

class WebRTCVoiceClient {
  private turnState: TurnState = 'idle';

  commitRecording(): void {
    this.turnState = 'waiting_user_final';
    // Waits forever for transcript event
  }

  handleTranscriptCompleted(): void {
    this.turnState = 'idle'; // Never called if no transcript
  }
}
```

### Correct Pattern
```typescript
// ✅ GOOD: Timeout ensures recovery
class WebRTCVoiceClient {
  private turnState: TurnState = 'idle';
  private turnStateTimeout: ReturnType<typeof setTimeout> | null = null;

  commitRecording(): void {
    this.turnState = 'waiting_user_final';

    // Start timeout to prevent permanent deadlock
    this.turnStateTimeout = setTimeout(() => {
      if (this.turnState === 'waiting_user_final') {
        logger.warn('[WebRTCVoiceClient] Timeout waiting for transcript, resetting to idle');
        this.turnState = 'idle';
        this.emit('timeout', { reason: 'No transcript received within 10s' });
      }
    }, 10000); // 10 seconds
  }

  handleTranscriptCompleted(): void {
    // Clear timeout on successful completion
    if (this.turnStateTimeout) {
      clearTimeout(this.turnStateTimeout);
      this.turnStateTimeout = null;
    }
    this.turnState = 'idle';
  }

  disconnect(): void {
    // Clean up timeout on disconnect
    if (this.turnStateTimeout) {
      clearTimeout(this.turnStateTimeout);
      this.turnStateTimeout = null;
    }
    this.turnState = 'idle';
  }
}
```

### Timeout Duration Guidelines
```typescript
// Choose timeout based on expected event arrival
const TIMEOUTS = {
  // Network round-trip
  API_RESPONSE: 5000,        // 5 seconds

  // User interaction
  USER_INPUT: 30000,         // 30 seconds

  // AI processing
  TRANSCRIPT: 10000,         // 10 seconds
  AI_RESPONSE: 15000,        // 15 seconds

  // Background tasks
  CLEANUP: 60000,            // 60 seconds
  HEARTBEAT: 35000,          // 35 seconds (server timeout is 30s)
};
```

### Checklist
- [ ] Timeout set when entering waiting state
- [ ] Timeout cleared when expected event arrives
- [ ] Timeout duration is generous but not infinite
- [ ] Timeout handler resets state to safe value
- [ ] Timeout cleanup on disconnect/unmount
- [ ] Test timeout scenario manually (block event, wait for timeout)

---

## Pattern 5: Graceful Shutdown Integration

### Problem
Resources (connections, timers, listeners) not cleaned up on shutdown cause memory leaks and prevent process from exiting cleanly.

### Anti-Pattern
```typescript
// ❌ BAD: No shutdown hook
const server = app.listen(PORT, () => {
  logger.info(`Server running on port ${PORT}`);
});

// ❌ BAD: Force exit after timeout
process.on('SIGTERM', () => {
  setTimeout(() => process.exit(0), 3000);
});
```

### Correct Pattern
```typescript
// ✅ GOOD: Comprehensive graceful shutdown
// server/src/server.ts
async function gracefulShutdown(signal: string): Promise<void> {
  logger.info(`${signal} received, starting graceful shutdown...`);

  // 1. Stop accepting new connections
  server.close(() => {
    logger.info('HTTP server closed');
  });

  // 2. Clean up WebSocket connections (with timeout)
  await Promise.race([
    cleanupWebSocketServer(),
    new Promise((resolve) => setTimeout(resolve, 3000))
  ]);

  // 3. Stop auth rate limiter cleanup
  stopRateLimiterCleanup();

  // 4. Shutdown voice WebSocket server
  if (voiceWsServer) {
    voiceWsServer.shutdown();
  }

  // 5. Close database connections
  await prisma.$disconnect();

  // 6. Final logging
  logger.info('Graceful shutdown complete');

  // 7. Exit cleanly
  process.exit(0);
}

// Register shutdown handlers
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Prevent immediate exit on unhandled rejection
process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled Rejection at:', promise, 'reason:', reason);
  // Don't exit immediately, let graceful shutdown handle it
});
```

### Cleanup Manager Pattern
```typescript
// ✅ GOOD: Centralized cleanup registration
// shared/utils/cleanup-manager.ts
class CleanupManager {
  private cleanupFunctions: Array<{
    name: string;
    fn: () => void | Promise<void>;
    priority: number;
  }> = [];

  register(
    name: string,
    fn: () => void | Promise<void>,
    priority: number = 10
  ): void {
    this.cleanupFunctions.push({ name, fn, priority });
  }

  async cleanup(): Promise<void> {
    // Sort by priority (higher = earlier)
    const sorted = this.cleanupFunctions.sort((a, b) => b.priority - a.priority);

    for (const { name, fn } of sorted) {
      try {
        logger.info(`[CleanupManager] Cleaning up: ${name}`);
        await fn();
      } catch (error) {
        logger.error(`[CleanupManager] Cleanup failed for ${name}:`, error);
      }
    }
  }
}

export const cleanupManager = new CleanupManager();

// Usage in components
cleanupManager.register('WebSocketService', () => {
  websocketService.disconnect();
}, 100); // High priority

cleanupManager.register('VoiceWebSocketServer', () => {
  voiceWsServer.shutdown();
}, 90);

cleanupManager.register('AuthRateLimiter', () => {
  stopRateLimiterCleanup();
}, 80);
```

### Checklist
- [ ] Shutdown handler registered for SIGTERM and SIGINT
- [ ] All timers/intervals cleared
- [ ] All event listeners removed
- [ ] All WebSocket/WebRTC connections closed
- [ ] All database connections closed
- [ ] Graceful shutdown timeout (5-10 seconds)
- [ ] Forced exit only after timeout
- [ ] Test with `kill -TERM <pid>`

---

## Pattern 6: Comprehensive Error Logging

### Problem
Silent failures prevent diagnosis. Generic error messages provide no actionable information.

### Anti-Pattern
```typescript
// ❌ BAD: No logging
this.dc.onclose = () => {
  this.handleDisconnection();
};

// ❌ BAD: Generic logging
this.dc.onerror = (error) => {
  logger.error('Data channel error', error);
};

// ❌ BAD: Debug-only logging (production has debug=false)
if (this.config.debug) {
  logger.info('Connection closed');
}
```

### Correct Pattern
```typescript
// ✅ GOOD: Always log errors regardless of debug mode
this.dc.onopen = () => {
  // Normal operation - can be debug-gated
  if (this.config.debug) {
    logger.info('[WebRTCConnection] Data channel opened');
  }
  this.setConnectionState('connected');
};

this.dc.onerror = (event: Event) => {
  // CRITICAL: Always log errors
  console.error('[WebRTCConnection] Data channel error event:', {
    type: event.type,
    target: event.target,
    timestamp: Date.now(),
    readyState: this.dc?.readyState,
    bufferedAmount: this.dc?.bufferedAmount,
    error: event
  });
  this.emit('error', event);
};

this.dc.onclose = (event: Event) => {
  // CRITICAL: Always log close events
  const closeEvent = event as any;
  console.error('[WebRTCConnection] Data channel closed:', {
    code: closeEvent.code,
    reason: closeEvent.reason,
    wasClean: closeEvent.wasClean,
    timestamp: Date.now(),
    connectionState: this.connectionState,
    lastHeartbeat: Date.now() - this.lastHeartbeat
  });
  this.handleDisconnection();
};

// ✅ GOOD: Log ALL events during diagnosis
private handleEvent(event: any): void {
  // Comprehensive event logging (can be temporary for diagnosis)
  console.log(`🔔 [VoiceEventHandler] ${event.type}`, {
    type: event.type,
    timestamp: Date.now(),
    itemId: event.item_id,
    deltaLength: event.delta?.length,
    error: event.error
  });

  // Route to specific handler
  this.routeEvent(event);
}
```

### Structured Logging
```typescript
// ✅ GOOD: Consistent log format
import { logger } from '@/services/logger';

// Success operations (INFO level)
logger.info('[Component] Operation completed', {
  operation: 'connect',
  duration: Date.now() - startTime,
  metadata: { userId, restaurantId }
});

// Expected issues (WARN level)
logger.warn('[Component] Retrying operation', {
  operation: 'fetch',
  attempt: 2,
  maxAttempts: 3,
  lastError: error.message
});

// Unexpected issues (ERROR level)
logger.error('[Component] Operation failed', {
  operation: 'process',
  error: error.message,
  stack: error.stack,
  context: { orderId, itemId }
});

// Critical issues (FATAL level - rare)
logger.fatal('[Component] Unrecoverable error', {
  operation: 'initialize',
  error: error.message,
  willExitProcess: true
});
```

### Checklist
- [ ] Errors always logged (not gated by debug flag)
- [ ] Log includes context (IDs, state, timestamps)
- [ ] Log includes structured data (objects, not strings)
- [ ] Consistent log prefix per component `[ComponentName]`
- [ ] Use `console.error` for errors (shows in red in console)
- [ ] Use `console.log` for trace logging (easy to filter by prefix)
- [ ] Use emoji prefixes for easy visual scanning (🔔 for events, ❌ for errors, ✅ for success)

---

## Pattern 7: WebRTC DataChannel Setup Sequence

### The Complete Correct Sequence

```typescript
// ✅ GOOD: Complete WebRTC connection flow
class WebRTCConnection extends EventEmitter {
  private pc: RTCPeerConnection | null = null;
  private dc: RTCDataChannel | null = null;
  private sessionActive = false;

  async connect(ephemeralToken: string): Promise<void> {
    try {
      // Step 1: Create peer connection with ICE servers
      this.pc = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
      });

      // Step 2: Add audio track (if using audio)
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          sampleRate: 24000
        }
      });
      stream.getTracks().forEach(track => {
        this.pc!.addTrack(track, stream);
      });

      // Step 3: Set up ICE candidate collection
      this.pc.onicecandidate = (event) => {
        if (event.candidate) {
          if (this.config.debug) {
            logger.info('[WebRTCConnection] ICE candidate:', event.candidate.candidate);
          }
        }
      };

      // Step 4: Create data channel (BEFORE creating offer)
      this.dc = this.pc.createDataChannel('oai-events', {
        ordered: true
      });

      // Step 5: Attach handlers BEFORE channel opens
      this.setupDataChannel();

      // Step 6: Create offer
      const offer = await this.pc.createOffer();
      await this.pc.setLocalDescription(offer);

      // Step 7: Send offer to OpenAI with ephemeral token
      const sdpResponse = await fetch(
        `https://api.openai.com/v1/realtime?model=${this.config.model}`,
        {
          method: 'POST',
          body: offer.sdp,
          headers: {
            'Authorization': `Bearer ${ephemeralToken}`,
            'Content-Type': 'application/sdp'
          }
        }
      );

      if (!sdpResponse.ok) {
        throw new Error(`SDP exchange failed: ${sdpResponse.statusText}`);
      }

      // Step 8: Set remote description
      const answerSdp = await sdpResponse.text();
      const answer: RTCSessionDescriptionInit = {
        type: 'answer',
        sdp: answerSdp
      };
      await this.pc.setRemoteDescription(answer);

      // Step 9: Mark session as active
      this.sessionActive = true;

      if (this.config.debug) {
        logger.info('[WebRTCConnection] WebRTC connection established');
      }
    } catch (error) {
      logger.error('[WebRTCConnection] Connection failed:', error);
      this.handleDisconnection();
      throw error;
    }
  }

  private setupDataChannel(): void {
    if (!this.dc) return;

    // CRITICAL: onmessage BEFORE channel opens
    this.dc.onmessage = (event: MessageEvent) => {
      this.emit('dataChannelMessage', event.data);
    };

    this.dc.onopen = () => {
      if (this.config.debug) {
        logger.info('[WebRTCConnection] Data channel opened');
      }
      this.setConnectionState('connected');
      this.emit('dataChannelReady', this.dc);
    };

    this.dc.onerror = (event: Event) => {
      console.error('[WebRTCConnection] Data channel error:', {
        type: event.type,
        readyState: this.dc?.readyState,
        timestamp: Date.now()
      });
      this.emit('error', event);
    };

    this.dc.onclose = (event: Event) => {
      const closeEvent = event as any;
      console.error('[WebRTCConnection] Data channel closed:', {
        code: closeEvent.code,
        reason: closeEvent.reason,
        wasClean: closeEvent.wasClean
      });
      this.handleDisconnection();
    };
  }

  disconnect(): void {
    this.sessionActive = false;

    if (this.dc) {
      this.dc.close();
      this.dc = null;
    }

    if (this.pc) {
      this.pc.close();
      this.pc = null;
    }

    this.setConnectionState('disconnected');
  }
}
```

### Sequence Checklist
- [ ] Peer connection created first
- [ ] Audio tracks added (if needed)
- [ ] ICE handlers attached
- [ ] Data channel created BEFORE offer
- [ ] Handlers attached BEFORE channel opens
- [ ] Offer created and set as local description
- [ ] Offer sent to server with auth
- [ ] Answer received and set as remote description
- [ ] Session marked active
- [ ] Error handling at each step
- [ ] Cleanup on disconnect

---

## Testing Real-Time Code

### Unit Tests
```typescript
describe('WebRTCVoiceClient', () => {
  test('cleanup clears state timeout', () => {
    const client = new WebRTCVoiceClient(config);
    const clearTimeoutSpy = jest.spyOn(global, 'clearTimeout');

    // Simulate entering waiting state
    client['turnState'] = 'waiting_user_final';
    client['turnStateTimeout'] = setTimeout(() => {}, 10000);

    // Disconnect should clear timeout
    client.disconnect();

    expect(clearTimeoutSpy).toHaveBeenCalled();
    expect(client['turnStateTimeout']).toBeNull();
  });

  test('timeout resets state after 10 seconds', async () => {
    jest.useFakeTimers();
    const client = new WebRTCVoiceClient(config);

    // Enter waiting state
    client['turnState'] = 'waiting_user_final';
    client['startStateTimeout']();

    // Fast-forward 10 seconds
    jest.advanceTimersByTime(10000);

    // State should reset
    expect(client['turnState']).toBe('idle');

    jest.useRealTimers();
  });
});
```

### Integration Tests
```typescript
describe('KDS WebSocket Race Conditions', () => {
  test('concurrent initialize calls are guarded', async () => {
    const component = renderKitchenDisplay();

    // Simulate rapid re-renders
    const promises = [
      component.initialize(),
      component.initialize(),
      component.initialize()
    ];

    await Promise.all(promises);

    // Should only connect once
    expect(mockWebSocketService.connect).toHaveBeenCalledTimes(1);
  });
});
```

### E2E Tests
```typescript
// tests/e2e/voice-ordering.spec.ts
test('voice ordering recovers from timeout', async ({ page }) => {
  await page.goto('/kiosk');

  // Start voice recording
  await page.click('[data-testid="voice-order-button"]');

  // Don't speak (simulate no audio)
  await page.waitForTimeout(500);

  // Release button (commit empty audio)
  await page.click('[data-testid="voice-order-button"]');

  // Wait for timeout (10s)
  await page.waitForTimeout(11000);

  // Should be able to retry
  await page.click('[data-testid="voice-order-button"]');
  await expect(page.locator('[data-testid="voice-status"]')).toHaveText('Recording...');
});
```

---

## Summary Checklist

When implementing real-time features, ensure:

### Timers & Intervals
- [ ] All timers stored in references
- [ ] Cleanup methods implemented
- [ ] Integrated with graceful shutdown
- [ ] Tests verify cleanup

### Event Handlers
- [ ] Handlers attached before async operations
- [ ] Defensive fallbacks for missed events
- [ ] Comprehensive event logging
- [ ] Test rapid sequences

### Connections
- [ ] Guard flags prevent races
- [ ] Connection promises allow awaiting
- [ ] Mounted flags prevent updates after unmount
- [ ] Cleanup before reconnect

### State Machines
- [ ] Timeouts for all waiting states
- [ ] Timeout cleanup on success
- [ ] Graceful recovery on timeout
- [ ] Test timeout scenarios

### Shutdown
- [ ] Signal handlers registered
- [ ] All resources cleaned up
- [ ] Graceful shutdown timeout
- [ ] Test with kill signals

### Logging
- [ ] Errors always logged
- [ ] Structured data included
- [ ] Consistent component prefixes
- [ ] Visual scanning aids (emoji, colors)

---

**Last Updated:** 2025-11-19
**Status:** Production-Proven Patterns
**Next Review:** 2026-02-19

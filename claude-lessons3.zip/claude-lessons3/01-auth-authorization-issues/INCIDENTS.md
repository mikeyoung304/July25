---
category: authentication-authorization
category_id: "01"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: INCIDENTS
incident_count: 5
total_cost: 100000
total_duration_days: 70
severity_distribution:
  P0: 4
  P1: 1
incidents:
  - id: CL-AUTH-001
    title: "STRICT_AUTH Environment Drift"
    duration_days: 48
    cost: 20000
    severity: P0
  - id: CL-AUTH-002
    title: "JWT Scope Mismatch"
    duration_days: 10
    cost: 48000
    severity: P0
  - id: CL-AUTH-003
    title: "localStorage Session Sync"
    duration_days: 8
    cost: 12000
    severity: P0
  - id: CL-AUTH-004
    title: "Middleware Ordering Bug"
    duration_days: 3
    cost: 15000
    severity: P1
  - id: CL-AUTH-005
    title: "Multi-tenancy Access Control"
    duration_days: 1
    cost: 5000
    severity: P0
tags: [environment-drift, jwt, rbac, strict-auth, middleware, multi-tenancy, session-management]
key_files:
  - server/src/middleware/auth.ts
  - server/src/routes/auth.routes.ts
  - client/src/contexts/AuthContext.tsx
related_docs: [PATTERNS.md, PREVENTION.md, QUICK-REFERENCE.md, AI-AGENT-GUIDE.md]
---

# Major Authentication & Authorization Incidents

## CL-AUTH-001: STRICT_AUTH Environment Drift (48 Days)

**Date**: October 1 - November 18, 2025
**Duration**: 48 days (recurring daily)
**Cost**: $20,000+ engineering time + customer trust erosion
**Severity**: P0 Critical

### The Problem

Frontend used `supabase.auth.signInWithPassword()` which returned Supabase JWTs **without** `restaurant_id` claim. Backend STRICT_AUTH=true rejected these tokens.

### Root Cause Analysis

```
Local Development:
  STRICT_AUTH=false → Accepts tokens without restaurant_id → Works ✅

Production:
  STRICT_AUTH=true → Requires restaurant_id in JWT → Fails ❌

Frontend Code:
  Uses supabase.auth.signInWithPassword()
  Returns Supabase JWT (missing restaurant_id)

Backend Middleware:
  if (STRICT_AUTH && !decoded.restaurant_id) throw Unauthorized()
```

### Timeline

- **Oct 1**: STRICT_AUTH=true enabled on Render
- **Oct 1-Nov 18**: Daily production login failures
- **Nov 18**: Permanent fix (commit 9e97f720)

### Symptoms

- "Authentication Required" modal in infinite loop
- 401 Unauthorized on `/api/v1/auth/me`
- Works locally, fails in production
- User credentials correct but login rejected

### The Fix (Commit 9e97f720)

**File**: `/client/src/contexts/AuthContext.tsx:184-265`

```typescript
// BEFORE (BROKEN)
const login = async (email, password, restaurantId) => {
  // Direct Supabase auth
  const { data } = await supabase.auth.signInWithPassword({ email, password });
  // JWT missing restaurant_id → STRICT_AUTH rejects it
};

// AFTER (FIXED)
const login = async (email, password, restaurantId) => {
  // 1. Resolve slug to UUID
  const GROW_RESTAURANT_UUID = '11111111-1111-1111-1111-111111111111';
  const resolvedRestaurantId = restaurantId === 'grow'
    ? GROW_RESTAURANT_UUID
    : restaurantId;

  // 2. Use CUSTOM auth endpoint
  const response = await httpClient.post('/api/v1/auth/login', {
    email,
    password,
    restaurantId: resolvedRestaurantId
  });

  // 3. Store session in localStorage
  localStorage.setItem('auth_session', JSON.stringify({
    user: response.user,
    session: response.session,
    restaurantId: response.restaurantId
  }));

  // 4. Sync with Supabase for Realtime
  await supabase.auth.setSession({
    access_token: response.session.access_token,
    refresh_token: response.session.refresh_token
  });
};
```

### Prevention Rules

1. **Never use Supabase direct auth** for workspace login
2. **Always test with STRICT_AUTH=true** locally
3. **Store JWT in localStorage** for httpClient access
4. **Hardcode slug-to-UUID** resolution (no network call)

### References

- Commit: `9e97f720` (fix), `a3514472` (localStorage)
- Incident Report: [CL-AUTH-001](../../claudelessons-v2/knowledge/incidents/CL-AUTH-001-supabase-direct-auth-strict-mode.md)

---

## JWT Scope Mismatch (10 Days)

**Date**: November 2-12, 2025
**Duration**: 10 days (6 days undetected)
**Cost**: $48,000+ engineering time
**Severity**: P0 Critical

### The Problem

JWT tokens created **without** `scope` field, causing complete RBAC failure. All role-based operations returned 401 errors.

### Root Cause

Demo session removal (commit 5dc74903) changed JWT creation order:

```typescript
// BEFORE (WORKING)
const scopes = await fetchScopes(role);
const token = jwt.sign({ sub, email, role, scope: scopes }, secret);

// AFTER (BROKEN)
const token = jwt.sign({ sub, email, role }, secret);  // Missing scope!
const scopes = await fetchScopes(role);  // Too late

// Response body had scopes, but JWT didn't
// Backend RBAC checks JWT, not response body
```

### Symptoms

- `401: Missing required scope: orders:create`
- Server role couldn't place orders
- Cashier role couldn't process payments
- Kitchen role couldn't update order status
- All authorization checks failed

### The Fix (Commit 4fd9c9d2)

**File**: `/server/src/routes/auth.routes.ts:75-107`

```typescript
// CORRECT ORDER:
// 1. Fetch scopes from database FIRST
const { data: scopesData } = await supabase
  .from('role_scopes')
  .select('scope')
  .eq('role', userRole.role);

const scopes = scopesData?.map(s => s.scope) || [];

// 2. Create JWT with scopes included
const payload = {
  sub: authData.user.id,
  email: authData.user.email,
  role: userRole.role,
  restaurant_id: restaurantId,
  scope: scopes,  // ✅ CRITICAL FIX
  auth_method: 'email',
  iat: Math.floor(Date.now() / 1000),
  exp: Math.floor(Date.now() / 1000) + (8 * 60 * 60)
};

const token = jwt.sign(payload, process.env.SUPABASE_JWT_SECRET);
```

### Why Undetected for 6 Days

The system had fallback logic that sometimes worked:

```typescript
// Backend RBAC middleware
const scopes = decoded.scope || req.user.scopes || [];
// If JWT missing scope, check req.user.scopes (from session)
// This fallback masked the bug intermittently
```

### Prevention Rules

1. **Fetch scopes BEFORE JWT creation**
2. **Include scope in JWT payload** (not just response)
3. **Validate JWT structure** in tests
4. **No fallback logic** for critical fields

### References

- Commit: `4fd9c9d2` (fix), `5dc74903` (bug introduced)
- ADR: [ADR-010 JWT Payload Standards](../../docs/explanation/architecture-decisions/ADR-010-jwt-payload-standards.md)

---

## Restaurant ID Sync Failure (8 Days)

**Date**: November 2-10, 2025
**Duration**: 8 days
**Cost**: $12,000+ engineering time
**Severity**: P1 High

### The Problem

Login hung at "Signing in..." because React state `restaurantId` not synced with `httpClient.currentRestaurantId`.

### Root Cause

```typescript
// Demo session cleanup removed these sync calls
setRestaurantId(response.restaurantId);  // React state only
// Missing: setCurrentRestaurantId(response.restaurantId)

// httpClient makes API call without X-Restaurant-ID header
// Backend validateRestaurantAccess queries user_restaurants table
// Query hangs without timeout (no restaurant_id to filter on)
```

### Symptoms

- Login stuck at "Signing in..." indefinitely
- `/api/v1/auth/me` request hangs
- No error message (timeout, not rejection)

### The Fix (Commit acd6125c)

**File**: `/client/src/contexts/AuthContext.tsx`

Added `setCurrentRestaurantId()` at **5 critical locations**:

```typescript
// Line 82: Session restoration
setRestaurantId(session.restaurantId);
setCurrentRestaurantId(session.restaurantId);  // ✅ Added

// Line 152: Auth state change
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);  // ✅ Added

// Line 227: Email/password login
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);  // ✅ Added

// Line 263: PIN login
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);  // ✅ Added

// Line 315: Station login
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);  // ✅ Added
```

### Prevention Rules

1. **Always sync React state with httpClient global state**
2. **Add database query timeout** (5s) to prevent hangs
3. **Test all login flows** after state management changes

### References

- Commit: `acd6125c` (fix), `5dc74903` (bug introduced)

---

## Middleware Ordering Bug (3 Days)

**Date**: November 5-7, 2025
**Duration**: 3 days
**Cost**: $4,000+ engineering time
**Severity**: P2 Medium

### The Problem

Manager role couldn't save floor plans due to incorrect middleware order.

### Root Cause

```typescript
// WRONG ORDER
router.post('/tables',
  validateRestaurantAccess,  // Runs FIRST, req.user undefined!
  authenticate,              // Runs SECOND, sets req.user
  requireScopes(['tables:update']),
  handler
);

// validateRestaurantAccess needs req.user but it's not set yet
// Returns: 401 "Authentication required"
```

### The Fix (Commit 38f7bba0)

**File**: `/server/src/routes/tables.routes.ts`

```typescript
// CORRECT ORDER
router.post('/tables',
  authenticate,                    // 1. Set req.user
  validateRestaurantAccess,        // 2. Validate restaurant access
  requireScopes(['tables:update']), // 3. Check permissions
  handler
);
```

### Prevention Rules

1. **Standard middleware order**: authenticate → validateRestaurantAccess → requireScopes
2. **Never change middleware order** without testing
3. **Add integration tests** for middleware chain

### References

- Commit: `38f7bba0` (fix)

---

## Multi-Tenancy Security Vulnerability (1 Day)

**Date**: October 25, 2025
**Duration**: 1 day (caught in security audit)
**Cost**: $8,000+ engineering time
**Severity**: P0 Critical Security

### The Problem

Users could access data from other restaurants by changing `X-Restaurant-ID` header.

### Root Cause

```typescript
// VULNERABLE CODE
export async function authenticate(req, res, next) {
  const decoded = jwt.verify(token, secret);

  // BUG: Trusting client-provided header without validation
  req.restaurantId = req.headers['x-restaurant-id'];
  req.user = decoded;

  next();  // No validation that user has access!
}

// User from Restaurant A sends X-Restaurant-ID: restaurant-b-uuid
// Backend accepts it → cross-tenant data leak
```

### Attack Scenario

```bash
# Attacker logs in to Restaurant A
curl -X POST /api/v1/auth/login \
  -d '{"email":"user@restaurant-a.com","password":"pass"}'

# Receives token for Restaurant A
TOKEN="eyJhbG..."

# Changes X-Restaurant-ID to Restaurant B
curl -X GET /api/v1/orders \
  -H "Authorization: Bearer $TOKEN" \
  -H "X-Restaurant-ID: restaurant-b-uuid"

# SUCCESS - Returns Restaurant B orders! ❌
```

### The Fix (Commit df228afd)

**Files**:
- `/server/src/middleware/auth.ts`: Removed premature `req.restaurantId` assignment
- `/server/src/middleware/restaurantAccess.ts`: Added validation before setting

```typescript
// auth.ts: Only extract from JWT (trusted)
export async function authenticate(req, res, next) {
  const decoded = jwt.verify(token, secret);

  req.user = {
    id: decoded.sub,
    email: decoded.email,
    role: decoded.role,
    scopes: decoded.scope,
    restaurant_id: decoded.restaurant_id  // From JWT only
  };

  // Do NOT set req.restaurantId here
  next();
}

// restaurantAccess.ts: Validate before setting
export async function validateRestaurantAccess(req, res, next) {
  const requestedRestaurantId = req.headers['x-restaurant-id'];

  // Verify user has access to this restaurant
  const { data } = await supabase
    .from('user_restaurants')
    .select('*')
    .eq('user_id', req.user.id)
    .eq('restaurant_id', requestedRestaurantId)
    .single();

  if (!data) {
    throw Forbidden('Access denied to this restaurant');
  }

  // ONLY set after validation passes
  req.restaurantId = requestedRestaurantId;
  next();
}
```

### Impact

- **8-9 failing multi-tenancy tests** fixed
- Prevented potential data breach
- All 24 multi-tenancy tests now passing

### Prevention Rules

1. **Defense in depth**: JWT + middleware + RLS
2. **Never trust client headers** without validation
3. **Validate restaurant access** against database
4. **Test cross-tenant scenarios** in security suite

### References

- Commit: `df228afd` (fix)
- Security audit finding

---

## Summary Table

| Incident | Duration | Cost | Root Cause | Detection |
|----------|----------|------|------------|-----------|
| STRICT_AUTH drift | 48 days | $20K+ | Environment parity | Manual testing |
| JWT scope missing | 10 days | $48K+ | Code refactor order | Production error |
| Restaurant ID sync | 8 days | $12K+ | State management | User report |
| Middleware ordering | 3 days | $4K+ | Wrong order | Manual testing |
| Multi-tenancy vuln | 1 day | $8K+ | Missing validation | Security audit |
| **TOTAL** | **70 days** | **$92K+** | — | — |

---

## Common Patterns Across Incidents

1. **Environment Drift**: Local works, production fails
2. **Refactoring Bugs**: Code changes broke implicit contracts
3. **State Management**: React state vs global state desync
4. **Missing Validation**: Trusting client input
5. **Test Coverage Gaps**: Issues not caught by tests

---

**Related**: [PREVENTION.md](./PREVENTION.md), [ADR-011](../../docs/explanation/architecture-decisions/ADR-011-authentication-evolution.md)

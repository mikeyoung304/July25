---
category: authentication-authorization
category_id: "01"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: PATTERNS
pattern_count: 8
tags: [dual-auth, jwt, middleware-chain, multi-tenancy, strict-auth, session-storage, slug-resolution]
patterns:
  - name: "Dual Authentication Architecture"
    difficulty: advanced
    impact: high
  - name: "JWT Payload Requirements"
    difficulty: intermediate
    impact: critical
  - name: "Middleware Ordering Pattern"
    difficulty: intermediate
    impact: high
  - name: "Environment Parity Pattern (STRICT_AUTH)"
    difficulty: beginner
    impact: critical
  - name: "Restaurant ID Sync Pattern"
    difficulty: intermediate
    impact: high
  - name: "localStorage Session Storage Pattern"
    difficulty: beginner
    impact: high
  - name: "Multi-Tenancy Security Pattern"
    difficulty: advanced
    impact: critical
  - name: "Slug-to-UUID Resolution Pattern"
    difficulty: beginner
    impact: low
key_files:
  - server/src/middleware/auth.ts
  - server/src/routes/auth.routes.ts
  - client/src/contexts/AuthContext.tsx
  - client/src/services/http/httpClient.ts
  - server/src/middleware/restaurantAccess.ts
related_adrs: [ADR-006, ADR-010]
related_docs: [INCIDENTS.md, PREVENTION.md]
---

# Authentication & Authorization Patterns

## 1. Dual Authentication Architecture

### Pattern Overview

The system runs TWO authentication methods in parallel:

```typescript
// Priority 1: Supabase Auth (Production)
// - Email/password for managers/owners
// - httpOnly cookies, auto token refresh
// - Secure by default

// Priority 2: Custom JWT in localStorage (Fallback)
// - Demo users (development)
// - PIN authentication (shared devices)
// - Station authentication (KDS displays)
// - Voice ordering (WebRTC context)
```

### Implementation

**File**: `/client/src/services/http/httpClient.ts:109-148`

```typescript
async request(endpoint, options) {
  // 1. Check Supabase first
  const { data: { session } } = await supabase.auth.getSession();

  if (session?.access_token) {
    headers.set('Authorization', `Bearer ${session.access_token}`);
    logger.info('Using Supabase session');
  } else {
    // 2. Fallback to localStorage
    const savedSession = localStorage.getItem('auth_session');

    if (savedSession) {
      const parsed = JSON.parse(savedSession);

      // Validate expiry
      if (parsed.session?.accessToken &&
          parsed.session?.expiresAt > Date.now() / 1000) {
        headers.set('Authorization', `Bearer ${parsed.session.accessToken}`);
        logger.info('Using localStorage session');
      }
    }
  }

  return super.request(endpoint, { headers, ...options });
}
```

### When to Use Each Method

| Auth Method | Use Case | Storage | Lifetime |
|-------------|----------|---------|----------|
| Supabase Auth | Manager/owner login | Supabase localStorage | 1 hour (auto-refresh) |
| Custom JWT | Demo, PIN, station, voice | Custom localStorage | 1-8 hours |
| Anonymous | Customer orders | Ephemeral | 1 hour |

### Critical Rule

**NEVER use `supabase.auth.signInWithPassword()` for workspace login.**

Why? Supabase JWTs lack `restaurant_id` and `scope` fields required by STRICT_AUTH mode.

```typescript
// ❌ WRONG - Breaks with STRICT_AUTH=true
const { data } = await supabase.auth.signInWithPassword({ email, password });

// ✅ CORRECT - Custom JWT with all required fields
const response = await httpClient.post('/api/v1/auth/login', {
  email,
  password,
  restaurantId: '11111111-1111-1111-1111-111111111111'
});
```

---

## 2. JWT Payload Requirements

### Required Fields (ADR-010)

ALL JWTs MUST include:

```typescript
interface JWTPayload {
  // Identity
  sub: string;           // User ID (UUID)
  email: string;         // Email address

  // Authorization
  role: string;          // server, kitchen, manager, etc.
  scope: string[];       // Permission scopes (CRITICAL)

  // Multi-tenancy
  restaurant_id: string; // Restaurant UUID (CRITICAL)

  // Metadata
  auth_method: 'email' | 'pin' | 'station';
  iat: number;           // Issued at
  exp: number;           // Expiration
}
```

### JWT Creation Pattern (CORRECT)

**File**: `/server/src/routes/auth.routes.ts:75-107`

```typescript
// CRITICAL: Fetch scopes BEFORE creating JWT
const { data: scopesData, error: scopesError } = await supabase
  .from('role_scopes')
  .select('scope')
  .eq('role', userRole.role);

if (scopesError) {
  logger.warn('scope_fetch_fail', { restaurant_id: restaurantId });
}

const scopes = scopesData?.map(s => s.scope) || [];

// Generate JWT with ALL required fields
const payload = {
  sub: authData.user.id,
  email: authData.user.email,
  role: userRole.role,
  restaurant_id: restaurantId,  // ✅ Required for STRICT_AUTH
  scope: scopes,                 // ✅ Required for RBAC
  auth_method: 'email',
  iat: Math.floor(Date.now() / 1000),
  exp: Math.floor(Date.now() / 1000) + (8 * 60 * 60)
};

const token = jwt.sign(payload, process.env.SUPABASE_JWT_SECRET);
```

### Common JWT Creation Bugs

```typescript
// ❌ BUG: Creating JWT before fetching scopes (commit 4fd9c9d2)
const token = jwt.sign({ sub, email, role }, secret);
const scopes = await fetchScopes(role);  // TOO LATE!

// ❌ BUG: Missing restaurant_id (CL-AUTH-001)
const payload = { sub, email, role, scope };
// Will fail with STRICT_AUTH=true

// ❌ BUG: Using Supabase JWT directly
const { data } = await supabase.auth.signInWithPassword(...);
return data.session;  // Missing custom fields

// ✅ CORRECT: Fetch scopes first, include restaurant_id
const scopes = await fetchScopes(role);
const payload = { sub, email, role, scope: scopes, restaurant_id };
const token = jwt.sign(payload, secret);
```

---

## 3. Middleware Ordering Pattern

### The ONLY Correct Order

```typescript
router.post('/orders',
  authenticate,                    // 1. Validate JWT, set req.user
  validateRestaurantAccess,        // 2. Verify user can access restaurant
  requireScopes(['orders:create']), // 3. Check specific permissions
  async (req, res) => {
    // Handler code
  }
);
```

### Why Order Matters

**Commit 38f7bba0**: Manager couldn't save floor plans due to middleware ordering bug.

```typescript
// ❌ WRONG ORDER - validateRestaurantAccess runs before authenticate
router.post('/tables',
  validateRestaurantAccess,  // req.user is undefined!
  authenticate,
  requireScopes(['tables:update']),
  handler
);

// Result: 401 Unauthorized (user not set yet)
```

### Middleware Responsibilities

| Middleware | Input Requirements | Sets | Purpose |
|------------|-------------------|------|---------|
| `authenticate` | Authorization header | `req.user`, `req.restaurantId` | Validate JWT signature |
| `validateRestaurantAccess` | `req.user` | `req.restaurantRole` | Multi-tenancy check |
| `requireScopes` | `req.user.scopes` | none | Permission check |

### Pattern Template

```typescript
// Protected endpoint (staff only)
router.post('/resource',
  authenticate,
  validateRestaurantAccess,
  requireScopes(['resource:create']),
  handler
);

// Optional auth (menu browsing)
router.get('/menu',
  optionalAuth,  // Sets req.user if token present
  handler
);

// Public endpoint (customer orders)
router.post('/orders',
  optionalAuth,
  handler  // Check req.user to determine if staff or customer
);
```

---

## 4. Environment Parity Pattern (STRICT_AUTH)

### The Problem (CL-AUTH-001)

**48 days of production failures** due to environment drift:

```bash
# Local development (.env)
STRICT_AUTH=false  # Allowed legacy tokens

# Production (Render)
STRICT_AUTH=true   # Required restaurant_id in JWT

# Result: Works locally, breaks in production
```

### The Solution

**ALWAYS test with STRICT_AUTH=true locally** before deploying.

```bash
# server/.env (development)
STRICT_AUTH=true  # Same as production
SUPABASE_JWT_SECRET=your-secret
KIOSK_JWT_SECRET=your-secret
```

### STRICT_AUTH Enforcement

**File**: `/server/src/middleware/auth.ts:84-92`

```typescript
const strictAuth = process.env['STRICT_AUTH'] === 'true';

// Reject tokens without restaurant_id
if (strictAuth && !decoded.restaurant_id) {
  logger.error('⛔ STRICT_AUTH enabled - token missing restaurant_id rejected', {
    userId: decoded.sub,
    path: req.path,
    role: userRole
  });
  throw Unauthorized('Token missing restaurant context in strict auth mode');
}
```

### Pre-Commit Check Pattern

```bash
# .husky/pre-commit
if git diff --cached --name-only | grep -q "AuthContext\|auth.routes\|auth.middleware"; then
  echo "⚠️  Auth files changed - Did you test with STRICT_AUTH=true locally?"
  echo "   Add 'STRICT_AUTH=true' to server/.env and test login flow"
fi
```

---

## 5. Restaurant ID Sync Pattern

### The Two-State Problem (Commit acd6125c)

React state and httpClient global state must stay synchronized:

```typescript
// React state (for UI)
const [restaurantId, setRestaurantId] = useState<string>();

// Global state (for API calls)
httpClient.currentRestaurantId = restaurantId;
```

### Critical Sync Points

**File**: `/client/src/contexts/AuthContext.tsx`

```typescript
// ✅ CORRECT: Sync at ALL 5 locations

// 1. Session restoration (line 82)
if (session) {
  setRestaurantId(session.restaurantId);
  setCurrentRestaurantId(session.restaurantId);  // Sync httpClient
}

// 2. Auth state change (line 152)
if (event === 'SIGNED_IN') {
  setRestaurantId(response.restaurantId);
  setCurrentRestaurantId(response.restaurantId);  // Sync httpClient
}

// 3. Email/password login (line 227)
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);  // Sync httpClient

// 4. PIN login (line 263)
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);  // Sync httpClient

// 5. Station login (line 315)
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);  // Sync httpClient
```

### Bug Pattern

```typescript
// ❌ WRONG: Only update React state
setRestaurantId(response.restaurantId);
// Result: httpClient sends API calls without X-Restaurant-ID header
// Backend validateRestaurantAccess hangs on database query

// ✅ CORRECT: Update both
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);
```

---

## 6. localStorage Session Storage Pattern

### The Pattern (Commit a3514472)

After successful login, ALWAYS store session in localStorage:

```typescript
// ✅ CORRECT: Accessible to httpClient
localStorage.setItem('auth_session', JSON.stringify({
  user: response.user,
  session: {
    accessToken: response.session.access_token,
    refreshToken: response.session.refresh_token,
    expiresIn: response.session.expires_in,
    expiresAt: Date.now() / 1000 + response.session.expires_in
  },
  restaurantId: response.restaurantId
}));

// Also sync with Supabase for Realtime subscriptions
await supabase.auth.setSession({
  access_token: response.session.access_token,
  refresh_token: response.session.refresh_token
});
```

### Why Both Storage Locations?

| Storage | Purpose | Who Reads It |
|---------|---------|--------------|
| localStorage (auth_session) | API calls via httpClient | `httpClient.ts` |
| Supabase localStorage | Realtime subscriptions | Supabase SDK |

### Bug Pattern

```typescript
// ❌ WRONG: Only React state
setSession(sessionData);
// Result: httpClient can't find token, returns 401

// ❌ WRONG: Only Supabase
await supabase.auth.setSession(sessionData);
// Result: httpClient can't find token for voice ordering

// ✅ CORRECT: Both locations
localStorage.setItem('auth_session', JSON.stringify(sessionData));
await supabase.auth.setSession(sessionData);
```

---

## 7. Multi-Tenancy Security Pattern

### Defense in Depth (3 Layers)

**Layer 1: JWT Token**
```typescript
// JWT must contain restaurant_id
const payload = { ..., restaurant_id: '...' };
```

**Layer 2: Middleware Validation**

**File**: `/server/src/middleware/restaurantAccess.ts:22-82`

```typescript
export async function validateRestaurantAccess(req, res, next) {
  // 1. Ensure authenticated
  if (!req.user) throw Unauthorized('Authentication required');

  // 2. Get requested restaurant ID
  const requestedRestaurantId =
    req.headers['x-restaurant-id'] || req.restaurantId;

  if (!requestedRestaurantId) {
    throw Forbidden('Restaurant ID is required');
  }

  // 3. Admin bypass
  if (req.user.role === 'admin') {
    req.restaurantId = requestedRestaurantId;
    return next();
  }

  // 4. Validate user has access to this restaurant
  const { data, error } = await supabase
    .from('user_restaurants')
    .select('restaurant_id, role')
    .eq('user_id', req.user.id)
    .eq('restaurant_id', requestedRestaurantId)
    .single();

  if (error || !data) {
    throw Forbidden('Access denied to this restaurant');
  }

  // 5. ONLY set after validation passes
  req.restaurantId = requestedRestaurantId;
  req.restaurantRole = data.role;

  next();
}
```

**Layer 3: Database RLS Policies**
```sql
-- Supabase Row-Level Security
CREATE POLICY "Users can only access their restaurants"
ON orders FOR ALL
USING (restaurant_id IN (
  SELECT restaurant_id FROM user_restaurants
  WHERE user_id = auth.uid()
));
```

### Critical Security Bug (Commit df228afd)

```typescript
// ❌ VULNERABLE: Set restaurant_id before validation
export async function authenticate(req, res, next) {
  const decoded = jwt.verify(token, secret);

  // BUG: Trusting client-provided header without validation
  req.restaurantId = req.headers['x-restaurant-id'];
  req.user = decoded;
  next();
}

// Result: User from Restaurant A can access Restaurant B by changing header
```

### Correct Pattern

```typescript
// ✅ SECURE: Never trust client-provided restaurant_id
// 1. authenticate: Only extract from JWT (trusted source)
// 2. validateRestaurantAccess: Verify against database
// 3. Only then set req.restaurantId
```

---

## 8. Slug-to-UUID Resolution Pattern

### The Pattern (Hardcoded for Single Restaurant)

**File**: `/client/src/contexts/AuthContext.tsx:195-199`

```typescript
// Hardcode slug resolution (no network call)
const GROW_RESTAURANT_UUID = '11111111-1111-1111-1111-111111111111';
const resolvedRestaurantId = restaurantId === 'grow'
  ? GROW_RESTAURANT_UUID
  : restaurantId;
```

### Why Hardcoded?

1. **Avoid network call during login** (potential failure point)
2. **Single restaurant deployment** (no need for dynamic lookup)
3. **Simplifies auth flow** (fewer dependencies)

### Bug Pattern

```typescript
// ❌ WRONG: Network call during auth
const response = await httpClient.get(`/api/v1/restaurants/slug/${slug}`);
const restaurantId = response.id;
// Problems:
// - Network failure blocks login
// - Slug middleware dependency
// - Race condition during auth

// ✅ CORRECT: Hardcoded for known restaurants
const RESTAURANT_MAP = {
  'grow': '11111111-1111-1111-1111-111111111111',
  'demo': '22222222-2222-2222-2222-222222222222'
};
const restaurantId = RESTAURANT_MAP[slug] || slug;
```

---

## Pattern Checklist

Before deploying auth changes:

- [ ] JWT includes ALL required fields (sub, email, role, scope, restaurant_id)
- [ ] Scopes fetched BEFORE JWT creation
- [ ] Middleware order: authenticate → validateRestaurantAccess → requireScopes
- [ ] localStorage session stored after login
- [ ] React state and httpClient.currentRestaurantId synced
- [ ] STRICT_AUTH=true tested locally
- [ ] Multi-tenancy validation enforced
- [ ] No Supabase direct auth for workspace login
- [ ] Slug-to-UUID hardcoded (no network call)
- [ ] Token expiry validation in httpClient

---

**Related**: [ADR-006](../../docs/explanation/architecture-decisions/ADR-006-dual-authentication-pattern.md), [ADR-010](../../docs/explanation/architecture-decisions/ADR-010-jwt-payload-standards.md)

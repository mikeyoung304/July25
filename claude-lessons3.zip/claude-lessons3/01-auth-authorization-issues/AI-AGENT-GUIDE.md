---
category: authentication-authorization
category_id: "01"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: AI-AGENT-GUIDE
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
anti_pattern_count: 5
decision_tree_count: 1
test_scenario_count: 5
tags: [ai-guide, debugging, anti-patterns, decision-tree, code-review-checklist]
critical_anti_patterns:
  - name: "Supabase Direct Auth for Workspace Login"
    severity: critical
    prevented_cost: 20000
  - name: "JWT Creation Before Scope Fetch"
    severity: critical
    prevented_cost: 48000
  - name: "Missing Restaurant ID in JWT"
    severity: critical
    prevented_cost: 20000
  - name: "Wrong Middleware Order"
    severity: high
    prevented_cost: 15000
  - name: "STRICT_AUTH=false in Production"
    severity: critical
    prevented_cost: 20000
key_files:
  - server/src/middleware/auth.ts
  - server/src/routes/auth.routes.ts
  - client/src/contexts/AuthContext.tsx
  - client/src/services/http/httpClient.ts
related_docs: [PATTERNS.md, INCIDENTS.md, PREVENTION.md, QUICK-REFERENCE.md]
historical_context: "3 complete rewrites over 4 months, $100K+ engineering cost"
---

# AI Agent Guide - Authentication & Authorization

**Purpose**: Instructions for AI assistants (Claude, GPT, etc.) debugging auth issues in Restaurant OS

---

## When Auth Issues Arise

### First: Check These 5 Things (In Order)

1. **JWT Structure** (Most Common Issue)
   ```bash
   # Decode the token from browser localStorage or Network tab
   echo "$TOKEN" | cut -d. -f2 | base64 -d | jq
   ```

   Required fields:
   - `sub` (user ID)
   - `email`
   - `role`
   - `scope` (array) ← Missing this caused 10-day outage
   - `restaurant_id` ← Missing this caused 48-day recurring issue
   - `iat`, `exp`

2. **STRICT_AUTH Setting** (Environment Parity)
   ```bash
   grep STRICT_AUTH server/.env
   # Must be 'true' (matching production)
   ```

3. **Middleware Order** (Most Common Bug Pattern)
   ```typescript
   // CORRECT order:
   router.post('/endpoint',
     authenticate,              // 1. First
     validateRestaurantAccess,  // 2. Second
     requireScopes([...]),      // 3. Third
     handler
   );
   ```

4. **localStorage Session** (Dual Auth Pattern)
   ```javascript
   localStorage.getItem('auth_session')
   // Should contain accessToken, expiresAt, restaurantId
   ```

5. **State Sync** (React + httpClient)
   ```typescript
   // Both must be set:
   setRestaurantId(id)                    // React state
   setCurrentRestaurantId(id)             // httpClient global
   ```

---

## Red Flags to Watch For

### 🚨 Critical Anti-Patterns

**Never Allow These:**

1. **Supabase Direct Auth for Workspace Login**
   ```typescript
   // ❌ NEVER use this for workspace login
   await supabase.auth.signInWithPassword({ email, password })
   // Returns JWT without restaurant_id and scope
   ```

2. **JWT Creation Before Scope Fetch**
   ```typescript
   // ❌ WRONG order
   const token = jwt.sign(payload, secret)
   const scopes = await fetchScopes(role)  // TOO LATE!

   // ✅ CORRECT order
   const scopes = await fetchScopes(role)
   const payload = { ..., scope: scopes }
   const token = jwt.sign(payload, secret)
   ```

3. **Missing Restaurant ID in JWT**
   ```typescript
   // ❌ Missing restaurant_id
   const payload = { sub, email, role, scope }

   // ✅ Must include restaurant_id
   const payload = { sub, email, role, scope, restaurant_id }
   ```

4. **Wrong Middleware Order**
   ```typescript
   // ❌ validateRestaurantAccess before authenticate
   router.post('/endpoint',
     validateRestaurantAccess,  // req.user is undefined!
     authenticate,
     handler
   );
   ```

5. **STRICT_AUTH=false in Production**
   ```bash
   # ❌ Production must have STRICT_AUTH=true
   # ❌ Local dev should match production
   ```

---

## Test Scenarios to Run

When making auth changes, run these tests:

### 1. JWT Structure Validation
```bash
npm run test -- auth/jwt-structure
# Verifies all required fields present
```

### 2. STRICT_AUTH Mode Test
```bash
STRICT_AUTH=true npm run test:server
# Must pass with STRICT_AUTH=true
```

### 3. Multi-Tenancy Security
```bash
npm run test -- security/multi-tenancy
# Verifies cross-tenant access blocked
```

### 4. Middleware Chain Order
```bash
npm run test -- middleware/auth-chain
# Verifies correct execution order
```

### 5. Login Flow Integration
```bash
npm run test:e2e -- auth
# End-to-end login + API call
```

---

## Common Debug Scenarios

### Scenario 1: "401 Unauthorized" on API Calls

**User reports**: "Login seems to work but all API calls fail with 401"

**Diagnosis Path**:
```typescript
// 1. Check if JWT stored
localStorage.getItem('auth_session')
// If null → Not storing session after login

// 2. Check JWT structure
const session = JSON.parse(localStorage.getItem('auth_session'))
const decoded = jwt.decode(session.session.accessToken)
// Missing fields? → JWT creation bug

// 3. Check httpClient state
httpClient.currentRestaurantId
// If undefined → State sync bug
```

**Most Likely Causes**:
1. JWT missing `scope` or `restaurant_id` field
2. localStorage session not stored after login
3. STRICT_AUTH=true but JWT missing restaurant_id

**Fix Location**: `/server/src/routes/auth.routes.ts:87-107` (JWT creation)

---

### Scenario 2: "Login Hangs Forever"

**User reports**: "Stuck at 'Signing in...' spinner"

**Diagnosis Path**:
```bash
# 1. Check browser Network tab
# Look for hanging request to /api/v1/auth/me

# 2. Check backend logs
# Look for validateRestaurantAccess timeout

# 3. Verify restaurant_id sync
# In browser console:
httpClient.currentRestaurantId  // Should not be undefined
```

**Most Likely Causes**:
1. React state not synced with httpClient.currentRestaurantId
2. Backend query timeout (missing restaurant_id filter)
3. Network issue (but less likely)

**Fix Location**: `/client/src/contexts/AuthContext.tsx` (5 locations need sync)

---

### Scenario 3: "Works Locally, Fails in Production"

**User reports**: "Login works on my machine but not deployed"

**Diagnosis Path**:
```bash
# 1. Check STRICT_AUTH setting
grep STRICT_AUTH server/.env  # Local
# Compare with production env var

# 2. Check JWT structure
# Decode token from both environments
# Production requires restaurant_id if STRICT_AUTH=true

# 3. Check auth endpoint usage
grep -r "supabase.auth.signInWithPassword" client/src/
# Should not be used for workspace login
```

**Most Likely Cause**: Environment drift (STRICT_AUTH mismatch)

**Fix**: Change local to STRICT_AUTH=true, test, then deploy

---

### Scenario 4: "403 Forbidden on Protected Routes"

**User reports**: "Manager can't access floor plan editor"

**Diagnosis Path**:
```typescript
// 1. Check middleware order in route definition
// File: /server/src/routes/tables.routes.ts
// Order should be: authenticate → validateRestaurantAccess → requireScopes

// 2. Check user role in JWT
const decoded = jwt.decode(token)
console.log(decoded.role)  // Should be 'manager'

// 3. Check scopes in JWT
console.log(decoded.scope)  // Should include 'tables:update'
```

**Most Likely Causes**:
1. Middleware wrong order (validateRestaurantAccess before authenticate)
2. JWT missing scope field
3. User doesn't have required scope in database

**Fix Locations**:
- Middleware order: Route definition file
- JWT scope: `/server/src/routes/auth.routes.ts:75-85`

---

## Links to Key Files

### Backend (Authentication)
- **Auth Middleware**: `/server/src/middleware/auth.ts`
  - Lines 23-115: JWT validation
  - Lines 84-92: STRICT_AUTH enforcement
  - Lines 233-258: requireScope function

- **Restaurant Access**: `/server/src/middleware/restaurantAccess.ts`
  - Lines 16-94: Multi-tenancy validation
  - Lines 52-68: Database query with timeout

- **Auth Routes**: `/server/src/routes/auth.routes.ts`
  - Lines 22-107: POST /api/v1/auth/login
  - Lines 75-85: Scope fetch (critical)
  - Lines 87-107: JWT creation

### Frontend (Authentication)
- **Auth Context**: `/client/src/contexts/AuthContext.tsx`
  - Lines 184-265: login() function
  - Lines 195-199: Slug-to-UUID resolution
  - Lines 227, 263, 315: Restaurant ID sync points

- **HTTP Client**: `/client/src/services/http/httpClient.ts`
  - Lines 109-148: Dual auth pattern (Supabase + localStorage)

---

## Decision Tree for Auth Bugs

```
Is login working?
├─ NO → Check JWT structure (missing fields?)
│       Check STRICT_AUTH setting
│       Check if using Supabase direct auth
│
└─ YES → Are API calls failing?
         ├─ YES → Check localStorage session stored
         │        Check httpClient.currentRestaurantId synced
         │        Check middleware order
         │
         └─ NO → Are some routes forbidden?
                  Check JWT scope field
                  Check middleware order
                  Check user permissions in database
```

---

## Code Review Checklist for AI Agents

When reviewing auth-related PRs, verify:

- [ ] No `supabase.auth.signInWithPassword()` for workspace login
- [ ] JWT payload includes ALL required fields
- [ ] Scopes fetched BEFORE `jwt.sign()`
- [ ] localStorage session stored after login
- [ ] `setCurrentRestaurantId()` called after `setRestaurantId()`
- [ ] Middleware order: authenticate → validateRestaurantAccess → requireScopes
- [ ] Tests pass with STRICT_AUTH=true
- [ ] Multi-tenancy validation enforced
- [ ] No test tokens or demo bypasses in production paths

---

## Historical Context (Important!)

### Why This Documentation Exists

The auth system had **3 complete rewrites** in 4 months:

1. **Phase 1** (July-Sept): Custom JWT + test tokens → Security issues
2. **Phase 2** (Oct): Pure Supabase → Couldn't support demo/PIN/voice
3. **Phase 3** (Nov): Dual auth pattern → Current stable system

**Total cost**: $100K+ engineering time, 70+ days of incidents

### Major Incidents

1. **CL-AUTH-001** (48 days): STRICT_AUTH environment drift
2. **JWT Scope Bug** (10 days): Missing scope field in JWT
3. **Restaurant ID Sync** (8 days): State management bug
4. **Middleware Ordering** (3 days): Wrong execution order
5. **Multi-tenancy Vuln** (1 day): Security vulnerability

**Lesson**: These patterns are documented to prevent recurrence. Follow them strictly.

---

## When to Escalate

Escalate to human developer if:

1. **New authentication method needed** (requires architecture decision)
2. **Security vulnerability discovered** (needs immediate attention)
3. **JWT payload structure change required** (breaking change)
4. **Multi-tenancy validation bypass found** (critical security)
5. **Environment variable changes needed** (deployment impact)

---

## Success Metrics

After auth fixes, verify:

- [ ] Login success rate > 99.5%
- [ ] Zero authentication loops
- [ ] All protected routes accessible with correct roles
- [ ] Multi-tenancy tests passing (24/24)
- [ ] Voice ordering functional
- [ ] Demo mode working
- [ ] PIN/station auth working

---

## Quick Commands for AI Agents

```bash
# Validate environment
npm run validate:auth-env

# Run auth test suite
npm run test:auth

# Test with STRICT_AUTH
STRICT_AUTH=true npm run test:server

# Decode JWT token
echo "$TOKEN" | cut -d. -f2 | base64 -d | jq

# Check middleware order
npm run test -- middleware/auth-chain

# Integration tests
npm run test:e2e -- auth
```

---

## Final Reminder for AI Agents

**The #1 Rule**: When debugging auth issues, ALWAYS check JWT structure first.

**90% of auth bugs** are caused by:
1. Missing JWT fields (scope or restaurant_id)
2. Environment parity issues (STRICT_AUTH)
3. State synchronization problems

**Check these before deep debugging.**

---

## Additional Resources

- [PATTERNS.md](./PATTERNS.md) - Implementation patterns
- [INCIDENTS.md](./INCIDENTS.md) - Historical incidents
- [PREVENTION.md](./PREVENTION.md) - Prevention strategies
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Rapid debugging
- [ADR-006](../../docs/explanation/architecture-decisions/ADR-006-dual-authentication-pattern.md) - Architecture decision
- [ADR-010](../../docs/explanation/architecture-decisions/ADR-010-jwt-payload-standards.md) - JWT standards
- [ADR-011](../../docs/explanation/architecture-decisions/ADR-011-authentication-evolution.md) - Evolution history

---

**Last Updated**: 2025-11-19 (following 3rd authentication rewrite)
**Maintainer**: Technical Lead
**AI Agent Version**: Optimized for Claude Code, GPT-4, and similar assistants

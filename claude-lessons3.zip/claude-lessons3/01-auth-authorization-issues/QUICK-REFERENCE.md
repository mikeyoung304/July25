---
category: authentication-authorization
category_id: "01"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: QUICK-REFERENCE
error_pattern_count: 12
tags: [debugging, troubleshooting, error-messages, quick-fixes]
common_errors:
  - error: "401: No token provided"
    frequency: high
    avg_resolution_time: "5 minutes"
  - error: "401: Token missing restaurant context"
    frequency: high
    avg_resolution_time: "15 minutes"
  - error: "401: Missing required scope"
    frequency: medium
    avg_resolution_time: "10 minutes"
  - error: "403: Access denied to restaurant"
    frequency: medium
    avg_resolution_time: "20 minutes"
  - error: "Authentication loop (modal forever)"
    frequency: low
    avg_resolution_time: "30 minutes"
key_files:
  - server/src/middleware/auth.ts
  - client/src/contexts/AuthContext.tsx
related_docs: [PATTERNS.md, INCIDENTS.md, AI-AGENT-GUIDE.md]
---

# Auth Quick Reference - Rapid Debugging Guide

## Common Error Messages → Fixes

### `401: No token provided`

**Cause**: localStorage session not set after login

**Check**:
```javascript
localStorage.getItem('auth_session')
// Should return JSON object with session.accessToken
```

**Fix**:
```typescript
// After successful login, store session
localStorage.setItem('auth_session', JSON.stringify({
  user: response.user,
  session: {
    accessToken: response.session.access_token,
    expiresAt: Date.now() / 1000 + response.session.expires_in
  },
  restaurantId: response.restaurantId
}));
```

---

### `401: Token missing restaurant context in strict auth mode`

**Cause**: JWT missing `restaurant_id` field, STRICT_AUTH=true

**Check**:
```bash
# Decode JWT token
echo "$TOKEN" | cut -d. -f2 | base64 -d | jq
# Look for "restaurant_id" field
```

**Fix**: Use custom auth endpoint instead of Supabase direct:
```typescript
// ❌ WRONG
await supabase.auth.signInWithPassword({ email, password });

// ✅ CORRECT
await httpClient.post('/api/v1/auth/login', {
  email, password, restaurantId
});
```

---

### `401: Missing required scope: orders:create`

**Cause**: JWT missing `scope` field

**Check**:
```bash
# Decode JWT and look for scope array
echo "$TOKEN" | cut -d. -f2 | base64 -d | jq .scope
```

**Fix**: Fetch scopes BEFORE creating JWT
```typescript
// ✅ CORRECT ORDER
const scopes = await fetchScopes(role);
const payload = { ..., scope: scopes };  // Include in JWT
const token = jwt.sign(payload, secret);
```

**Location**: `/server/src/routes/auth.routes.ts:75-100`

---

### `403: Access denied to this restaurant`

**Cause**: User doesn't have access to requested restaurant

**Check**:
```sql
-- Verify user_restaurants entry
SELECT * FROM user_restaurants
WHERE user_id = 'user-uuid'
  AND restaurant_id = 'restaurant-uuid';
```

**Fix**: Grant access in database or check correct restaurant ID being sent

---

### Authentication modal loop (forever loading)

**Cause**: Supabase JWT incompatible with STRICT_AUTH

**Check**:
```bash
# Check backend environment
grep STRICT_AUTH server/.env
# Should be 'true'
```

**Fix**: Switch to custom auth endpoint (see CL-AUTH-001)

---

### Login hangs at "Signing in..."

**Cause**: React state not synced with httpClient.currentRestaurantId

**Check**:
```typescript
// In browser console after login attempt
httpClient.currentRestaurantId
// Should return restaurant UUID, not undefined
```

**Fix**: Add sync call after setting restaurant ID
```typescript
setRestaurantId(response.restaurantId);
setCurrentRestaurantId(response.restaurantId);  // Add this
```

**Location**: `/client/src/contexts/AuthContext.tsx` (5 locations)

---

## Correct Middleware Order

```typescript
router.post('/endpoint',
  authenticate,                    // 1. FIRST - Validate JWT
  validateRestaurantAccess,        // 2. SECOND - Check tenant access
  requireScopes(['scope:action']), // 3. THIRD - Check permissions
  handler
);
```

**Wrong Order = 401 Errors**

---

## JWT Structure Template

```json
{
  "sub": "user-uuid",
  "email": "user@example.com",
  "role": "server",
  "scope": ["orders:create", "orders:read"],
  "restaurant_id": "11111111-1111-1111-1111-111111111111",
  "auth_method": "email",
  "iat": 1700000000,
  "exp": 1700028800
}
```

**Missing ANY field = Auth failure**

---

## Testing Commands

### Validate environment
```bash
npm run validate:auth-env
```

### Test JWT structure
```bash
npm run test -- auth/jwt-structure
```

### Test with STRICT_AUTH=true
```bash
STRICT_AUTH=true npm run test:server
```

### Test middleware chain
```bash
npm run test -- middleware/auth-chain
```

### Full auth test suite
```bash
npm run test:auth
```

### Integration tests
```bash
npm run test:e2e -- auth
```

---

## Debug JWT Token

```bash
# Decode JWT (get from browser localStorage or Network tab)
echo "eyJhbG..." | cut -d. -f2 | base64 -d | jq

# Check required fields
echo "eyJhbG..." | cut -d. -f2 | base64 -d | jq '{
  has_sub: (has("sub")),
  has_email: (has("email")),
  has_role: (has("role")),
  has_scope: (has("scope")),
  has_restaurant_id: (has("restaurant_id"))
}'

# Verify scope array
echo "eyJhbG..." | cut -d. -f2 | base64 -d | jq '.scope | type'
# Should output: "array"

# Check expiry
echo "eyJhbG..." | cut -d. -f2 | base64 -d | jq '.exp'
# Compare with current timestamp: date +%s
```

---

## File Locations (Quick Access)

| Component | File Path | Key Lines |
|-----------|-----------|-----------|
| Auth middleware | `/server/src/middleware/auth.ts` | 23-115 |
| Restaurant access | `/server/src/middleware/restaurantAccess.ts` | 16-94 |
| Login endpoint | `/server/src/routes/auth.routes.ts` | 22-107 |
| Frontend auth | `/client/src/contexts/AuthContext.tsx` | 184-375 |
| httpClient dual auth | `/client/src/services/http/httpClient.ts` | 109-148 |
| STRICT_AUTH check | `/server/src/middleware/auth.ts` | 84-92 |
| JWT creation | `/server/src/routes/auth.routes.ts` | 87-107 |

---

## Environment Variables

### Required (Both Local and Production)

```bash
# Backend (.env)
STRICT_AUTH=true
SUPABASE_JWT_SECRET=your-secret-here
KIOSK_JWT_SECRET=your-secret-here

# Frontend (.env)
VITE_API_BASE_URL=http://localhost:3001
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

### Check Environment

```bash
# Verify STRICT_AUTH is true
grep STRICT_AUTH server/.env

# Verify secrets are set
grep JWT_SECRET server/.env

# Validate all auth environment variables
npm run validate:auth-env
```

---

## Restaurant ID Resolution

### Hardcoded Mapping (Single Restaurant)

```typescript
const GROW_RESTAURANT_UUID = '11111111-1111-1111-1111-111111111111';

// Resolve slug to UUID
const resolvedRestaurantId = restaurantId === 'grow'
  ? GROW_RESTAURANT_UUID
  : restaurantId;
```

**Location**: `/client/src/contexts/AuthContext.tsx:195-199`

**Why hardcoded?** Avoids network call during login (potential failure point)

---

## State Sync Pattern

### The Two Places to Update

```typescript
// 1. React state (for UI)
setRestaurantId(id);

// 2. httpClient global state (for API calls)
setCurrentRestaurantId(id);
```

### Where to Add Sync (5 Locations)

1. Session restoration - Line 82
2. Auth state change - Line 152
3. Email/password login - Line 227
4. PIN login - Line 263
5. Station login - Line 315

**File**: `/client/src/contexts/AuthContext.tsx`

---

## Authentication Flow Checklist

- [ ] 1. User submits credentials
- [ ] 2. Frontend calls POST `/api/v1/auth/login`
- [ ] 3. Backend validates with Supabase
- [ ] 4. Backend fetches user role from `user_restaurants`
- [ ] 5. Backend fetches scopes from `role_scopes` (BEFORE JWT)
- [ ] 6. Backend creates JWT with all required fields
- [ ] 7. Backend returns user + session + restaurantId
- [ ] 8. Frontend stores in localStorage
- [ ] 9. Frontend syncs with Supabase
- [ ] 10. Frontend updates React state
- [ ] 11. Frontend syncs httpClient.currentRestaurantId
- [ ] 12. Navigate to dashboard

**If ANY step fails, login hangs or returns 401**

---

## Browser Console Debugging

```javascript
// Check if session stored
localStorage.getItem('auth_session')

// Parse and inspect
JSON.parse(localStorage.getItem('auth_session'))

// Check httpClient state
httpClient.currentRestaurantId

// Check Supabase session
supabase.auth.getSession().then(({ data }) => console.log(data))

// Decode JWT token
const token = JSON.parse(localStorage.getItem('auth_session')).session.accessToken
const [header, payload, signature] = token.split('.')
JSON.parse(atob(payload))
```

---

## Quick Fix Commands

### Reset auth state (development)
```javascript
// Browser console
localStorage.removeItem('auth_session')
localStorage.clear()
location.reload()
```

### Regenerate JWT with correct structure
```bash
# Run migration to update role_scopes
npm run db:push

# Restart server to pick up changes
npm run dev:server
```

### Fix STRICT_AUTH mismatch
```bash
# Update local .env
echo "STRICT_AUTH=true" >> server/.env

# Restart server
npm run dev:server
```

---

## Incident Reference

| Issue | Incident ID | Fix Commit | Docs |
|-------|-------------|------------|------|
| STRICT_AUTH mismatch | CL-AUTH-001 | 9e97f720 | [Link](../../claudelessons-v2/knowledge/incidents/CL-AUTH-001-supabase-direct-auth-strict-mode.md) |
| JWT scope missing | (10-day bug) | 4fd9c9d2 | [ADR-010](../../docs/explanation/architecture-decisions/ADR-010-jwt-payload-standards.md) |
| Restaurant ID sync | (Login hang) | acd6125c | [INCIDENTS.md](./INCIDENTS.md) |
| Middleware ordering | (Manager blocked) | 38f7bba0 | [INCIDENTS.md](./INCIDENTS.md) |
| Multi-tenancy vuln | (Security) | df228afd | [INCIDENTS.md](./INCIDENTS.md) |

---

## Emergency Contacts

- **ADR-006**: Dual Authentication Pattern
- **ADR-010**: JWT Payload Standards
- **ADR-011**: Authentication Evolution (3 rewrites)
- **CL-AUTH-001**: Primary incident documentation

---

## One-Line Fixes

```bash
# Missing restaurant_id in JWT
# Fix: Use custom auth endpoint, not Supabase direct

# Missing scope in JWT
# Fix: Fetch scopes before jwt.sign()

# localStorage session not set
# Fix: localStorage.setItem('auth_session', ...)

# httpClient not synced
# Fix: setCurrentRestaurantId(restaurantId)

# Wrong middleware order
# Fix: authenticate → validateRestaurantAccess → requireScopes

# STRICT_AUTH mismatch
# Fix: STRICT_AUTH=true in local .env
```

---

**When in doubt**: Check JWT structure first (decode token), then check STRICT_AUTH setting.

---
category: "api-integration"
category_id: "07"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, openai, square, timeouts, model-changes, audit-logging]
---
# AI Agent Guide - API Integration Best Practices

**Created:** 2025-11-19
**Audience:** AI coding assistants (Claude, GPT-4, etc.)
**Purpose:** Prevent repeating $20K+ in API integration mistakes

---

## Critical Context

This guide is based on **168 API integration bug fixes** over 6 months, costing **$21,150+** in debugging time. The patterns documented here are proven solutions from production incidents.

**If you're an AI agent helping with code, read this entire guide before suggesting API integration changes.**

---

## Rule 1: ALWAYS Add Timeouts to External API Calls

### Why This Matters

**Cost of Violation:** $1,800 (12 hours debugging Square payment hangs)

**Incident:** Customers waiting indefinitely at payment screen because Square API calls had no timeout protection.

### The Rule

**Every external API call MUST have a timeout.** No exceptions.

```typescript
// ❌ NEVER DO THIS
const result = await externalApi.call();

// ✅ ALWAYS DO THIS
const result = await withTimeout(
  externalApi.call(),
  30000,  // 30 seconds
  'External API call'
);
```

### Default Timeout Values

```typescript
const TIMEOUTS = {
  PAYMENT_OPERATIONS: 30000,   // Square: payment, refund
  DATABASE_QUERIES: 5000,      // Supabase: detect hangs
  REALTIME_SESSIONS: 60000,    // OpenAI: WebRTC setup
  FILE_UPLOADS: 120000,        // Large file operations
  API_HEALTH_CHECKS: 10000     // Quick validation
};
```

### Implementation Template

```typescript
async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number,
  operation: string
): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(
        () => reject(new Error(`${operation} timed out after ${timeoutMs}ms`)),
        timeoutMs
      )
    )
  ]);
}
```

### When to Suggest This

- Any `await fetch()` call to external APIs
- Any SDK method call (Square, OpenAI, Stripe, etc.)
- Any database query that could hang
- Any WebSocket or WebRTC connection setup

---

## Rule 2: Log BEFORE External API Calls, Not After

### Why This Matters

**Cost of Violation:** $1,500 (10 hours debugging Square audit race condition)

**Incident:** Customers charged but system showed error because audit log happened AFTER payment processing.

### The Rule

**Always log intent BEFORE making external API calls.** This enables forensic analysis and prevents "charged but unrecorded" scenarios.

```typescript
// ❌ NEVER DO THIS: Log after API call
const payment = await paymentsApi.create(request);
await logAudit({ status: 'success', paymentId: payment.id });

// ✅ ALWAYS DO THIS: Two-phase logging
// Phase 1: Log before API call
const auditId = await logAudit({ status: 'initiated', orderId, amount });

// Phase 2: Make API call
try {
  const payment = await withTimeout(
    paymentsApi.create(request),
    30000,
    'Payment creation'
  );

  // Phase 3: Update audit log
  await updateAudit(auditId, { status: 'success', paymentId: payment.id });
} catch (error) {
  await updateAudit(auditId, { status: 'failed', error: error.message });
  throw error;
}
```

### Audit Status Flow

```
initiated → (API call) → success
                      ↓
                    failed
```

### When to Suggest This

- Payment processing (credit card, cash, refunds)
- Order creation/updates
- Inventory adjustments
- Any operation with financial implications
- Any operation with compliance requirements (PCI DSS, GDPR)

---

## Rule 3: Check Provider Changelogs Before Debugging

### Why This Matters

**Cost of Violation:** $1,200 (8 hours debugging OpenAI whisper-1 deprecation)

**Incident:** Voice ordering completely broken because OpenAI silently deprecated `whisper-1` model for Realtime API. The API accepted the old config but ignored it, causing 8 hours of debugging.

### The Rule

**Before debugging API integration issues, check provider changelogs for breaking changes.**

### Silent API Change Red Flags

- Feature was working last week/month, now broken
- API accepts config but behavior changed
- No error messages or status codes
- Everything else works except one specific feature

### Provider Changelog URLs

```typescript
const CHANGELOGS = {
  OPENAI: 'https://platform.openai.com/docs/changelog',
  SQUARE: 'https://developer.squareup.com/blog',
  SUPABASE: 'https://supabase.com/changelog',
  STRIPE: 'https://stripe.com/docs/upgrades',
  VERCEL: 'https://vercel.com/changelog'
};
```

### What to Look For

- Keywords: "deprecat", "breaking", "removed", "discontinued", "sunset"
- Date ranges: When did the feature stop working?
- Migration guides: Provider instructions for updating
- Community forums: Other developers reporting same issue

### When to Suggest This

- API integration suddenly stops working
- No code changes on our side
- No clear error messages
- Working code from git history no longer works

---

## Rule 4: Trim Environment Variables at Startup

### Why This Matters

**Cost of Violation:** $600 (4 hours debugging voice ordering with newline in API key)

**Incident:** Voice ordering button did nothing because `OPENAI_API_KEY` contained `\n` from Vercel CLI. OpenAI API rejected malformed Authorization header with 401/403.

### The Rule

**Always trim environment variables at startup** to remove newlines, spaces, and other whitespace from CLI tools.

```typescript
// ❌ NEVER DO THIS: Use raw process.env
const apiKey = process.env['OPENAI_API_KEY'];

// ✅ ALWAYS DO THIS: Trim at startup
const getString = (key: string, fallback = ''): string => {
  const value = process.env[key];
  const trimmed = value?.trim();  // Remove newlines/whitespace
  return trimmed !== undefined && trimmed !== '' ? trimmed : fallback;
};

const apiKey = getString('OPENAI_API_KEY');
```

### Validation at Startup

```typescript
// Detect malformed keys at startup
if (apiKey.includes('\n') || apiKey.includes('\\n') || apiKey.includes('\r')) {
  throw new Error(
    `Environment variable OPENAI_API_KEY contains invalid characters. ` +
    `This may be caused by CLI tools. Fix: Use "echo -n" when setting.`
  );
}
```

### When to Suggest This

- Any code reading environment variables
- Any startup validation logic
- Any health check endpoints
- Any config modules

---

## Rule 5: Test with Production API Keys

### Why This Matters

**Cost of Violation:** 8+ hours across multiple incidents

**Lesson:** Mock data hides API integration issues. Always test critical flows with real provider APIs.

### The Rule

**Test critical flows with production API keys in staging environment.**

### What to Test

```typescript
// Payment flow: Card → Square → Success
test('Payment flow with real Square API', async () => {
  // Use sandbox/test credentials
  const result = await createPayment({
    amount: 100,  // $1.00
    cardNonce: 'cnon:card-nonce-ok'  // Square test nonce
  });

  expect(result.status).toBe('COMPLETED');
});

// Voice ordering: Audio → OpenAI → Transcription
test('Voice transcription with real OpenAI API', async () => {
  const session = await openai.createRealtimeSession();
  const transcript = await session.transcribe(testAudio);

  expect(transcript).toBeTruthy();
});
```

### When to Suggest This

- Adding new API integration
- Updating API SDK versions
- After provider announces changes
- Weekly smoke tests in staging

---

## Rule 6: Attach Event Handlers BEFORE Event Sources

### Why This Matters

**Cost of Violation:** $1,050 (7 hours debugging voice WebRTC race condition)

**Incident:** DataChannel `onmessage` handler attached 50-100ms after channel opened, losing initial events (session.created) and causing cascade failures.

### The Rule

**Always attach event handlers synchronously BEFORE creating/opening event sources.**

```typescript
// ❌ NEVER DO THIS: Handler attached after source created
const channel = peer.createDataChannel('data');
// 50-100ms delay here...
channel.onmessage = (event) => {
  // Too late - initial messages lost
  handleMessage(event);
};

// ✅ ALWAYS DO THIS: Handler attached before source opens
const channel = peer.createDataChannel('data');
channel.onmessage = (event) => {
  // Ready for first message
  handleMessage(event);
};
channel.onopen = () => {
  console.log('Channel opened');
};
```

### Race Condition Timing

```
❌ Bad Timeline:
0ms:    createDataChannel()
0ms:    onopen fires
50ms:   onmessage attached  ← TOO LATE
100ms:  First event lost

✅ Good Timeline:
0ms:    createDataChannel()
0ms:    onmessage attached  ← READY
0ms:    onopen fires
100ms:  First event captured
```

### When to Suggest This

- WebSocket connections
- WebRTC data channels
- Server-Sent Events (SSE)
- Event emitters
- Observable subscriptions

---

## Rule 7: Sync State Across All Systems

### Why This Matters

**Cost of Violation:** $3,600 (24 hours debugging auth token synchronization)

**Incident:** Login hung at "Signing in..." because React state updated but httpClient state not synced, causing API calls to miss `X-Restaurant-ID` header.

### The Rule

**When updating state, sync ALL systems that depend on it.** Never update one system and forget others.

```typescript
// ❌ NEVER DO THIS: Only update React state
setRestaurantId(response.restaurantId);

// ✅ ALWAYS DO THIS: Sync all state systems
setRestaurantId(response.restaurantId);
httpClient.setRestaurantId(response.restaurantId);
localStorage.setItem('restaurantId', response.restaurantId);

// Verify sync
logger.info('Restaurant ID updated', {
  reactState: restaurantId,
  httpClient: httpClient.currentRestaurantId,
  localStorage: localStorage.getItem('restaurantId'),
  allSynced: restaurantId === httpClient.currentRestaurantId
});
```

### State Systems to Consider

- React state (useState, context)
- Global stores (Redux, Zustand, etc.)
- HTTP clients (axios, fetch wrappers)
- localStorage/sessionStorage
- Cookies
- URL parameters

### When to Suggest This

- Authentication state changes
- User profile updates
- Multi-tenancy (restaurant_id, tenant_id)
- Any state used across components/services

---

## Rule 8: Add Retry Logic for Transient Failures

### Why This Matters

**Cost of Violation:** Multiple hours across various incidents

**Lesson:** Networks are unreliable. APIs have temporary outages. Retry transient failures.

### The Rule

**Add retry logic with exponential backoff for network errors and 5xx server errors.** Do NOT retry 4xx client errors.

```typescript
async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  baseDelayMs: number = 1000
): Promise<T> {
  let lastError: Error;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;

      // Don't retry client errors (4xx)
      if (error.statusCode >= 400 && error.statusCode < 500) {
        throw error;
      }

      if (attempt === maxRetries - 1) break;

      // Exponential backoff: 1s, 2s, 4s
      const delayMs = baseDelayMs * Math.pow(2, attempt);
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }

  throw lastError;
}
```

### Retry Decision Matrix

| Error Type | Retry? | Max Retries | Backoff |
|------------|--------|-------------|---------|
| Network timeout | Yes | 3 | Exponential |
| 5xx Server error | Yes | 3 | Exponential |
| 429 Rate limit | Yes | 5 | Linear + header |
| 4xx Client error | No | 0 | N/A |
| 401 Auth error | No | 0 | N/A |

### When to Suggest This

- Network requests to external APIs
- Database queries under load
- File operations over network
- Any operation with transient failure modes

---

## Rule 9: Validate Payload Before Sending

### Why This Matters

**Cost of Violation:** Multiple hours debugging invalid payloads

**Lesson:** External APIs have strict requirements (length limits, formats, enums). Validate before sending.

### The Rule

**Validate payloads client-side and server-side before making external API calls.**

```typescript
import { z } from 'zod';

// Define schema
const PaymentSchema = z.object({
  amount: z.number().positive().max(100000),  // $1000 max
  idempotencyKey: z.string().max(45),  // Square limit
  currency: z.enum(['USD']),
  orderSource: z.enum(['kiosk', 'online', 'server'])
});

// Validate before API call
const validated = PaymentSchema.parse(request);
const result = await paymentsApi.create(validated);
```

### Provider-Specific Limits

```typescript
const PROVIDER_LIMITS = {
  SQUARE: {
    IDEMPOTENCY_KEY_MAX_LENGTH: 45,
    AMOUNT_MIN: 1,  // 1 cent
    AMOUNT_MAX: 100000000  // $1M
  },
  OPENAI: {
    MAX_TOKENS: 4096,
    MAX_MESSAGES: 100,
    MAX_TOOLS: 128
  },
  SUPABASE: {
    MAX_ROWS_PER_REQUEST: 1000,
    MAX_PAYLOAD_SIZE: 10485760  // 10MB
  }
};
```

### When to Suggest This

- Payment processing
- API calls with length limits
- API calls with enum values
- API calls with format requirements (dates, UUIDs, etc.)

---

## Rule 10: Monitor and Alert

### Why This Matters

**Cost of Violation:** Issues discovered by customers instead of monitoring

**Lesson:** Proactive monitoring catches issues before they impact customers.

### The Rule

**Add health checks, metrics, and alerts for all external API integrations.**

### Health Check Template

```typescript
router.get('/health', async (req, res) => {
  const checks = {
    timestamp: new Date().toISOString(),
    status: 'healthy',
    checks: {
      database: false,
      openai: false,
      square: false
    }
  };

  // Check each dependency
  try {
    await supabase.from('restaurants').select('id').limit(1);
    checks.checks.database = true;
  } catch {
    checks.status = 'unhealthy';
  }

  // Return status
  const statusCode = checks.status === 'healthy' ? 200 : 503;
  res.status(statusCode).json(checks);
});
```

### Alert Conditions

```typescript
const ALERT_THRESHOLDS = {
  ERROR_RATE: 0.10,      // Alert if >10% errors
  TIMEOUT_RATE: 0.05,    // Alert if >5% timeouts
  STALE_AUDIT_LOGS: 5,   // Alert if logs >5 minutes old
  CIRCUIT_BREAKER_OPEN: true  // Alert immediately
};
```

### When to Suggest This

- Adding new API integration
- New critical feature (payments, auth, etc.)
- After incident resolution (prevent recurrence)
- Production deployments

---

## Common Mistakes to Avoid

### Mistake 1: Assuming APIs Are Reliable

```typescript
// ❌ WRONG: No error handling
const result = await api.call();
return result.data;

// ✅ CORRECT: Expect failures
try {
  const result = await withTimeout(
    withRetry(() => api.call()),
    30000,
    'API call'
  );
  return result.data;
} catch (error) {
  logger.error('API call failed', { error });
  throw new Error('Service temporarily unavailable');
}
```

### Mistake 2: Using Mock Data in Integration Tests

```typescript
// ❌ WRONG: Mock hides API issues
jest.mock('square-sdk', () => ({
  paymentsApi: {
    create: jest.fn().mockResolvedValue({ status: 'COMPLETED' })
  }
}));

// ✅ CORRECT: Test with real API (sandbox)
test('Payment with real Square sandbox API', async () => {
  const result = await createPayment({
    amount: 100,
    cardNonce: 'cnon:card-nonce-ok'
  });
  expect(result.status).toBe('COMPLETED');
});
```

### Mistake 3: Silent Error Handling

```typescript
// ❌ WRONG: Swallow errors silently
try {
  await api.call();
} catch (error) {
  // Silent failure - no one knows it failed
}

// ✅ CORRECT: Log and re-throw
try {
  await api.call();
} catch (error) {
  logger.error('API call failed', { error });
  throw error;  // Let caller handle
}
```

### Mistake 4: No Monitoring

```typescript
// ❌ WRONG: No visibility into API health
const result = await api.call();

// ✅ CORRECT: Track metrics
const startTime = Date.now();
try {
  const result = await api.call();
  metrics.record('api_call', {
    provider: 'square',
    latency: Date.now() - startTime,
    success: true
  });
} catch (error) {
  metrics.record('api_call', {
    provider: 'square',
    latency: Date.now() - startTime,
    success: false,
    error: error.message
  });
  throw error;
}
```

---

## Code Review Checklist

When reviewing API integration code, verify:

- [ ] Timeout added to external API calls (30s default)
- [ ] Audit logging BEFORE external API calls
- [ ] Retry logic for transient failures (3 retries, exponential backoff)
- [ ] Environment variables trimmed at startup
- [ ] Payload validation before sending
- [ ] Event handlers attached before event sources
- [ ] State synced across all systems
- [ ] Error handling logs and re-throws
- [ ] Health check endpoint includes new dependency
- [ ] Metrics tracked (calls, errors, timeouts, latency)
- [ ] Alert conditions defined (error rate, timeout rate)
- [ ] Integration tests use real API (sandbox/staging)

---

## Emergency Response

### Symptom: API Calls Hanging

**Check:**
1. Timeout wrapper applied?
2. Provider status page (downtime?)
3. Network connectivity
4. Environment variables (newlines?)

**Quick Fix:**
```typescript
const result = await withTimeout(apiCall(), 30000, 'API call');
```

### Symptom: Silent API Failure

**Check:**
1. Provider changelog (breaking changes?)
2. API version/model deprecation
3. Error logs (status codes?)
4. Payload validation (missing fields?)

**Quick Fix:**
```bash
# Check provider changelog
curl https://platform.openai.com/docs/changelog
```

### Symptom: Race Condition

**Check:**
1. Event handlers attached before sources?
2. State updates in correct order?
3. Timing logs (when did events fire?)

**Quick Fix:**
```typescript
// Attach handler BEFORE creating source
source.onmessage = handler;  // First
source.open();  // Second
```

---

## Summary: The 10 Rules

1. **ALWAYS add timeouts** (30s default)
2. **Log BEFORE external APIs** (two-phase audit)
3. **Check provider changelogs** (before debugging)
4. **Trim environment variables** (at startup)
5. **Test with production API keys** (in staging)
6. **Attach handlers BEFORE sources** (prevent race conditions)
7. **Sync state across systems** (React, httpClient, localStorage)
8. **Add retry logic** (exponential backoff)
9. **Validate payloads** (before sending)
10. **Monitor and alert** (health checks, metrics)

---

## Related Documentation

- [README.md](./README.md) - Executive summary
- [PATTERNS.md](./PATTERNS.md) - Detailed API patterns
- [INCIDENTS.md](./INCIDENTS.md) - Real incident reports
- [PREVENTION.md](./PREVENTION.md) - Monitoring strategies
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Copy-paste code

---

**Last Updated:** 2025-11-19
**Based on:** 168 bug fixes, $21,150 in debugging costs
**Maintainer:** Technical Lead

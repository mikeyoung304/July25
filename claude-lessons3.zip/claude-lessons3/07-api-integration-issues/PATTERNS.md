---
category: "api-integration"
category_id: "07"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "PATTERNS"
tags: [openai, square, timeouts, model-changes, audit-logging]
---
# API Integration Patterns - Lessons from 168 Bug Fixes

**Created:** 2025-11-19
**Category:** Technical Patterns
**Source:** 6 months of production incidents (June-November 2025)

---

## Core Principles

### 1. Never Trust External APIs
- Providers change APIs without notice
- Networks fail unpredictably
- Timeouts must be explicit
- Silent failures are common

### 2. Log Before, Not After
- Log intent before external calls
- Update logs with results
- Enables forensic analysis
- Prevents "charged but unrecorded" scenarios

### 3. Fail Fast and Loud
- Timeout errors must throw
- Silent failures are bugs
- Customers prefer errors over infinite waits
- Monitoring depends on visible failures

---

## Pattern 1: Timeout Handling

### The Problem
```typescript
// ❌ DANGEROUS: No timeout protection
const paymentResult = await paymentsApi.create(paymentRequest);
```

**Consequences:**
- Customer waits forever
- Browser tab hangs
- No error feedback
- Cannot retry or cancel

### The Solution
```typescript
// ✅ SAFE: 30-second timeout wrapper
async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number = 30000,
  operation: string = 'API call'
): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(
        () => reject(new Error(`${operation} timed out after ${timeoutMs}ms`)),
        timeoutMs
      )
    )
  ]);
}

// Usage
const paymentResult = await withTimeout(
  paymentsApi.create(paymentRequest),
  30000,
  'Square payment creation'
);
```

### Timeout Values (Production-Tested)

| Operation | Timeout | Rationale |
|-----------|---------|-----------|
| Payment creation | 30s | Network + processing time |
| Payment retrieval | 30s | Lookup + response time |
| Refund processing | 30s | API call + validation |
| Database queries | 5s | Fast queries, detect hangs |
| Real-time session | 60s | WebRTC connection establishment |
| File uploads | 120s | Large files, slow networks |

### Real-World Example: Square Payment Timeout

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/server/src/routes/payments.routes.ts:38-64`

**Commit:** cf7d9320 (November 10, 2025)

```typescript
// Before: Customers waited indefinitely
paymentResult = await paymentsApi.create(paymentRequest);

// After: 30-second timeout prevents hangs
paymentResult = await withTimeout(
  paymentsApi.create(paymentRequest),
  30000,
  'Square payment creation'
);
```

**Impact:** Eliminated infinite waits, improved customer experience

---

## Pattern 2: Two-Phase Audit Logging

### The Problem
```typescript
// ❌ DANGEROUS: Log AFTER external API call
const paymentResult = await paymentsApi.create(paymentRequest);

await PaymentService.logPaymentAttempt({
  status: 'success',
  paymentId: paymentResult.payment.id
});
```

**Consequences:**
- Customer charged, audit log fails
- System shows error, customer confused
- No record of payment attempt
- Revenue reconciliation issues

### The Solution
```typescript
// ✅ SAFE: Two-phase audit logging

// Phase 1: Log BEFORE external API call
await PaymentService.logPaymentAttempt({
  orderId: order_id,
  status: 'initiated',  // NEW: Pre-charge status
  restaurantId: restaurantId,
  amount: validation.orderTotal,
  idempotencyKey: serverIdempotencyKey
});

// Phase 2: Make API call (safe to fail now)
const paymentResult = await withTimeout(
  paymentsApi.create(paymentRequest),
  30000,
  'Square payment creation'
);

// Phase 3: Update audit log with result
await PaymentService.updatePaymentAuditStatus(
  serverIdempotencyKey,
  paymentResult.payment?.status === 'COMPLETED' ? 'success' : 'failed',
  paymentResult.payment.id
);
```

### Audit Status Flow

```
initiated → (API call) → success
                      ↓
                    failed
```

### Real-World Example: Square Audit Race Condition

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/server/src/routes/payments.routes.ts:233-299`

**Commit:** dc8afec6 (November 10, 2025)

**Before:**
1. Charge customer (line 215)
2. Update order status (line 233)
3. Log audit (line 244) ← **FAILS HERE**
4. Throw error to client
5. Customer charged but system shows error

**After:**
1. Log audit status='initiated' ← **FAILS EARLY**
2. Charge customer (safe now)
3. Update audit status='success'

**Impact:** Eliminated "charged but unrecorded" scenario

---

## Pattern 3: Environment Variable Validation

### The Problem
```typescript
// ❌ DANGEROUS: No validation, silent failures
const apiKey = process.env['OPENAI_API_KEY'];
const response = await fetch('https://api.openai.com/...', {
  headers: { 'Authorization': `Bearer ${apiKey}` }
});
```

**Consequences:**
- Missing keys fail in production
- Newline characters from CLI tools
- 401/403 errors with no context
- Hours debugging config issues

### The Solution
```typescript
// ✅ SAFE: Validate at startup + trim whitespace

// 1. Trim all environment variables
const getString = (key: string, fallback = ''): string => {
  const value = process.env[key];
  const trimmed = value?.trim();  // Remove newlines from CLI
  return trimmed !== undefined && trimmed !== '' ? trimmed : fallback;
};

// 2. Validate required keys at startup
const validateRequiredEnvVars = () => {
  const required = [
    'OPENAI_API_KEY',
    'SQUARE_ACCESS_TOKEN',
    'SUPABASE_SERVICE_KEY'
  ];

  for (const key of required) {
    const value = getString(key);
    if (!value) {
      throw new Error(`Missing required environment variable: ${key}`);
    }

    // Detect malformed keys (newlines from CLI)
    if (value.includes('\n') || value.includes('\\n') || value.includes('\r')) {
      throw new Error(
        `Environment variable ${key} contains invalid characters (newlines). ` +
        `This may be caused by CLI tools. Fix: Use "echo -n" when setting variables.`
      );
    }
  }
};

// 3. Run validation before starting server
validateRequiredEnvVars();
```

### Real-World Example: OpenAI API Key with Newlines

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/server/src/config/env.ts:10-23`

**Commit:** 03011ced (November 7, 2025)

**Problem:**
```bash
# ❌ WRONG: Adds newline to environment variable
echo "sk-proj-..." | vercel env add OPENAI_API_KEY production

# Result: OPENAI_API_KEY="sk-proj-...\n"
```

**Solution:**
```bash
# ✅ CORRECT: No newline added
echo -n "sk-proj-..." | vercel env add OPENAI_API_KEY production

# Result: OPENAI_API_KEY="sk-proj-..."
```

**Impact:** Voice ordering worked after deployment

---

## Pattern 4: Race Condition Prevention

### The Problem
```typescript
// ❌ DANGEROUS: Handler attached after event source opens
const dataChannel = peerConnection.createDataChannel('openai-realtime');

// 50-100ms delay here...
dataChannel.onopen = () => {
  console.log('DataChannel opened');
};

dataChannel.onmessage = (event) => {
  // Handler attached AFTER channel opens
  // Initial messages (session.created) are LOST
  handleMessage(event);
};
```

**Consequences:**
- First events lost (session.created)
- Cascade failures (missing transcript map entries)
- State machine deadlocks
- Transcription silently fails

### The Solution
```typescript
// ✅ SAFE: Attach handlers BEFORE creating event source
const setupDataChannel = () => {
  const dataChannel = peerConnection.createDataChannel('openai-realtime');

  // Attach handlers IMMEDIATELY (before onopen can fire)
  dataChannel.onmessage = (event) => {
    // Handler ready for first message
    handleMessage(event);
  };

  dataChannel.onopen = () => {
    console.log('DataChannel opened');
    // All messages will be captured now
  };

  return dataChannel;
};
```

### Race Condition Timing

```
Timeline (Before Fix):
0ms:    createDataChannel()
0ms:    dataChannel.onopen fires
50ms:   dataChannel.onmessage attached  ← TOO LATE
100ms:  session.created event lost
500ms:  conversation.item.created lost
1000ms: State machine deadlock

Timeline (After Fix):
0ms:    createDataChannel()
0ms:    dataChannel.onmessage attached  ← READY
0ms:    dataChannel.onopen fires
100ms:  session.created event captured
500ms:  conversation.item.created captured
1000ms: Normal operation
```

### Real-World Example: Voice WebRTC Race Condition

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/client/src/modules/voice/services/WebRTCConnection.ts:412-418`

**Commit:** 500b820c (November 10, 2025)

**Before:**
- Handler attached in VoiceEventHandler (separate class)
- 50-100ms delay between channel creation and handler attachment
- Lost session.created events
- Transcript map never populated
- Transcription silently failed

**After:**
- Handler attached in WebRTCConnection (same class)
- Handler attached BEFORE channel opens
- Messages forwarded via 'dataChannelMessage' event
- All events captured
- Transcription works reliably

**Impact:** Fixed voice ordering in production

---

## Pattern 5: Silent API Change Detection

### The Problem
```typescript
// ❌ VULNERABLE: Old API usage continues to work... until it doesn't
const sessionConfig = {
  input_audio_transcription: {
    model: 'whisper-1',  // Silently deprecated by OpenAI
    language: 'en'
  }
};

// API accepts config, no error thrown
// But transcription events never arrive
```

**Consequences:**
- No deprecation notice
- No error messages
- Feature silently breaks
- Hours debugging "working" code

### The Solution
```typescript
// ✅ DEFENSIVE: Check provider changelogs, add fallbacks

// 1. Monitor provider changelogs (daily)
// - OpenAI API updates: https://platform.openai.com/docs/changelog
// - Square API updates: https://developer.squareup.com/blog
// - Supabase updates: https://supabase.com/changelog

// 2. Add version checks and logging
const sessionConfig = {
  input_audio_transcription: {
    model: 'gpt-4o-transcribe',  // Updated 2025-01-18
    // Note: whisper-1 silently deprecated by OpenAI
  }
};

logger.info('Using OpenAI transcription model', {
  model: sessionConfig.input_audio_transcription.model,
  updated: '2025-01-18',
  reason: 'whisper-1 deprecated'
});

// 3. Test with production API keys regularly
// - Weekly smoke test of critical flows
// - Monitor for missing events/responses
// - Alert on unexpected behavior changes
```

### Real-World Example: OpenAI Model Breaking Change

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/client/src/modules/voice/services/VoiceSessionConfig.ts:253`

**Commit:** 3a5d126f (November 18, 2025)

**Timeline:**
- **October 16, 2025:** Voice ordering works (whisper-1)
- **November 2025:** OpenAI deprecates whisper-1 for Realtime API
- **November 18, 2025:** 8 hours debugging, discover forum posts
- **Fix:** 1 line change: `model: 'whisper-1'` → `model: 'gpt-4o-transcribe'`

**Evidence:**
- OpenAI community forum posts (2025)
- No official deprecation notice
- API accepted old config but ignored it
- Only transcription events stopped

**Impact:** $1,200 debugging cost for 1-line fix

---

## Pattern 6: Retry Logic with Exponential Backoff

### The Problem
```typescript
// ❌ DANGEROUS: No retry on transient failures
const result = await apiCall();
```

### The Solution
```typescript
// ✅ SAFE: Retry with exponential backoff
async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  baseDelayMs: number = 1000
): Promise<T> {
  let lastError: Error;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;

      // Don't retry on client errors (4xx)
      if (error.statusCode >= 400 && error.statusCode < 500) {
        throw error;
      }

      // Calculate exponential backoff: 1s, 2s, 4s
      const delayMs = baseDelayMs * Math.pow(2, attempt);

      logger.warn(`Retry attempt ${attempt + 1}/${maxRetries}`, {
        error: lastError.message,
        delayMs
      });

      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }

  throw lastError;
}

// Usage
const result = await withRetry(
  () => apiCall(),
  3,  // 3 retries
  1000  // 1 second base delay
);
```

### Retry Decision Matrix

| Error Type | Retry? | Backoff | Max Retries |
|------------|--------|---------|-------------|
| 5xx Server Error | Yes | Exponential | 3 |
| Network Timeout | Yes | Exponential | 3 |
| Rate Limit (429) | Yes | Linear + header | 5 |
| 4xx Client Error | No | N/A | 0 |
| Auth Failure (401) | No | N/A | 0 |
| Not Found (404) | No | N/A | 0 |

---

## Pattern 7: Rate Limiting

### The Problem
```typescript
// ❌ DANGEROUS: Burst of API calls, hit rate limit
for (const item of items) {
  await apiCall(item);  // 100 calls in 1 second
}
```

### The Solution
```typescript
// ✅ SAFE: Rate limiter with token bucket algorithm
class RateLimiter {
  private tokens: number;
  private lastRefill: number;

  constructor(
    private maxTokens: number,
    private refillRate: number  // tokens per second
  ) {
    this.tokens = maxTokens;
    this.lastRefill = Date.now();
  }

  async acquire(): Promise<void> {
    this.refillTokens();

    while (this.tokens < 1) {
      await new Promise(resolve => setTimeout(resolve, 100));
      this.refillTokens();
    }

    this.tokens -= 1;
  }

  private refillTokens(): void {
    const now = Date.now();
    const elapsed = (now - this.lastRefill) / 1000;
    const tokensToAdd = elapsed * this.refillRate;

    this.tokens = Math.min(this.maxTokens, this.tokens + tokensToAdd);
    this.lastRefill = now;
  }
}

// Usage
const limiter = new RateLimiter(10, 2);  // 10 tokens, refill 2/sec

for (const item of items) {
  await limiter.acquire();
  await apiCall(item);  // Max 2 calls/sec
}
```

---

## Pattern 8: Payload Validation

### The Problem
```typescript
// ❌ DANGEROUS: Send unvalidated data to external API
const result = await apiCall({
  amount: userInput.amount,
  idempotencyKey: generateKey()
});
```

### The Solution
```typescript
// ✅ SAFE: Validate before sending
import { z } from 'zod';

const PaymentSchema = z.object({
  amount: z.number().positive().max(100000),  // $1000 max
  idempotencyKey: z.string().max(45),  // Square limit
  currency: z.enum(['USD']),
  orderSource: z.enum(['kiosk', 'online', 'server'])
});

// Validate before API call
const validated = PaymentSchema.parse({
  amount: userInput.amount,
  idempotencyKey: generateKey(),
  currency: 'USD',
  orderSource: 'kiosk'
});

const result = await apiCall(validated);
```

### Real-World Example: Square Idempotency Key Length

**Commit:** 82d38356 (date unknown)

**Problem:**
- Generated UUID idempotency keys (36 chars)
- Added prefixes for uniqueness (50+ chars)
- Square API limit: 45 characters
- Silent failures in production

**Solution:**
```typescript
// Before: Too long
const key = `${restaurantId}-${orderId}-${Date.now()}`;  // 50+ chars

// After: Within limit
const key = `ord-${orderId.slice(0, 8)}-${Date.now()}`;  // 22 chars
```

---

## Summary: The 8 Critical Patterns

1. **Timeout Handling** - 30s for payments, 5s for DB
2. **Two-Phase Audit Logging** - Log before external calls
3. **Environment Variable Validation** - Trim and validate at startup
4. **Race Condition Prevention** - Attach handlers before operations
5. **Silent API Change Detection** - Monitor changelogs, log versions
6. **Retry Logic** - Exponential backoff for transient failures
7. **Rate Limiting** - Token bucket for burst protection
8. **Payload Validation** - Validate before sending to external APIs

---

## Related Documentation

- [INCIDENTS.md](./INCIDENTS.md) - Detailed incident reports
- [PREVENTION.md](./PREVENTION.md) - Monitoring and alerts
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Code examples
- [AI-AGENT-GUIDE.md](./AI-AGENT-GUIDE.md) - AI development guidelines

---

**Last Updated:** 2025-11-19
**Patterns Validated:** 168 bug fixes over 6 months
**Maintainer:** Technical Lead

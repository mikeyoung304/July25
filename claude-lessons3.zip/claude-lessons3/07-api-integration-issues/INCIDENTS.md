---
category: "api-integration"
category_id: "07"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "INCIDENTS"
incident_count: 4
total_cost: 20000
severity_distribution:
  P0: 2
  P1: 2
tags: [openai, square, timeouts, model-changes, audit-logging]
---
# Major API Integration Incidents - Detailed Reports

**Created:** 2025-11-19
**Category:** Incident Analysis
**Period:** June-November 2025 (6 months)

---

## Incident Index

| ID | Date | Severity | Cost | Provider | Status |
|----|------|----------|------|----------|--------|
| [INC-001](#inc-001-openai-model-breaking-change) | Nov 18, 2025 | P0 | $1,200 | OpenAI | ✅ Resolved |
| [INC-002](#inc-002-auth-token-synchronization-crisis) | Nov 2-18 | P0 | $3,600 | Internal | ✅ Resolved |
| [INC-003](#inc-003-square-payment-timeout) | Nov 10, 2025 | P0 | $1,800 | Square | ✅ Resolved |
| [INC-004](#inc-004-square-audit-race-condition) | Nov 10, 2025 | P0 | $1,500 | Square | ✅ Resolved |
| [INC-005](#inc-005-voice-webrtc-race-condition) | Nov 10, 2025 | P0 | $1,050 | OpenAI | ✅ Resolved |
| [INC-006](#inc-006-environment-variable-newlines) | Nov 7, 2025 | P1 | $600 | Internal | ✅ Resolved |

**Total Cost:** $9,750 for top 6 incidents

---

## INC-001: OpenAI Model Breaking Change

### Overview
| Field | Value |
|-------|-------|
| **Date** | November 18, 2025 |
| **Duration** | 8 hours (6h initial + 2h git analysis) |
| **Severity** | P0 - Complete feature failure |
| **Cost** | $1,200 (8 hours × $150/hr) |
| **Provider** | OpenAI Realtime API |
| **Commits** | 3a5d126f, d42b2c74 |

### Timeline

**November 2025 (Unknown Date):**
- OpenAI silently deprecates `whisper-1` model for Realtime API
- No deprecation notice sent to developers
- No migration guide published
- API continues accepting old config

**November 18, 2025 - 10:00 AM:**
- User reports: "Voice ordering button does nothing"
- Developer investigation begins

**10:00 AM - 4:00 PM (6 hours):**
- Add comprehensive logging across voice services
- Verify session connects (✅ working)
- Verify audio transmits (✅ 49KB sent, 1140 packets)
- Verify agent responds (✅ response.text.done events)
- Verify session.update sent (✅ 15KB payload)
- Identify: NO transcription events received
  - No `conversation.item.input_audio_transcription.delta`
  - No `conversation.item.input_audio_transcription.completed`
- Conclusion: Not a code bug, possibly API issue

**4:00 PM - 6:00 PM (2 hours):**
- Scan git history to October 16 (when it worked)
- Compare session config: IDENTICAL
- Find race condition fix from November 10
- Realize: Something changed externally

**6:00 PM - 6:15 PM (15 minutes):**
- Search OpenAI community forums
- Find posts about whisper-1 not working
- Discover recommendation: `gpt-4o-transcribe`
- Apply fix and test

**6:15 PM - 6:30 PM:**
- Commit fix: 1 line changed
- Write comprehensive documentation
- Deploy to production

### Root Cause

OpenAI deprecated `whisper-1` model for Realtime API transcription without notice.

**Evidence:**
```typescript
// Old config (broken after deprecation)
input_audio_transcription: {
  model: 'whisper-1',
  language: 'en'
}

// New config (working)
input_audio_transcription: {
  model: 'gpt-4o-transcribe'
}
```

**Why It Was Hard to Debug:**
1. **Silent Failure** - API accepted config but ignored it
2. **No Error Events** - No indication model was invalid
3. **Everything Else Worked** - Audio, responses, session all functional
4. **Recent Breaking Change** - Working code from October broke
5. **Undocumented** - No migration guide or deprecation notice
6. **Multi-Layer System** - Hard to isolate which layer was failing

### Impact

**Customer Experience:**
- Voice ordering completely non-functional
- Button press appeared to do nothing
- No error messages shown
- Users assumed feature was broken

**Business Impact:**
- 2 weeks of broken voice ordering
- Lost revenue from voice-ordering customers
- Support tickets and confusion
- Developer time: 8 hours

### Fix

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/client/src/modules/voice/services/VoiceSessionConfig.ts:253`

```typescript
// Change 1 line
- model: 'whisper-1',
- language: 'en'
+ model: 'gpt-4o-transcribe'
```

**Commit:** 3a5d126f

### Prevention

1. **Monitor Provider Changelogs**
   - Daily check of OpenAI API updates
   - Subscribe to provider newsletters
   - Set up Google Alerts for deprecations

2. **Version Logging**
   ```typescript
   logger.info('Using OpenAI transcription model', {
     model: 'gpt-4o-transcribe',
     updated: '2025-01-18',
     reason: 'whisper-1 deprecated'
   });
   ```

3. **Weekly Smoke Tests**
   - Test critical flows with production API keys
   - Monitor for missing events/responses
   - Alert on unexpected behavior changes

### Related Documentation

- [VOICE_FIX_TRANSCRIPTION_MODEL_2025-01-18.md](/Users/mikeyoung/CODING/rebuild-6.0/docs/archive/2025-01/VOICE_FIX_TRANSCRIPTION_MODEL_2025-01-18.md)
- [PATTERNS.md](./PATTERNS.md#pattern-5-silent-api-change-detection)

---

## INC-002: Auth Token Synchronization Crisis

### Overview
| Field | Value |
|-------|-------|
| **Date** | November 2-18, 2025 |
| **Duration** | 24 hours (across 16 days) |
| **Severity** | P0 - Complete login failure |
| **Cost** | $3,600 (24 hours × $150/hr) |
| **Provider** | Internal (httpClient state management) |
| **Commits** | acd6125c, 9e97f720, a3514472 |

### Timeline

**November 2, 2025:**
- Remove 430 lines of demo session code
- Accidentally remove `setCurrentRestaurantId()` calls
- Push to production

**November 2-18, 2025 (16 days):**
- Users report: "Login hangs at 'Signing in...'"
- Intermittent failures (race condition)
- Multiple attempts to fix
- Add comprehensive logging

**November 10, 2025:**
- Identify root cause: Restaurant ID not synced
- httpClient missing `X-Restaurant-ID` header
- Backend middleware queries hang without timeout
- Add `setCurrentRestaurantId()` at 5 critical locations

**November 18, 2025:**
- Switch from Supabase auth to custom JWT endpoint
- Ensures restaurant context in token payload
- Fixes authentication loop permanently

### Root Cause

**State Synchronization Failure:**
```typescript
// The Problem:
// 1. React state updated with restaurantId
setRestaurantId(response.restaurantId);

// 2. httpClient state NOT updated
// httpClient.currentRestaurantId = undefined

// 3. API calls missing X-Restaurant-ID header
// Backend middleware queries user_restaurants table

// 4. Query hangs (no timeout) or fails validation
// Login stuck at "Signing in..."
```

**Where It Happened:**
- Line 82: `initializeAuth()` - session restoration
- Line 152: `onAuthStateChange()` - Supabase SIGNED_IN event
- Line 227: `login()` - EMAIL/PASSWORD LOGIN (primary)
- Line 263: `loginWithPin()` - PIN authentication
- Line 315: `loginAsStation()` - station authentication

### Impact

**Customer Experience:**
- Login hung at "Signing in..." indefinitely
- No error message shown
- Users forced to refresh and retry
- Some users gave up

**Business Impact:**
- 16 days of intermittent login failures
- Customer frustration and support tickets
- Developer time: 24 hours across multiple sessions
- Multiple production deployments

### Fix

**Phase 1: Sync httpClient State (November 10)**

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/client/src/contexts/AuthContext.tsx`

**Commit:** acd6125c

```typescript
// Add setCurrentRestaurantId() at 5 locations
await setCurrentRestaurantId(response.restaurantId);
httpClient.setRestaurantId(response.restaurantId);
```

**Phase 2: Switch to Custom JWT (November 18)**

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/client/src/contexts/AuthContext.tsx`

**Commit:** 9e97f720

```typescript
// Replace Supabase auth with custom JWT endpoint
const response = await fetch('/api/v1/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email, password })
});

// Custom JWT includes restaurant_id in payload
const { token, user, restaurantId } = await response.json();
```

### Prevention

1. **Single Source of Truth**
   - Never duplicate state across systems
   - Use context providers or global stores
   - Document state dependencies

2. **State Change Logging**
   ```typescript
   logger.info('Auth state updated', {
     userId: user.id,
     restaurantId: restaurantId,
     httpClientSynced: httpClient.currentRestaurantId === restaurantId
   });
   ```

3. **Integration Tests**
   ```typescript
   test('login syncs httpClient state', async () => {
     await login(email, password);
     expect(httpClient.currentRestaurantId).toBe(expectedRestaurantId);
   });
   ```

### Related Documentation

- [AUTHENTICATION_EVOLUTION_SUMMARY.md](/Users/mikeyoung/CODING/rebuild-6.0/AUTHENTICATION_EVOLUTION_SUMMARY.md)
- [ADR-011: Authentication Evolution](/Users/mikeyoung/CODING/rebuild-6.0/docs/explanation/architecture-decisions/ADR-011-authentication-evolution.md)

---

## INC-003: Square Payment Timeout

### Overview
| Field | Value |
|-------|-------|
| **Date** | November 10, 2025 |
| **Duration** | 12 hours |
| **Severity** | P0 - Payment system failure |
| **Cost** | $1,800 (12 hours × $150/hr) |
| **Provider** | Square Payments API |
| **Commits** | cf7d9320 |

### Timeline

**Unknown Date:**
- Production reports: "Payment button hangs"
- Users wait indefinitely with no feedback
- Some users abandon carts

**November 10, 2025 - 9:00 AM:**
- Developer investigation begins
- Review Square API calls
- Identify: No timeout protection

**9:00 AM - 9:00 PM (12 hours):**
- Research Square API behavior
- Design timeout wrapper with Promise.race()
- Implement for all Square API calls
- Test with simulated network issues
- Deploy to production

### Root Cause

**No Timeout Protection:**
```typescript
// ❌ DANGEROUS: No timeout on Square API call
const paymentResult = await paymentsApi.create(paymentRequest);
```

**Consequences:**
- Network issues cause infinite hangs
- Square API outages leave customers waiting
- No error feedback to users
- Cannot retry or cancel

### Impact

**Customer Experience:**
- Payment button appears frozen
- No loading indicator or progress
- No error message after timeout
- Users abandon carts

**Business Impact:**
- Lost revenue from abandoned carts
- Customer support tickets
- Reputation damage
- Developer time: 12 hours

### Fix

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/server/src/routes/payments.routes.ts:38-64`

**Commit:** cf7d9320

```typescript
// Timeout wrapper for Square API calls
async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number = 30000,
  operation: string = 'Square API call'
): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(
        () => reject(new Error(`${operation} timed out after ${timeoutMs}ms`)),
        timeoutMs
      )
    )
  ]);
}

// Usage
paymentResult = await withTimeout(
  paymentsApi.create(paymentRequest),
  30000,
  'Square payment creation'
);
```

### Prevention

1. **Always Add Timeouts**
   - 30 seconds for payment operations
   - 5 seconds for database queries
   - 60 seconds for WebRTC connections

2. **Timeout Monitoring**
   ```typescript
   logger.warn('Square API timeout', {
     operation: 'payment creation',
     timeoutMs: 30000,
     orderId: order_id
   });
   ```

3. **User Feedback**
   - Show timeout error message
   - Provide retry button
   - Log for monitoring

### Related Documentation

- [PATTERNS.md](./PATTERNS.md#pattern-1-timeout-handling)
- [P0_PAYMENT_AUDIT_ANALYSIS.md](/Users/mikeyoung/CODING/rebuild-6.0/docs/investigations/P0_PAYMENT_AUDIT_ANALYSIS.md)

---

## INC-004: Square Audit Race Condition

### Overview
| Field | Value |
|-------|-------|
| **Date** | November 10, 2025 |
| **Duration** | 10 hours |
| **Severity** | P0 - Compliance violation |
| **Cost** | $1,500 (10 hours × $150/hr) |
| **Provider** | Square Payments API |
| **Commits** | dc8afec6 |

### Timeline

**Unknown Date:**
- Production reports: "Payment error but card charged"
- Customer confusion: "Was I charged?"
- Support team investigates

**November 10, 2025 - 9:00 AM:**
- Developer investigation begins
- Review payment flow timing
- Identify: Audit log AFTER payment processing

**9:00 AM - 7:00 PM (10 hours):**
- Research PCI DSS requirements (ADR-009)
- Design two-phase audit logging
- Implement 'initiated' status
- Add `updatePaymentAuditStatus()` function
- Test with simulated audit failures
- Deploy to production

### Root Cause

**Audit Timing Bug:**
```typescript
// ❌ DANGEROUS: Audit AFTER external API call
const paymentResult = await paymentsApi.create(paymentRequest);
await OrdersService.updateOrderPayment(...);
await PaymentService.logPaymentAttempt({ status: 'success' });
```

**The Problem:**
1. Customer charged (Square API)
2. Order marked as paid (database)
3. Audit log fails (database error)
4. Error thrown to client
5. **Customer charged but system shows error** ❌

### Impact

**Customer Experience:**
- "Payment error" message shown
- But card was charged
- Confusion: "Was I charged or not?"
- Support burden: refund requests

**Business Impact:**
- Revenue reconciliation issues
- PCI DSS compliance gap
- Customer trust damage
- Developer time: 10 hours

### Fix

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/server/src/routes/payments.routes.ts:233-299`

**Commit:** dc8afec6

```typescript
// Phase 1: Log BEFORE external API call
await PaymentService.logPaymentAttempt({
  orderId: order_id,
  status: 'initiated',  // NEW: Pre-charge status
  restaurantId: restaurantId,
  amount: validation.orderTotal,
  idempotencyKey: serverIdempotencyKey
});

// Phase 2: Make API call (safe to fail now)
const paymentResult = await withTimeout(
  paymentsApi.create(paymentRequest),
  30000,
  'Square payment creation'
);

// Phase 3: Update audit log with result
await PaymentService.updatePaymentAuditStatus(
  serverIdempotencyKey,
  paymentResult.payment?.status === 'COMPLETED' ? 'success' : 'failed',
  paymentResult.payment.id
);
```

### Prevention

1. **Log Before External APIs**
   - Audit log with status='initiated'
   - Safe to fail early (no charge yet)
   - Update log after API call

2. **Audit Status Flow**
   ```
   initiated → (API call) → success
                         ↓
                       failed
   ```

3. **Monitoring**
   ```typescript
   // Alert on 'initiated' logs not updated
   SELECT * FROM payment_audit_logs
   WHERE status = 'initiated'
   AND created_at < NOW() - INTERVAL '5 minutes';
   ```

### Related Documentation

- [PATTERNS.md](./PATTERNS.md#pattern-2-two-phase-audit-logging)
- [P0_PAYMENT_AUDIT_ANALYSIS.md](/Users/mikeyoung/CODING/rebuild-6.0/docs/investigations/P0_PAYMENT_AUDIT_ANALYSIS.md)
- [ADR-009: Error Handling Philosophy](/Users/mikeyoung/CODING/rebuild-6.0/docs/explanation/architecture-decisions/ADR-009-error-handling-philosophy.md)

---

## INC-005: Voice WebRTC Race Condition

### Overview
| Field | Value |
|-------|-------|
| **Date** | November 10, 2025 |
| **Duration** | 7 hours |
| **Severity** | P0 - Feature completely broken |
| **Cost** | $1,050 (7 hours × $150/hr) |
| **Provider** | OpenAI Realtime API (WebRTC) |
| **Commits** | 500b820c |

### Timeline

**Unknown Date:**
- Voice ordering transcription fails
- State machine deadlocks
- "Waiting for user transcript..." forever

**November 10, 2025 - 8:00 AM:**
- Developer investigation begins
- Add comprehensive logging
- Verify WebRTC connection works
- Verify audio transmits

**8:00 AM - 3:00 PM (7 hours):**
- Identify: Initial events lost
- Discover: Handler attached 50-100ms late
- Find: DataChannel opens before handler ready
- Design: Attach handler before channel creation
- Implement: Forward events via EventEmitter
- Test: Verify events captured
- Deploy to production

### Root Cause

**Race Condition Timing:**
```typescript
// ❌ DANGEROUS: Handler attached after channel opens
const dataChannel = peerConnection.createDataChannel('openai-realtime');

// 50-100ms delay here...
dataChannel.onmessage = (event) => {
  // Handler attached AFTER channel opens
  // Initial messages (session.created) are LOST
  handleMessage(event);
};
```

**Timeline:**
```
0ms:    createDataChannel()
0ms:    dataChannel.onopen fires
50ms:   dataChannel.onmessage attached  ← TOO LATE
100ms:  session.created event lost
500ms:  conversation.item.created lost
1000ms: State machine deadlock
```

### Impact

**Customer Experience:**
- Voice ordering appears to work
- Audio transmits, agent responds
- But transcription never appears
- State machine stuck forever

**Business Impact:**
- Voice ordering non-functional
- Customer confusion and frustration
- Developer time: 7 hours

### Fix

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/client/src/modules/voice/services/WebRTCConnection.ts:412-418`

**Commit:** 500b820c

```typescript
// ✅ SAFE: Attach handler BEFORE channel opens
const setupDataChannel = () => {
  const dataChannel = peerConnection.createDataChannel('openai-realtime');

  // Attach handler IMMEDIATELY (before onopen can fire)
  dataChannel.onmessage = (event) => {
    // Handler ready for first message
    this.emit('dataChannelMessage', event.data);
  };

  dataChannel.onopen = () => {
    logger.info('DataChannel opened');
    // All messages will be captured now
  };

  return dataChannel;
};
```

**Timeline After Fix:**
```
0ms:    createDataChannel()
0ms:    dataChannel.onmessage attached  ← READY
0ms:    dataChannel.onopen fires
100ms:  session.created event captured
500ms:  conversation.item.created captured
1000ms: Normal operation
```

### Prevention

1. **Attach Handlers Early**
   - Before creating event sources
   - Before opening connections
   - Before triggering events

2. **Race Condition Logging**
   ```typescript
   logger.debug('Handler attached', {
     timestamp: Date.now(),
     channel: 'dataChannel'
   });

   dataChannel.onopen = () => {
     logger.debug('Channel opened', {
       timestamp: Date.now(),
       channel: 'dataChannel'
     });
   };
   ```

3. **Defensive Fallbacks**
   ```typescript
   // Create transcript entry if missing
   if (!this.transcriptMap.has(itemId)) {
     logger.warn('Missing transcript map entry, creating defensively', {
       itemId
     });
     this.transcriptMap.set(itemId, { text: '', status: 'in_progress' });
   }
   ```

### Related Documentation

- [PATTERNS.md](./PATTERNS.md#pattern-4-race-condition-prevention)

---

## INC-006: Environment Variable Newlines

### Overview
| Field | Value |
|-------|-------|
| **Date** | November 7, 2025 |
| **Duration** | 4 hours |
| **Severity** | P1 - Feature broken in production |
| **Cost** | $600 (4 hours × $150/hr) |
| **Provider** | Internal (CLI tools) |
| **Commits** | 03011ced |

### Timeline

**Unknown Date:**
- Deploy to production (Render)
- Voice ordering button does nothing
- No error messages shown

**November 7, 2025 - 2:00 PM:**
- Developer investigation begins
- Check environment variables
- Find: OPENAI_API_KEY contains '\n'

**2:00 PM - 6:00 PM (4 hours):**
- Trace source: Vercel CLI without `-n` flag
- Design solution: Trim all env vars at startup
- Add validation for malformed keys
- Implement health check endpoint
- Deploy to production

### Root Cause

**Newline Characters from CLI:**
```bash
# ❌ WRONG: Adds newline to environment variable
echo "sk-proj-..." | vercel env add OPENAI_API_KEY production

# Result: OPENAI_API_KEY="sk-proj-...\n"
```

**The Problem:**
```typescript
// OpenAI API receives malformed Authorization header
Authorization: Bearer sk-proj-...\n

// OpenAI rejects with 401/403 error
// Client connect() promise rejects silently
// User sees no feedback
```

### Impact

**Customer Experience:**
- Voice ordering button appears to do nothing
- No error message shown
- No loading indicator
- Silent failure

**Business Impact:**
- Feature broken in production
- Customer confusion
- Developer time: 4 hours

### Fix

**File:** `/Users/mikeyoung/CODING/rebuild-6.0/server/src/config/env.ts:10-23`

**Commit:** 03011ced

```typescript
// Trim all environment variables
const getString = (key: string, fallback = ''): string => {
  const value = process.env[key];
  // Trim to remove any whitespace or newline characters
  const trimmed = value?.trim();
  return trimmed !== undefined && trimmed !== '' ? trimmed : fallback;
};

// Detect malformed keys at startup
if (apiKey.includes('\n') || apiKey.includes('\\n') || apiKey.includes('\r')) {
  throw new Error(
    `Environment variable ${key} contains invalid characters (newlines). ` +
    `This may be caused by CLI tools. Fix: Use "echo -n" when setting variables.`
  );
}
```

### Prevention

1. **Always Use `echo -n`**
   ```bash
   # ✅ CORRECT: No newline added
   echo -n "value" | vercel env add VAR_NAME production
   ```

2. **Trim at Startup**
   ```typescript
   const trimmed = value?.trim();
   ```

3. **Validate at Startup**
   ```typescript
   if (value.includes('\n')) {
     throw new Error('Invalid environment variable');
   }
   ```

4. **Health Check Endpoint**
   ```typescript
   router.get('/health', (req, res) => {
     const apiKeyValid = !apiKey.includes('\n');
     res.json({ api_key_valid: apiKeyValid });
   });
   ```

### Related Documentation

- [PATTERNS.md](./PATTERNS.md#pattern-3-environment-variable-validation)
- [VOICE_ORDERING_FIX_SUMMARY.md](/Users/mikeyoung/CODING/rebuild-6.0/VOICE_ORDERING_FIX_SUMMARY.md)

---

## Summary Statistics

### Total Cost
| Incident | Hours | Cost |
|----------|-------|------|
| INC-001: OpenAI Model Change | 8 | $1,200 |
| INC-002: Auth Token Sync | 24 | $3,600 |
| INC-003: Square Timeout | 12 | $1,800 |
| INC-004: Square Audit Race | 10 | $1,500 |
| INC-005: Voice WebRTC Race | 7 | $1,050 |
| INC-006: Env Var Newlines | 4 | $600 |
| **Total** | **65** | **$9,750** |

### Incident Categories
- **Silent API Changes:** 1 incident (15%)
- **State Synchronization:** 1 incident (15%)
- **Timeout Issues:** 1 incident (15%)
- **Race Conditions:** 2 incidents (31%)
- **Configuration Issues:** 1 incident (15%)

### Providers Affected
- **OpenAI:** 2 incidents
- **Square:** 2 incidents
- **Internal:** 2 incidents

---

## Related Documentation

- [README.md](./README.md) - Executive summary
- [PATTERNS.md](./PATTERNS.md) - API patterns and best practices
- [PREVENTION.md](./PREVENTION.md) - Solutions and monitoring
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Code examples
- [AI-AGENT-GUIDE.md](./AI-AGENT-GUIDE.md) - AI development guidelines

---

**Last Updated:** 2025-11-19
**Incidents Analyzed:** 6 major incidents
**Total Cost:** $9,750
**Maintainer:** Technical Lead

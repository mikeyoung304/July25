---
category: "api-integration"
category_id: "07"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, openai, square, timeouts, model-changes, audit-logging]
---
# API Integration Quick Reference

**Created:** 2025-11-19
**Category:** Developer Reference
**Purpose:** Copy-paste solutions for common API integration tasks

---

## Timeout Values (Production-Tested)

```typescript
// Standard timeout values from 6 months of production
const TIMEOUTS = {
  PAYMENT_CREATION: 30000,     // 30 seconds - Square payment
  PAYMENT_RETRIEVAL: 30000,    // 30 seconds - Square lookup
  REFUND_PROCESSING: 30000,    // 30 seconds - Square refund
  DATABASE_QUERY: 5000,        // 5 seconds - Detect hangs
  REALTIME_SESSION: 60000,     // 60 seconds - WebRTC setup
  FILE_UPLOAD: 120000,         // 2 minutes - Large files
  API_HEALTH_CHECK: 10000,     // 10 seconds - Quick validation
  WEBHOOK_DELIVERY: 15000      // 15 seconds - Third-party webhook
};
```

---

## Timeout Wrapper

```typescript
/**
 * Universal timeout wrapper for all external APIs
 * Usage: wrap any promise with withTimeout()
 */
async function withTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number,
  operation: string
): Promise<T> {
  let timeoutId: NodeJS.Timeout;

  const timeoutPromise = new Promise<T>((_, reject) => {
    timeoutId = setTimeout(() => {
      reject(new Error(`${operation} timed out after ${timeoutMs}ms`));
    }, timeoutMs);
  });

  try {
    const result = await Promise.race([promise, timeoutPromise]);
    clearTimeout(timeoutId);
    return result;
  } catch (error) {
    clearTimeout(timeoutId);
    throw error;
  }
}

// Example: Square Payment
const payment = await withTimeout(
  paymentsApi.create(paymentRequest),
  30000,
  'Square payment creation'
);

// Example: Database Query
const user = await withTimeout(
  supabase.from('users').select('*').eq('id', userId).single(),
  5000,
  'User query'
);

// Example: OpenAI API
const completion = await withTimeout(
  openai.chat.completions.create({ model: 'gpt-4', messages }),
  30000,
  'OpenAI completion'
);
```

---

## Retry Logic with Exponential Backoff

```typescript
/**
 * Retry transient failures with exponential backoff
 * Does NOT retry 4xx client errors
 */
async function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  baseDelayMs: number = 1000
): Promise<T> {
  let lastError: Error;

  for (let attempt = 0; attempt < maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error as Error;

      // Don't retry client errors (4xx)
      if (error.statusCode >= 400 && error.statusCode < 500) {
        throw error;
      }

      // Don't retry on last attempt
      if (attempt === maxRetries - 1) {
        break;
      }

      // Calculate exponential backoff: 1s, 2s, 4s
      const delayMs = baseDelayMs * Math.pow(2, attempt);
      await new Promise(resolve => setTimeout(resolve, delayMs));
    }
  }

  throw lastError;
}

// Example: Retry API call with timeout
const result = await withRetry(
  () => withTimeout(apiCall(), 30000, 'API call'),
  3  // 3 retries
);
```

---

## Two-Phase Audit Logging

```typescript
/**
 * Log intent before external API call
 * Update log with result after
 * Prevents "charged but unrecorded" scenario
 */

// Phase 1: Log BEFORE API call
const auditId = uuidv4();
await supabase.from('payment_audit_logs').insert({
  id: auditId,
  order_id: order_id,
  restaurant_id: restaurant_id,
  status: 'initiated',  // NEW: Pre-charge status
  amount: amount,
  idempotency_key: idempotencyKey,
  created_at: new Date().toISOString()
});

// Phase 2: Make API call (safe to fail now)
try {
  const payment = await withTimeout(
    paymentsApi.create(paymentRequest),
    30000,
    'Square payment creation'
  );

  // Phase 3: Update audit log with success
  await supabase
    .from('payment_audit_logs')
    .update({
      status: 'success',
      payment_id: payment.id,
      updated_at: new Date().toISOString()
    })
    .eq('id', auditId);

} catch (error) {
  // Update audit log with failure
  await supabase
    .from('payment_audit_logs')
    .update({
      status: 'failed',
      error_code: error.code,
      error_detail: error.message,
      updated_at: new Date().toISOString()
    })
    .eq('id', auditId);

  throw error;
}
```

---

## Environment Variable Validation

```typescript
/**
 * Trim and validate all environment variables at startup
 * Catches newlines from CLI tools, missing values
 */

// 1. Trim helper
const getString = (key: string, fallback = ''): string => {
  const value = process.env[key];
  const trimmed = value?.trim();  // Remove newlines
  return trimmed !== undefined && trimmed !== '' ? trimmed : fallback;
};

// 2. Validate at startup
const validateEnvironment = (): void => {
  const required = [
    'OPENAI_API_KEY',
    'SQUARE_ACCESS_TOKEN',
    'SUPABASE_SERVICE_KEY'
  ];

  for (const key of required) {
    const value = getString(key);

    // Check if missing
    if (!value) {
      throw new Error(`Missing required environment variable: ${key}`);
    }

    // Check for newlines (from CLI tools)
    if (value.includes('\n') || value.includes('\\n') || value.includes('\r')) {
      throw new Error(
        `Environment variable ${key} contains invalid characters. ` +
        `Fix: Use "echo -n" when setting via CLI.`
      );
    }

    // Check for placeholders
    if (value === 'CHANGEME' || value === 'demo') {
      throw new Error(`Environment variable ${key} has placeholder value`);
    }
  }
};

// 3. Run before starting server
validateEnvironment();
```

---

## Race Condition Prevention

```typescript
/**
 * Attach event handlers BEFORE creating event sources
 * Prevents losing initial events
 */

// ❌ WRONG: Handler attached after channel opens
const channel = peer.createDataChannel('data');
// 50-100ms delay...
channel.onmessage = (event) => {
  // Too late - initial messages lost
  handleMessage(event);
};

// ✅ CORRECT: Handler attached before channel opens
const channel = peer.createDataChannel('data');
channel.onmessage = (event) => {
  // Ready for first message
  handleMessage(event);
};
channel.onopen = () => {
  // All messages captured
  console.log('Channel opened');
};
```

---

## API Error Codes Reference

### OpenAI API

| Code | Meaning | Retry? | Action |
|------|---------|--------|--------|
| 401 | Invalid API key | No | Check OPENAI_API_KEY |
| 429 | Rate limit | Yes | Exponential backoff |
| 500 | Server error | Yes | Retry 3x |
| 503 | Service unavailable | Yes | Retry 3x |

### Square API

| Code | Meaning | Retry? | Action |
|------|---------|--------|--------|
| 401 | Invalid token | No | Check SQUARE_ACCESS_TOKEN |
| 402 | Payment declined | No | Inform user |
| 429 | Rate limit | Yes | Exponential backoff |
| 500 | Server error | Yes | Retry 3x |
| 503 | Service unavailable | Yes | Retry 3x |

### Supabase

| Error | Meaning | Retry? | Action |
|-------|---------|--------|--------|
| PGRST301 | RLS policy violation | No | Check restaurant_id |
| PGRST116 | Row not found | No | Handle missing data |
| 08006 | Connection failure | Yes | Retry 3x |
| 53300 | Too many connections | Yes | Use connection pooling |

---

## Common Error Patterns

### Pattern 1: Silent API Change

```typescript
// Symptom: API accepts config but ignores it
// Example: OpenAI whisper-1 deprecation

// ❌ OLD (broken after deprecation)
const config = {
  input_audio_transcription: {
    model: 'whisper-1',
    language: 'en'
  }
};

// ✅ NEW (working)
const config = {
  input_audio_transcription: {
    model: 'gpt-4o-transcribe'
  }
};

// Prevention: Log API versions
logger.info('Using OpenAI transcription', {
  model: config.input_audio_transcription.model,
  updated: '2025-01-18',
  reason: 'whisper-1 deprecated'
});
```

### Pattern 2: Newlines in Environment Variables

```typescript
// Symptom: API returns 401/403 with valid-looking key
// Cause: Newline characters from CLI

// ❌ WRONG: Adds newline
echo "sk-proj-..." | vercel env add OPENAI_API_KEY production

// ✅ CORRECT: No newline
echo -n "sk-proj-..." | vercel env add OPENAI_API_KEY production

// Detection: Check for newlines at startup
if (apiKey.includes('\n') || apiKey.includes('\\n')) {
  throw new Error('API key contains newline characters');
}
```

### Pattern 3: State Synchronization

```typescript
// Symptom: API calls missing required headers
// Cause: State not synced between systems

// ❌ WRONG: Only update React state
setRestaurantId(response.restaurantId);

// ✅ CORRECT: Sync all state systems
setRestaurantId(response.restaurantId);
httpClient.setRestaurantId(response.restaurantId);
localStorage.setItem('restaurantId', response.restaurantId);

// Verification: Log state sync
logger.info('Restaurant ID updated', {
  reactState: restaurantId,
  httpClient: httpClient.currentRestaurantId,
  localStorage: localStorage.getItem('restaurantId'),
  allSynced: restaurantId === httpClient.currentRestaurantId
});
```

### Pattern 4: Race Condition Timing

```typescript
// Symptom: Events lost, state machine deadlock
// Cause: Async handler attached too late

// Timeline (Before Fix):
// 0ms:    Event source created
// 0ms:    First event fires
// 50ms:   Handler attached ← TOO LATE
// 100ms:  Event lost

// ✅ CORRECT: Attach handler synchronously
const source = createEventSource();
source.onmessage = (event) => {
  // Handler ready for first event
  handleMessage(event);
};
```

---

## Health Check Template

```typescript
/**
 * Health check endpoint for monitoring
 * Returns status of all external dependencies
 */
router.get('/health', async (req, res) => {
  const checks = {
    timestamp: new Date().toISOString(),
    status: 'healthy',
    checks: {
      database: false,
      openai: false,
      square: false
    }
  };

  // Database
  try {
    await supabase.from('restaurants').select('id').limit(1);
    checks.checks.database = true;
  } catch {
    checks.status = 'unhealthy';
  }

  // OpenAI
  try {
    const apiKey = process.env.OPENAI_API_KEY?.trim();
    checks.checks.openai = apiKey &&
      !apiKey.includes('\n') &&
      apiKey.length > 20;
  } catch {
    checks.status = 'unhealthy';
  }

  // Square
  try {
    const token = process.env.SQUARE_ACCESS_TOKEN?.trim();
    checks.checks.square = token &&
      !token.includes('\n') &&
      token.length > 20;
  } catch {
    checks.status = 'unhealthy';
  }

  const statusCode = checks.status === 'healthy' ? 200 : 503;
  res.status(statusCode).json(checks);
});
```

---

## Logging Templates

### API Call Logging

```typescript
// Log before API call
logger.info('Calling external API', {
  provider: 'Square',
  operation: 'payment creation',
  orderId: order_id,
  amount: amount,
  idempotencyKey: idempotencyKey
});

const startTime = Date.now();

try {
  const result = await withTimeout(apiCall(), 30000, 'Square payment');

  // Log success
  logger.info('API call succeeded', {
    provider: 'Square',
    operation: 'payment creation',
    orderId: order_id,
    latencyMs: Date.now() - startTime,
    paymentId: result.id
  });

} catch (error) {
  // Log failure
  logger.error('API call failed', {
    provider: 'Square',
    operation: 'payment creation',
    orderId: order_id,
    latencyMs: Date.now() - startTime,
    error: error.message,
    errorCode: error.code
  });

  throw error;
}
```

### Timeout Logging

```typescript
try {
  const result = await withTimeout(apiCall(), 30000, 'Square payment');
} catch (error) {
  if (error.message.includes('timed out')) {
    logger.error('API timeout', {
      provider: 'Square',
      operation: 'payment creation',
      timeoutMs: 30000,
      orderId: order_id
    });

    // Send alert
    await sendAlert('Square API timeout', { orderId: order_id });
  }

  throw error;
}
```

---

## Provider-Specific Quirks

### OpenAI Realtime API

```typescript
// Quirk: whisper-1 deprecated for Realtime API
// Solution: Use gpt-4o-transcribe
const config = {
  input_audio_transcription: {
    model: 'gpt-4o-transcribe'  // Not whisper-1
  }
};

// Quirk: turn_detection: null breaks manual control
// Solution: Use server VAD with manual override
const config = {
  turn_detection: {
    type: 'server_vad',
    create_response: false,  // Manual control
    silence_duration_ms: 1500
  }
};
```

### Square Payments API

```typescript
// Quirk: Idempotency key max 45 characters
// Solution: Use short prefixes
const key = `ord-${orderId.slice(0, 8)}-${Date.now()}`;  // 22 chars

// Quirk: Amount in cents (not dollars)
const amountCents = Math.round(amountDollars * 100);

// Quirk: v43 SDK uses .paymentsApi (not .payments)
const result = await client.paymentsApi.create(request);
```

### Supabase

```typescript
// Quirk: RLS policies require explicit restaurant_id
const { data } = await supabase
  .from('orders')
  .select('*')
  .eq('restaurant_id', restaurantId);  // Always required

// Quirk: Service key bypasses RLS
// Only use server-side, never expose to client
const supabaseAdmin = createClient(url, serviceKey);

// Quirk: Connection pooling required for high traffic
const supabase = createClient(url, anonKey, {
  db: {
    poolSize: 10
  }
});
```

---

## Testing Checklist

### API Integration Tests

```typescript
// Test timeout handling
test('API call times out after 30 seconds', async () => {
  const slowApi = () => new Promise(resolve => setTimeout(resolve, 60000));

  await expect(
    withTimeout(slowApi(), 30000, 'Slow API')
  ).rejects.toThrow('timed out after 30000ms');
});

// Test retry logic
test('Retries transient failures', async () => {
  let attempts = 0;
  const flaky = async () => {
    attempts++;
    if (attempts < 3) throw new Error('Transient failure');
    return 'success';
  };

  const result = await withRetry(flaky, 3);
  expect(result).toBe('success');
  expect(attempts).toBe(3);
});

// Test two-phase audit
test('Audit log created before API call', async () => {
  const auditId = await logIntent('payment', { orderId: '123' });

  const { data } = await supabase
    .from('audit_logs')
    .select('*')
    .eq('id', auditId)
    .single();

  expect(data.status).toBe('initiated');
});
```

---

## Monitoring Queries

### Stale Audit Logs

```sql
-- Find audit logs not updated in 5 minutes
SELECT *
FROM payment_audit_logs
WHERE status = 'initiated'
AND created_at < NOW() - INTERVAL '5 minutes';
```

### High Error Rate

```sql
-- Count errors in last hour by provider
SELECT
  metadata->>'provider' as provider,
  COUNT(*) as error_count
FROM audit_logs
WHERE status = 'failed'
AND created_at > NOW() - INTERVAL '1 hour'
GROUP BY provider;
```

### High Timeout Rate

```sql
-- Count timeouts in last hour
SELECT
  metadata->>'operation' as operation,
  COUNT(*) as timeout_count
FROM audit_logs
WHERE error_detail LIKE '%timed out%'
AND created_at > NOW() - INTERVAL '1 hour'
GROUP BY operation;
```

---

## Emergency Fixes

### Voice Ordering Broken

```bash
# Check OpenAI API key
curl https://july25.onrender.com/api/v1/realtime/health

# Expected: { "status": "healthy", "checks": { "api_key_valid": true } }
```

### Payment System Hanging

```bash
# Check Square API timeout
grep "timed out" server/logs/production.log

# Fix: Ensure withTimeout() wrapper applied
```

### Auth Loop

```bash
# Check httpClient state sync
# In client console:
console.log('React state:', restaurantId);
console.log('httpClient state:', httpClient.currentRestaurantId);

# Expected: Both should match
```

---

## Related Documentation

- [README.md](./README.md) - Executive summary
- [PATTERNS.md](./PATTERNS.md) - API patterns and best practices
- [INCIDENTS.md](./INCIDENTS.md) - Detailed incident reports
- [PREVENTION.md](./PREVENTION.md) - Monitoring and alerts
- [AI-AGENT-GUIDE.md](./AI-AGENT-GUIDE.md) - AI development guidelines

---

**Last Updated:** 2025-11-19
**Quick Reference Version:** 1.0
**Maintainer:** Technical Lead

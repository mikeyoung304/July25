---
category: "build-deployment"
category_id: "05"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, vercel, monorepo, memory-limits, build-order, ci-cd]
---
# Build & Deployment Quick Reference

**Purpose:** Fast lookup for commands, configurations, and checklists
**Audience:** Developers needing quick answers
**Format:** Copy-paste ready commands

---

## Build Commands for Each Environment

### Local Development
```bash
# Start development servers (client + server)
npm run dev

# Start client only
npm run dev:client

# Start server only
npm run dev:server

# With memory limit
NODE_OPTIONS='--max-old-space-size=3072' npm run dev
```

### Local Production Test
```bash
# Build client for production
cd client && npm run build

# Serve client locally
npx serve -s dist -p 5173

# Build server for production
cd server && npm run build

# Start server with compiled code
node dist/server.js
```

### Vercel Deployment
```bash
# Deploy via CLI
vercel --prod

# Or push to main for auto-deploy
git push origin main

# Check deployment status
vercel ls

# View logs
vercel logs [deployment-url]
```

### Render Deployment
```bash
# Auto-deploys from main branch
git push origin main

# Manual deploy via dashboard
# https://dashboard.render.com/web/your-service

# View logs
# Dashboard → your-service → Logs
```

---

## Memory Flags and Limits

### Current Constraints
```bash
# Development (3GB)
NODE_OPTIONS='--max-old-space-size=3072'

# Build (3GB)
NODE_OPTIONS='--max-old-space-size=3072'

# Test (3GB with GC)
NODE_OPTIONS='--max-old-space-size=3072 --expose-gc'

# Production Target (1GB)
NODE_OPTIONS='--max-old-space-size=1024'
```

### Check Memory Usage
```bash
# Current memory usage
ps aux | grep node | awk '{print $6/1024 " MB " $11}'

# Watch memory in real-time
watch -n 1 "ps aux | grep node | awk '{print \$6/1024 \" MB \" \$11}'"

# Detailed memory breakdown
node --inspect server/src/server.ts
# Then: chrome://inspect
```

---

## Environment Variable Checklist

### Client Variables (VITE_ prefix)
```bash
VITE_API_BASE_URL=https://july25.onrender.com
VITE_SUPABASE_URL=https://xiwfhcikfdoshxwbtjxt.supabase.co
VITE_SUPABASE_ANON_KEY=[from Supabase dashboard]
VITE_DEFAULT_RESTAURANT_ID=11111111-1111-1111-1111-111111111111
VITE_USE_REALTIME_VOICE=true
VITE_DEBUG_VOICE=false
VITE_ENVIRONMENT=production
VITE_DEMO_PANEL=false
```

### Server Variables
```bash
# OpenAI
OPENAI_API_KEY=[from OpenAI dashboard]

# Supabase
SUPABASE_URL=https://xiwfhcikfdoshxwbtjxt.supabase.co
SUPABASE_SERVICE_KEY=[from Supabase dashboard]

# Authentication Secrets (64-char hex)
KIOSK_JWT_SECRET=[64 chars]
PIN_PEPPER=[64 chars]
DEVICE_FINGERPRINT_SALT=[64 chars]
STATION_TOKEN_SECRET=[64 chars]
WEBHOOK_SECRET=[64 chars]

# Configuration
DEFAULT_RESTAURANT_ID=11111111-1111-1111-1111-111111111111
PORT=3001
NODE_ENV=production
FRONTEND_URL=https://july25-client.vercel.app
ALLOWED_ORIGINS=https://july25-client.vercel.app,http://localhost:5173
```

### Validation Commands
```bash
# Validate environment configuration
npm run env:validate

# Check for drift
npm run docs:drift

# Generate new secret (64-char hex)
openssl rand -hex 32
```

---

## Deployment Rollback Steps

### Vercel Rollback (3 minutes)
```bash
# Option 1: Via CLI
vercel rollback [deployment-url]

# Option 2: Via Dashboard
# 1. https://vercel.com/your-team/july25-client/deployments
# 2. Find last good deployment
# 3. Click "..." → "Promote to Production"
```

### Render Rollback (5 minutes)
```bash
# Option 1: Via Dashboard
# 1. https://dashboard.render.com/web/your-service
# 2. Events tab → Find last good deploy
# 3. "Rollback to this deploy"

# Option 2: Git revert
git revert HEAD
git push origin main  # Auto-deploys
```

---

## Troubleshooting Quick Fixes

### "vite: command not found" in Vercel
```json
// vercel.json
{
  "installCommand": "npm ci --production=false --workspaces --include-workspace-root"
}
```

### "tsx: not found" in Render
```json
// server/package.json
{
  "scripts": {
    "start": "node dist/server.js"  // NOT "tsx src/server.ts"
  }
}
```

### Environment validation fails in CI
```typescript
// vite.config.ts
if (mode === 'production' && !process.env.CI) {
  // Only validate in actual production, not CI
}
```

### Memory limit exceeded
```json
// package.json
{
  "scripts": {
    "build": "NODE_OPTIONS='--max-old-space-size=3072' npm run build"
  }
}
```

### TypeScript compilation fails in Render
```json
// server/package.json
{
  "dependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^20.19.10",
    "typescript": "^5.3.3"
  }
}
```

---

## Critical File Locations

### Configuration Files
```
/vercel.json                           # Vercel deployment config
/package.json                          # Root workspace config
/client/package.json                   # Client dependencies
/server/package.json                   # Server dependencies
/shared/package.json                   # Shared types
```

### Environment Files
```
/.env.example                          # Root env documentation
/client/.env.example                   # Client env documentation
/server/.env.example                   # Server env documentation
/.env.local                           # Local development (gitignored)
```

### Schema Files
```
/server/src/config/env.schema.ts      # Server env validation
/client/src/config/env.schema.ts      # Client env validation
```

### Documentation
```
/docs/reference/config/ENVIRONMENT.md              # Environment reference
/docs/reference/config/VERCEL_RENDER_DEPLOYMENT.md # Deployment guide
/claude-lessons3/05-build-deployment-issues/       # This directory
```

---

## Pre-Deployment Checklist

Copy this before each deployment:

```
[ ] Environment variables validated: `npm run env:validate`
[ ] All tests passing: `npm test`
[ ] Type check clean: `npm run typecheck`
[ ] Memory usage acceptable: <3GB
[ ] Production build tested locally
[ ] No console.log statements added
[ ] Documentation updated
[ ] Rollback plan ready
[ ] Team notified of deployment
```

---

## Common Commands

### Install & Setup
```bash
# Clean install all workspaces
npm ci --production=false --workspaces --include-workspace-root

# Install single workspace
npm install --workspace=restaurant-os-client

# Clean everything
npm run clean:all
```

### Build
```bash
# Build all
npm run build:full

# Build client for Vercel
npm run build:vercel

# Build server for Render
npm run build:render

# Build with memory limit
NODE_OPTIONS='--max-old-space-size=3072' npm run build
```

### Test
```bash
# All tests
npm test

# Client tests only
npm run test:client

# Server tests only
npm run test:server

# E2E tests
npm run test:e2e

# With coverage
npm run test:coverage
```

### Type Checking
```bash
# Full type check
npm run typecheck

# Quick check (faster)
npm run typecheck:quick

# Watch mode
npm run typecheck -- --watch
```

### Deployment
```bash
# Deploy client to Vercel
vercel --prod

# Check Vercel status
vercel ls

# View Vercel logs
vercel logs [deployment-url]

# Render auto-deploys from main
git push origin main
```

### Monitoring
```bash
# Check backend health
curl https://july25.onrender.com/api/v1/health

# Check voice service
curl https://july25.onrender.com/api/v1/ai/voice/handshake

# Memory usage
ps aux | grep node

# Port usage
lsof -i :3001
lsof -i :5173
```

---

## Emergency Contacts

### Platforms
- **Vercel Dashboard:** https://vercel.com/your-team/july25-client
- **Render Dashboard:** https://dashboard.render.com/web/your-service
- **Supabase Dashboard:** https://app.supabase.com/project/xiwfhcikfdoshxwbtjxt
- **OpenAI Dashboard:** https://platform.openai.com/

### Documentation
- **Main Docs:** /Users/mikeyoung/CODING/rebuild-6.0/docs/
- **Build Issues:** /Users/mikeyoung/CODING/rebuild-6.0/claude-lessons3/05-build-deployment-issues/
- **CLAUDE.md:** /Users/mikeyoung/CODING/rebuild-6.0/CLAUDE.md

### Git
```bash
# Recent commits
git log --oneline -20

# Find who changed file
git blame [file]

# Find when line was added
git log -S "search term" -p

# View specific commit
git show [commit-hash]
```

---

## Quick Diagnosis Tree

```
Problem: Build failing
├─ Works locally?
│  ├─ YES → Environment difference
│  │  ├─ Check CI variable: process.env.CI
│  │  ├─ Check secrets configuration
│  │  └─ Check vercel.json installCommand
│  └─ NO → Local issue
│     ├─ Check dependencies: npm ci
│     ├─ Check build order: shared before client
│     └─ Check NODE_OPTIONS memory limit

Problem: Deployment failing
├─ Vercel?
│  ├─ Check vercel.json installCommand
│  ├─ Check --production=false flag
│  └─ Check buildCommand workspace order
└─ Render?
   ├─ Check start script uses node (not tsx)
   ├─ Check @types in dependencies
   └─ Check TypeScript compiles cleanly

Problem: Memory issues
├─ Check current usage: ps aux | grep node
├─ Check NODE_OPTIONS in package.json
├─ Check for memory leaks:
│  ├─ Intervals without clearInterval
│  ├─ Event listeners without cleanup
│  └─ Unbounded caches
└─ Optimize bundle: manual chunks in vite.config.ts

Problem: Environment variables
├─ Validate: npm run env:validate
├─ Check drift: npm run docs:drift
├─ Verify platform dashboards
│  ├─ Vercel: VITE_ variables
│  └─ Render: Server variables
└─ Check Zod schema matches .env.example
```

---

**Document Version:** 1.0.0
**Last Updated:** November 19, 2025
**Print This:** Keep a copy at your desk!

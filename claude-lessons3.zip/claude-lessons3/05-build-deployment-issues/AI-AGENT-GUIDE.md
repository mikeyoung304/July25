---
category: "build-deployment"
category_id: "05"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, vercel, monorepo, memory-limits, build-order, ci-cd]
---
# AI Agent Guide: Build & Deployment Issues

**Purpose:** Specific guidance for AI agents to avoid the 30-commit cascade
**Audience:** Claude Code, GitHub Copilot, Cursor AI, and other AI assistants
**Critical:** Read this BEFORE touching build/deployment configuration

---

## Core Principles for AI Agents

### 1. ALWAYS Check NODE_OPTIONS First

**Before suggesting ANY build command, check memory constraints:**

```typescript
// CORRECT: Check existing configuration
// Read package.json first
const packageJson = JSON.parse(fs.readFileSync('package.json', 'utf-8'));
const devScript = packageJson.scripts.dev;

// Look for NODE_OPTIONS
if (devScript.includes('NODE_OPTIONS')) {
  // Preserve existing memory limits
  // Example: NODE_OPTIONS='--max-old-space-size=3072'
}
```

**WRONG: Assume defaults or suggest increasing memory**
```typescript
// ❌ DON'T DO THIS
"dev": "npm run dev"  // Missing NODE_OPTIONS

// ❌ DON'T DO THIS
"dev": "NODE_OPTIONS='--max-old-space-size=8192' npm run dev"  // Too high!
```

**Rule:** If NODE_OPTIONS exists, PRESERVE THE EXACT VALUE. Don't increase without explicit user request.

---

### 2. Build Shared Workspace BEFORE Client

**Dependency Graph (memorize this):**
```
shared/ (no dependencies)
  ↓
client/ (depends on shared)
  ↓
server/ (depends on shared)
```

**CORRECT Build Order:**
```json
{
  "scripts": {
    "build:vercel": "npm run build --workspace=@rebuild/shared --if-present && npm run build --workspace=restaurant-os-client"
  }
}
```

**WRONG Build Order:**
```json
{
  "scripts": {
    "build:vercel": "npm run build --workspaces"  // ❌ Race condition!
  }
}
```

**Rule:** ALWAYS build shared first, then client/server. NEVER use `--workspaces` without explicit order.

---

### 3. Use --production=false for Vercel

**THE SINGLE MOST IMPORTANT VERCEL CONFIGURATION:**

```json
// vercel.json - CORRECT
{
  "installCommand": "npm ci --production=false --workspaces --include-workspace-root"
}
```

**Why this matters:**
- Vercel defaults to `npm ci --production` (excludes devDependencies)
- Build tools (vite, typescript) are often in devDependencies
- Without `--production=false`, builds fail with "command not found"

**NEVER suggest:**
```json
// ❌ WRONG - Missing --production=false
{
  "installCommand": "npm ci --workspaces"
}

// ❌ WRONG - Doesn't install workspace root
{
  "installCommand": "npm ci --production=false --workspaces"
}

// ❌ WRONG - NODE_ENV hack is outdated
{
  "installCommand": "NODE_ENV=development npm ci --workspaces"
}
```

---

### 4. Test with Production Builds Locally

**BEFORE suggesting deployment, tell user to test locally:**

```bash
# Test production build
cd client && npm run build

# Check if it actually works
npx serve -s dist -p 5173

# Test in browser
open http://localhost:5173
```

**Signs of successful production build:**
- No "command not found" errors
- No "cannot find module" errors
- No TypeScript compilation errors
- Assets load in browser

**If ANY of these fail locally, DO NOT deploy.**

---

### 5. Environment Parity Validation

**Always verify three environments match:**

1. **Local Development**
2. **CI/GitHub Actions** 
3. **Production/Vercel**

**Checklist for AI Agents:**
```typescript
// Check these in order:
1. Does vercel.json have correct installCommand?
2. Does package.json build:vercel have correct order?
3. Are NODE_OPTIONS consistent across environments?
4. Are environment variables validated conditionally?
5. Is production start script using compiled code?
```

**Example of environment-aware code:**
```typescript
// CORRECT: Environment-aware validation
if (mode === 'production' && !process.env.CI) {
  // Strict validation only for Vercel
  validateEnvironmentVariables();
} else if (mode === 'production' && process.env.CI) {
  // CI can skip validation
  console.warn('CI environment detected');
}
```

---

## Decision Trees for AI Agents

### When User Says: "Build is failing"

```
Step 1: Ask where it's failing
├─ Local? → Check dependencies and build order
├─ Vercel? → Check vercel.json installCommand
└─ Render? → Check start script and @types placement

Step 2: Check recent changes
├─ git log --oneline -5
└─ git diff HEAD~1

Step 3: Identify pattern
├─ "command not found" → Dependencies issue
├─ "cannot find module" → Build order issue
├─ "memory limit exceeded" → NODE_OPTIONS issue
└─ "environment variable" → Validation issue

Step 4: Apply specific fix (see patterns below)
```

---

### When User Says: "Fix deployment"

**DO NOT immediately suggest code changes. Follow this sequence:**

```
1. ✅ Ask diagnostic questions:
   - "Where is it failing? (Vercel/Render/CI)"
   - "What's the exact error message?"
   - "Did this work before? What changed?"

2. ✅ Verify configuration first:
   - Check vercel.json
   - Check package.json scripts
   - Check environment variables

3. ✅ Suggest verification commands:
   - "Let's test production build locally first"
   - "Can you run: npm run build"

4. ✅ THEN suggest fixes based on diagnostics
```

**DO NOT do this:**
```
❌ "Let's try moving everything to dependencies"
❌ "Try increasing memory to 8GB"
❌ "Add npx to all commands"
❌ "Let's rewrite the entire configuration"
```

---

## Common Mistakes AI Agents Make

### Mistake 1: The "npx Everything" Pattern

**WRONG:**
```json
{
  "scripts": {
    "build": "npx vite build",
    "dev": "npx vite",
    "typecheck": "npx tsc"
  }
}
```

**Why wrong:** npx downloads on every run, slow and unreliable

**CORRECT:**
```json
{
  "scripts": {
    "build": "vite build",
    "dev": "vite",
    "typecheck": "tsc"
  }
}
```

With proper vercel.json:
```json
{
  "installCommand": "npm ci --production=false --workspaces --include-workspace-root"
}
```

---

### Mistake 2: The "Move Everything to Dependencies" Pattern

**WRONG:**
```json
{
  "dependencies": {
    "vite": "5.4.19",
    "typescript": "^5.3.3",
    "eslint": "^9.31.0",
    "prettier": "^3.0.0",
    "vitest": "^1.0.0"
  }
}
```

**Why wrong:** Bloats production bundle, masks real issue

**CORRECT:**
```json
{
  "dependencies": {
    "@types/express": "^4.17.21",  // Needed for TS compilation
    "typescript": "^5.3.3"          // Needed for build
  },
  "devDependencies": {
    "eslint": "^9.31.0",            // Dev tool only
    "prettier": "^3.0.0",           // Dev tool only
    "vitest": "^1.0.0"              // Dev tool only
  }
}
```

With vercel.json `--production=false` flag.

---

### Mistake 3: The "Increase Memory Until It Works" Pattern

**WRONG:**
```json
{
  "scripts": {
    "build": "NODE_OPTIONS='--max-old-space-size=16384' npm run build"
  }
}
```

**Why wrong:** Masks memory leaks, not sustainable

**CORRECT:**
```json
{
  "scripts": {
    "build": "NODE_OPTIONS='--max-old-space-size=3072' npm run build"
  }
}
```

Then investigate actual memory leaks:
- Intervals without clearInterval
- Event listeners without cleanup
- Unbounded caches

---

### Mistake 4: The "Parallel Build Everything" Pattern

**WRONG:**
```json
{
  "scripts": {
    "build:vercel": "npm run build --workspaces"
  }
}
```

**Why wrong:** Race condition - client builds before shared compiles

**CORRECT:**
```json
{
  "scripts": {
    "build:vercel": "npm run build --workspace=@rebuild/shared --if-present && npm run build --workspace=restaurant-os-client"
  }
}
```

---

### Mistake 5: The "Suppress Errors" Pattern

**WRONG:**
```json
{
  "scripts": {
    "build": "tsc || true",
    "test": "vitest || exit 0"
  }
}
```

**Why wrong:** Hides real errors, deploys broken code

**CORRECT:**
```json
{
  "scripts": {
    "build": "tsc",
    "test": "vitest"
  }
}
```

Let failures fail. Fix the root cause.

---

## Verification Checklist for AI Agents

Before suggesting ANY deployment changes, verify:

```
Configuration Files:
[ ] vercel.json has --production=false flag
[ ] package.json build:vercel has correct order
[ ] package.json NODE_OPTIONS is 3072 (not higher)
[ ] No || true or || exit 0 in scripts
[ ] Start script uses node (not tsx) for Render

Dependencies:
[ ] @types packages in dependencies (for TS compilation)
[ ] Build tools accessible from workspace context
[ ] No duplicate installations of same package

Environment:
[ ] .env.example documents all variables
[ ] Environment validation is conditional (checks CI flag)
[ ] Platform dashboards configured

Testing:
[ ] Suggest local production build test BEFORE deploy
[ ] Check that build actually succeeds
[ ] Verify no "command not found" errors
```

---

## Response Templates for AI Agents

### Template: Build Failure Diagnosis

```markdown
I see the build is failing. Let me help diagnose this systematically:

**Step 1: Understanding the Error**
Can you share:
- The exact error message?
- Where it's failing? (Local/Vercel/Render/CI)
- The last few commits? (run: `git log --oneline -5`)

**Step 2: Quick Checks**
Let's verify the basics:
1. Check your vercel.json has this line:
   `"installCommand": "npm ci --production=false --workspaces --include-workspace-root"`

2. Check your package.json has this build order:
   `"build:vercel": "npm run build --workspace=@rebuild/shared --if-present && npm run build --workspace=restaurant-os-client"`

3. Try building locally:
   ```bash
   npm run build
   ```

**Step 3: Based on Error Type**
[Provide specific fix based on user's error message]
```

---

### Template: Memory Issue

```markdown
I see a memory error. Let's fix this properly (not just increase the limit):

**Current Memory Configuration:**
[Show current NODE_OPTIONS value]

**This is already at the safe limit (3GB). Instead of increasing, let's find the leak:**

1. **Check for interval leaks:**
   Search for `setInterval` without stored reference

2. **Check for event listener leaks:**
   Search for `addEventListener` without `removeEventListener`

3. **Check for cache leaks:**
   Search for Maps/Objects that grow unbounded

**Would you like me to scan for these patterns?**
```

---

### Template: Environment Variables

```markdown
Let's set up environment variables correctly:

**For Client (VITE_ prefix):**
These go in Vercel dashboard:
- VITE_API_BASE_URL
- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY
- [list all client vars]

**For Server:**
These go in Render dashboard:
- OPENAI_API_KEY
- KIOSK_JWT_SECRET
- [list all server vars]

**Validation:**
After updating:
1. Run: `npm run env:validate`
2. Test locally with production build
3. Deploy

**Important:** Never commit actual secrets to .env files. Use .env.example for documentation only.
```

---

## Learning from the 30-Commit Cascade

**What the agent should have done differently:**

1. **Commit 1-5** ("Just install vite")
   - ❌ Added packages without understanding root cause
   - ✅ Should have checked vercel.json installCommand first

2. **Commits 6-15** ("TypeScript nightmare")
   - ❌ Tried every possible PATH configuration
   - ✅ Should have recognized dependencies vs devDependencies issue

3. **Commits 16-25** ("Dependencies hell")
   - ❌ Moved packages randomly between dependencies/devDependencies
   - ✅ Should have understood Vercel's --production flag

4. **Commits 26-30** ("PostCSS problems")
   - ❌ Tried multiple configuration styles
   - ✅ Should have tested workspace module resolution

5. **Final Solution** (Commits 31-32)
   - ✅ Finally understood: Vercel needs --production=false
   - ✅ This should have been commit 1

**The root cause was a single configuration line:**
```json
"installCommand": "npm ci --production=false --workspaces --include-workspace-root"
```

**Lesson for AI Agents:**
- Check platform-specific documentation FIRST
- Understand build environment differences
- Test hypothesis before suggesting code changes
- Don't suggest 30 variations of the same wrong approach

---

## High-Risk Operations for AI Agents

**NEVER suggest these without explicit user request and verification:**

1. **Increasing memory beyond 3GB**
   - Current limit: 3072MB
   - Don't suggest higher without investigating leaks

2. **Changing workspace structure**
   - Monorepo structure is intentional
   - Don't suggest merging workspaces

3. **Removing environment validation**
   - Validation catches deployment issues
   - Don't suggest skipping validation globally

4. **Moving all devDependencies to dependencies**
   - Bloats production bundle
   - Fix install command instead

5. **Using --force or --legacy-peer-deps**
   - Masks dependency conflicts
   - Fix actual conflict instead

6. **Disabling TypeScript checks**
   - Type safety is important
   - Fix TypeScript errors instead

---

## Success Metrics for AI Agents

**A good AI agent response should:**
- ✅ Ask diagnostic questions before suggesting fixes
- ✅ Suggest testing locally before deployment
- ✅ Preserve existing working configuration
- ✅ Explain WHY a fix works, not just what to change
- ✅ Provide rollback instructions
- ✅ Reference documentation

**A bad AI agent response will:**
- ❌ Immediately suggest rewriting configuration
- ❌ Increase limits without investigating root cause
- ❌ Add npx/workarounds instead of proper fixes
- ❌ Suggest changes without testing them
- ❌ Ignore environment differences

---

## Final Checklist for AI Agents

Before responding to build/deployment questions:

```
[ ] Have I asked diagnostic questions?
[ ] Have I read the error message carefully?
[ ] Have I checked vercel.json configuration?
[ ] Have I verified package.json scripts?
[ ] Have I suggested local testing first?
[ ] Have I explained WHY my suggestion will work?
[ ] Have I avoided the 5 common mistakes?
[ ] Have I provided rollback instructions?
[ ] Would my suggestion have prevented the 30-commit cascade?
```

If you can't check all boxes, ask more questions instead of suggesting fixes.

---

## Resources for AI Agents

**Required Reading:**
- [PATTERNS.md](./PATTERNS.md) - Understand the patterns
- [INCIDENTS.md](./INCIDENTS.md) - Learn from past mistakes
- [PREVENTION.md](./PREVENTION.md) - Know the solutions

**Quick Reference:**
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Copy-paste commands

**Project Context:**
- `/Users/mikeyoung/CODING/rebuild-6.0/CLAUDE.md` - Project overview
- `/Users/mikeyoung/CODING/rebuild-6.0/docs/` - Full documentation

---

## Remember

**The 30-commit cascade happened because:**
1. Didn't check platform documentation first
2. Tried to fix symptoms instead of root cause
3. Didn't test hypotheses before committing
4. Didn't understand environment differences

**You can prevent this by:**
1. Asking diagnostic questions first
2. Understanding the system before suggesting changes
3. Testing locally before deploying
4. Learning from documented incidents

**When in doubt:**
- Ask more questions
- Suggest verification steps
- Reference documentation
- Test before deploying

---

**Document Version:** 1.0.0
**Last Updated:** November 19, 2025
**Target Audience:** All AI assistants working on this codebase
**Status:** Required reading before suggesting build/deployment changes

---
category: "build-deployment"
category_id: "05"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "PATTERNS"
tags: [vercel, monorepo, memory-limits, build-order, ci-cd]
---
# Build & Deployment Patterns

**Purpose:** Understand the patterns that cause build issues and how to avoid them
**Audience:** Developers and AI agents working with the monorepo
**Last Updated:** November 19, 2025

---

## Table of Contents

1. [Monorepo Workspace Compilation](#monorepo-workspace-compilation)
2. [Dependencies vs devDependencies](#dependencies-vs-devdependencies)
3. [Environment Variable Validation](#environment-variable-validation)
4. [Memory Constraint Management](#memory-constraint-management)
5. [CI vs Production Environment Differences](#ci-vs-production-environment-differences)
6. [Build Order Dependencies](#build-order-dependencies)

---

## Monorepo Workspace Compilation

### The Core Challenge

In a monorepo, **workspace context matters**. What works in local development may fail in CI/deployment because:

1. **PATH Resolution** - Different in root vs workspace
2. **Module Resolution** - Workspaces may not see root node_modules
3. **Build Tools** - Must be accessible from workspace context
4. **Configuration Files** - May need to be in workspace or root depending on tool

### Pattern: Local Works, Vercel Fails

#### Scenario
```bash
# Local development (WORKS)
npm run dev
npm run build

# Vercel deployment (FAILS)
ERROR: vite: command not found
```

#### Why It Happens

**Local:** npm run scripts execute with full PATH including root node_modules/.bin
```bash
$ npm run build
# Executes: ./node_modules/.bin/vite build
```

**Vercel:** Workspace build runs in isolated context
```bash
$ cd client && npm run build
# Executes: ../node_modules/.bin/vite build  # MAY NOT EXIST
```

#### Solution Pattern

**Option 1: Build from Root (Recommended)**
```json
// package.json (root)
{
  "scripts": {
    "build:vercel": "npm run build --workspace=@rebuild/shared --if-present && npm run build --workspace=restaurant-os-client"
  }
}
```

**Option 2: Install in Workspace**
```json
// client/package.json
{
  "dependencies": {
    "vite": "5.4.19"  // In dependencies, not devDependencies
  }
}
```

**Option 3: Use npx (Not Recommended)**
```json
// client/package.json
{
  "scripts": {
    "build": "npx vite build"  // Downloads on every build, slow
  }
}
```

---

### Pattern: TypeScript Compilation in Workspaces

#### The Problem
```bash
# Shared workspace needs TypeScript to compile
cd shared && npm run build
# ERROR: tsc: command not found
```

#### Why It Happens

TypeScript is in root devDependencies:
```json
// package.json (root)
{
  "devDependencies": {
    "typescript": "^5.3.3"
  }
}
```

But workspace tries to access it:
```json
// shared/package.json
{
  "scripts": {
    "build": "tsc -p tsconfig.build.json"
  }
}
```

#### Evolution of Solutions (30-Commit Cascade)

**Attempt 1:** Add to root devDependencies (Already there!)
```bash
# Still fails - workspace can't see it
```

**Attempt 2:** Use npx
```json
"build": "npx tsc -p tsconfig.build.json"
```
Result: Works but slow, downloads on every build

**Attempt 3:** Use npm exec
```json
"build": "npm exec tsc -- -p tsconfig.build.json"
```
Result: Still fails in Vercel

**Attempt 4:** Use full path
```json
"build": "../../node_modules/.bin/tsc -p tsconfig.build.json"
```
Result: Fragile, breaks if structure changes

**Attempt 5:** Move to workspace dependencies
```json
// shared/package.json
{
  "dependencies": {
    "typescript": "^5.3.3"
  }
}
```
Result: **WORKS** - But only because TypeScript is now in dependencies

**Attempt 6 (Final):** Build from root with workspace flag
```json
// package.json (root)
{
  "scripts": {
    "build:vercel": "npm run build --workspace=@rebuild/shared --if-present && npm run build --workspace=restaurant-os-client"
  }
}
```
Result: **OPTIMAL** - Clean, maintains workspace isolation, works everywhere

#### Rule of Thumb

**If a build tool is needed during `npm run build`:**
- Put it in `dependencies` (not `devDependencies`)
- OR ensure workspace builds run from root context
- OR install it in the specific workspace

---

### Pattern: PostCSS Plugin Resolution

#### The Problem
```bash
# Vercel build fails
Error: Cannot find module 'tailwindcss'
```

#### Why It Happens

PostCSS configuration in client workspace:
```javascript
// client/postcss.config.js
export default {
  plugins: [
    'tailwindcss',  // String reference
    'autoprefixer'
  ]
}
```

Plugins installed in root:
```json
// package.json (root)
{
  "devDependencies": {
    "tailwindcss": "^3.4.11",
    "autoprefixer": "^10.4.20"
  }
}
```

**Problem:** Workspace can't resolve string references to root node_modules

#### Solution: Use require.resolve()
```javascript
// client/postcss.config.js
export default {
  plugins: [
    require('tailwindcss'),  // Direct require
    require('autoprefixer')
  ]
}
```

Or move postcss.config.js to root:
```javascript
// postcss.config.js (root)
export default {
  plugins: [
    'tailwindcss',
    'autoprefixer'
  ]
}
```

---

## Dependencies vs devDependencies

### The Critical Distinction

In a monorepo, the difference between `dependencies` and `devDependencies` determines **what gets installed in production/CI builds**.

### Pattern: Vercel Installs with --production

#### Default Behavior
```bash
# Vercel's default install command
npm ci --production

# This installs:
# ✅ dependencies
# ❌ devDependencies (EXCLUDED)
```

#### Why This Breaks Builds

If your build tools are in devDependencies:
```json
// package.json
{
  "devDependencies": {
    "vite": "5.4.19",
    "typescript": "^5.3.3",
    "tailwindcss": "^3.4.11"
  }
}
```

Then `npm ci --production` doesn't install them, and build fails.

#### Solution 1: Custom Install Command (Recommended)

```json
// vercel.json
{
  "installCommand": "npm ci --production=false --workspaces --include-workspace-root"
}
```

**Explanation:**
- `--production=false` - Install devDependencies too
- `--workspaces` - Install all workspace dependencies
- `--include-workspace-root` - Install root dependencies

#### Solution 2: Move Build Tools to dependencies

```json
// package.json
{
  "dependencies": {
    "vite": "5.4.19",
    "typescript": "^5.3.3",
    "@vitejs/plugin-react": "^4.5.2"
  }
}
```

**Trade-off:** Larger production bundle, but more predictable builds

#### Solution 3: NODE_ENV Override (Hacky)

```json
// vercel.json
{
  "installCommand": "NODE_ENV=development npm ci --workspaces"
}
```

**Problem:** npm checks NODE_ENV to decide production flag
**Issue:** Can confuse other tools that read NODE_ENV

---

### Pattern: @types Packages in Monorepo

#### The Render Deployment Issue

**Problem:** TypeScript compilation fails in production
```bash
# Render build
npm run build
# ERROR: Cannot find module '@types/express'
```

#### Why It Happens

TypeScript needs @types packages to compile, but they're in devDependencies:
```json
// server/package.json (WRONG)
{
  "devDependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^20.19.10",
    "@types/jsonwebtoken": "^9.0.6"
  }
}
```

Render runs:
```bash
npm ci --production  # Skips devDependencies
npm run build        # TypeScript can't find @types
```

#### Solution: Move @types to dependencies

```json
// server/package.json (CORRECT)
{
  "dependencies": {
    "@types/express": "^4.17.21",
    "@types/node": "^20.19.10",
    "@types/jsonwebtoken": "^9.0.6"
  }
}
```

**Why This Works:**
- @types packages are needed at BUILD TIME
- Production builds compile TypeScript
- @types in dependencies ensures they're always available

**Why This is OK:**
- @types packages are tiny (~100KB total)
- No runtime cost (only used during compilation)
- Ensures build reproducibility

---

## Environment Variable Validation

### Pattern: Context-Aware Validation

#### The Problem

Environment validation that works everywhere:
```typescript
// client/vite.config.ts
if (mode === 'production') {
  const required = ['VITE_API_BASE_URL', 'VITE_SUPABASE_URL'];
  const missing = required.filter(key => !process.env[key]);
  if (missing.length > 0) {
    throw new Error(`Missing: ${missing.join(', ')}`);
  }
}
```

**Issue:** This fails in CI where production secrets aren't available.

#### Three Build Contexts

1. **Local Development** - Reads from `.env` file
2. **CI/GitHub Actions** - No secrets, builds for testing only
3. **Production/Vercel** - Reads from platform environment variables

#### Solution: Environment Detection

```typescript
// client/vite.config.ts
if (mode === 'production' && !process.env.CI) {
  // Strict validation only for actual production deployments
  const required = ['VITE_API_BASE_URL', 'VITE_SUPABASE_URL'];
  const missing = required.filter(key => !process.env[key]);

  if (missing.length > 0) {
    throw new Error(`Missing required environment variables: ${missing.join(', ')}`);
  }
} else if (mode === 'production' && process.env.CI) {
  console.warn('⚠️  CI environment detected - skipping strict env validation');
  console.warn('   Production builds on Vercel will still enforce strict validation');
}
```

**Benefits:**
- ✅ Local production builds work without secrets
- ✅ CI can build for smoke tests
- ✅ Actual production deployment still validates strictly
- ✅ Clear warnings in each context

---

### Pattern: Zod Schema Validation

#### Recommended Approach

Use Zod for runtime validation with environment-aware fallbacks:

```typescript
// server/src/config/env.schema.ts
import { z } from 'zod';

const envSchema = z.object({
  OPENAI_API_KEY: z.string().min(1),
  KIOSK_JWT_SECRET: z.string().min(32).optional(), // Optional for dev
  SUPABASE_URL: z.string().url(),
  SUPABASE_SERVICE_KEY: z.string().min(1),
});

export function validateEnv() {
  const result = envSchema.safeParse(process.env);

  if (!result.success) {
    if (process.env.NODE_ENV === 'production') {
      throw new Error(`Invalid environment variables: ${result.error.message}`);
    } else {
      console.warn('⚠️  Development mode: Some env vars missing', result.error.format());
    }
  }

  return result.data;
}
```

#### Benefits of Zod

1. **Type Safety** - Generated types match runtime validation
2. **Clear Errors** - Zod provides detailed validation errors
3. **Transformations** - Auto-trim whitespace, parse numbers, etc.
4. **Optional vs Required** - Different rules for dev vs prod
5. **Documentation** - Schema IS documentation

---

### Pattern: Environment File Consolidation

#### Before: 15 .env Files (CHAOS)

```
.env
.env.local
.env.production
.env.development
.env.test
client/.env
client/.env.local
client/.env.example
server/.env
server/.env.local
server/.env.test
server/.env.example
supabase/.env
tests/.env
.env.example
```

**Problems:**
- Same variable with different values across files
- No single source of truth
- Drift detection impossible
- 80% inconsistency rate

#### After: 3 .env Files (ORDER)

```
.env.example              # Root - lists ALL variables
client/.env.example       # Client-specific (VITE_ prefix)
server/.env.example       # Server-specific
```

**Development:**
```
.env.local               # Developer's local overrides (gitignored)
```

**Rules:**
1. **.env.example** - Committed, documents ALL variables
2. **.env.local** - Gitignored, developer's actual values
3. **Platform Dashboards** - Production values (Vercel, Render)
4. **Zod Validation** - Enforces consistency

---

## Memory Constraint Management

### The Memory Journey: 12GB → 3GB → 1GB (target)

#### Why Memory Matters

Node.js default heap: **512MB**
Vite development: **2-4GB**
Our target: **1GB production, 3GB development**

Without constraints → memory leaks grow unchecked → OOM crashes

### Pattern: NODE_OPTIONS Configuration

#### Correct Usage

```json
// package.json
{
  "scripts": {
    "dev": "NODE_OPTIONS='--max-old-space-size=3072' concurrently \"npm run dev:server\" \"npm run dev:client\"",
    "build": "NODE_OPTIONS='--max-old-space-size=3072' npm run build:client",
    "test": "NODE_OPTIONS='--max-old-space-size=3072 --expose-gc' npm test"
  }
}
```

**Values:**
- 3072 = 3GB (current safe limit)
- 2048 = 2GB (intermediate goal)
- 1024 = 1GB (production target)

#### Anti-Pattern: Global NODE_OPTIONS

```bash
# DON'T DO THIS (affects all Node processes)
export NODE_OPTIONS='--max-old-space-size=8192'
```

**Why Bad:**
- Affects ALL Node.js processes system-wide
- Masks memory issues
- Makes debugging harder
- Not reproducible across environments

#### Pattern: Vite Memory Configuration

```typescript
// vite.config.ts
export default defineConfig({
  build: {
    rollupOptions: {
      output: {
        manualChunks: {
          vendor: ['react', 'react-dom'],
          charts: ['recharts'],
          forms: ['react-hook-form', 'zod']
        }
      }
    }
  }
});
```

**Why Manual Chunks Help:**
- Splits large bundles into smaller pieces
- Reduces peak memory during build
- Improves load-time performance
- Enables better caching

---

### Pattern: Memory Leak Detection

#### Common Leak Sources

1. **Event Listeners Without Cleanup**
```typescript
// BAD
componentDidMount() {
  window.addEventListener('resize', this.handler);
}

// GOOD
componentDidMount() {
  window.addEventListener('resize', this.handler);
}

componentWillUnmount() {
  window.removeEventListener('resize', this.handler);
}
```

2. **Intervals Without Clearing**
```typescript
// BAD
setInterval(() => this.cleanup(), 60000);

// GOOD
private interval: NodeJS.Timeout | null = null;

start() {
  this.interval = setInterval(() => this.cleanup(), 60000);
}

stop() {
  if (this.interval) {
    clearInterval(this.interval);
    this.interval = null;
  }
}
```

3. **Unbounded Caches**
```typescript
// BAD
const cache = {};
function addToCache(key, value) {
  cache[key] = value; // Grows forever
}

// GOOD
const cache = new Map();
const MAX_SIZE = 1000;

function addToCache(key, value) {
  if (cache.size >= MAX_SIZE) {
    const firstKey = cache.keys().next().value;
    cache.delete(firstKey);
  }
  cache.set(key, value);
}
```

#### Detection Commands

```bash
# Monitor heap usage
node --expose-gc --inspect server/src/server.ts

# Take heap snapshot
kill -USR2 <pid>

# Analyze in Chrome DevTools
chrome://inspect
```

---

## CI vs Production Environment Differences

### Pattern: Environment Detection

#### Five Environments to Consider

1. **Local Development** (`NODE_ENV=development`)
2. **Local Production Build** (`NODE_ENV=production`, no CI)
3. **CI/GitHub Actions** (`NODE_ENV=production`, `CI=true`)
4. **Staging/Preview** (`NODE_ENV=production`, Vercel preview)
5. **Production** (`NODE_ENV=production`, Vercel production)

#### Detection Pattern

```typescript
const isCI = process.env.CI === 'true';
const isProduction = process.env.NODE_ENV === 'production';
const isVercel = process.env.VERCEL === '1';
const isPreview = process.env.VERCEL_ENV === 'preview';

if (isProduction && !isCI) {
  // Actual production deployment - strict validation
} else if (isProduction && isCI) {
  // CI build - lenient validation
} else {
  // Development - helpful warnings
}
```

---

### Pattern: CI-Specific Tolerances

#### Example: Timing Tests

```typescript
// server/tests/security/webhook.proof.test.ts
const avgTime = timings.reduce((a, b) => a + b) / timings.length;

// CI runners have more variance due to shared resources
const varianceTolerance = process.env.CI ? 3.0 : 2.0;  // 3x for CI, 2x for local
const maxVariance = avgTime * varianceTolerance;

for (const timing of timings) {
  const variance = Math.abs(timing - avgTime);
  expect(variance).toBeLessThan(maxVariance);
}
```

**Why:**
- GitHub Actions runners are shared and variable performance
- Local machines are more consistent
- Test should verify BEHAVIOR (constant-time algorithm) not absolute performance

---

### Pattern: Environment Parity Checklist

Before deploying, verify parity across all environments:

**Dependencies:**
- [ ] Same Node.js version (20.x)
- [ ] Same npm version (10.7.0)
- [ ] Same package-lock.json
- [ ] Dependencies match devDependencies needs

**Environment Variables:**
- [ ] All required vars documented in .env.example
- [ ] Zod schema matches .env.example
- [ ] Platform dashboards match schema
- [ ] No hardcoded secrets in code

**Build Process:**
- [ ] Same build command in all environments
- [ ] Same NODE_OPTIONS constraints
- [ ] Workspace build order documented
- [ ] PostCSS/Vite/TS accessible from workspace

**Runtime:**
- [ ] Same start command
- [ ] Same port configuration
- [ ] Same database connection
- [ ] Same API endpoints

---

## Build Order Dependencies

### Pattern: Workspace Dependency Graph

```
shared/         (No dependencies)
    ↓
client/         (Depends on shared)
    ↓
server/         (Depends on shared)
```

#### Correct Build Order

```bash
# Option 1: Sequential
npm run build --workspace=@rebuild/shared --if-present
npm run build --workspace=restaurant-os-client
npm run build --workspace=restaurant-os-server

# Option 2: Parallel (if independent after shared)
npm run build --workspace=@rebuild/shared && \
npm run build --workspace=restaurant-os-client & \
npm run build --workspace=restaurant-os-server & \
wait
```

#### Incorrect Build Order (FAILS)

```bash
# BAD: Client before shared
npm run build --workspace=restaurant-os-client  # ERROR: Cannot find module 'shared/types'
npm run build --workspace=@rebuild/shared

# BAD: All in parallel
npm run build --workspaces  # Race condition, may fail randomly
```

---

### Pattern: Detecting Build Order Issues

#### Symptoms

```bash
# Build works sometimes, fails other times (race condition)
npm run build  # Success
npm run build  # Success
npm run build  # ERROR: Cannot find module 'shared/types'

# Build fails in CI but works locally
npm run build  # Local: Success
# CI: ERROR
```

#### Diagnosis

```bash
# Check import timestamps
ls -la client/dist/
ls -la shared/dist/

# If shared/dist is NEWER than client/dist → build order issue
```

#### Solution

```json
// package.json
{
  "scripts": {
    "prebuild:client": "npm run build --workspace=@rebuild/shared --if-present",
    "build:client": "npm run build --workspace=restaurant-os-client"
  }
}
```

Using `prebuild` prefix ensures correct order automatically.

---

## Summary: Pattern Recognition

### When You See... It Means...

| Symptom | Pattern | Solution |
|---------|---------|----------|
| "command not found" in Vercel | Workspace PATH issue | Build from root OR add to dependencies |
| Works locally, fails CI | Environment difference | Check NODE_ENV, CI variable, secrets |
| Random build failures | Race condition | Fix build order, use `--if-present` |
| Memory errors | Heap limit exceeded | Check NODE_OPTIONS, fix memory leaks |
| "Cannot find module '@types/*'" | Missing build dependencies | Move @types to dependencies |
| PostCSS errors in CI | Plugin resolution | Use require() or move config to root |
| Environment validation fails | Missing secrets | Context-aware validation |

### Quick Decision Tree

```
Build failing?
    ↓
Works locally?
    YES → Environment difference (check CI variable, secrets)
    NO → Local issue (check dependencies, build order)
        ↓
    CI only?
        YES → Check environment variables, dependencies vs devDependencies
        NO → Check vercel.json, installCommand
            ↓
        Vercel only?
            YES → Monorepo workspace issue (PATH, module resolution)
            NO → Memory issue? (check heap size)
```

---

## Next Steps

- **For Prevention:** See [PREVENTION.md](./PREVENTION.md)
- **For Quick Fixes:** See [QUICK-REFERENCE.md](./QUICK-REFERENCE.md)
- **For AI Agents:** See [AI-AGENT-GUIDE.md](./AI-AGENT-GUIDE.md)
- **For Incidents:** See [INCIDENTS.md](./INCIDENTS.md)

---

**Last Updated:** November 19, 2025
**Document Version:** 1.0.0
**Maintainer:** Engineering Team

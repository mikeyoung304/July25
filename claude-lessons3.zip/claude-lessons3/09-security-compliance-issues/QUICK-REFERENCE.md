---
category: "security-compliance"
category_id: "09"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, multi-tenancy, rbac, audit-logging, credentials, rls]
---
# Security Quick Reference Guide

Fast reference for developers implementing security-sensitive features. Use this as a checklist when writing authentication, authorization, payment, or multi-tenancy code.

---

## Security Checklist for New Features

```
[ ] Middleware ordered correctly (auth → validation → business logic)
[ ] Multi-tenancy validated at 3 layers (middleware, service, DB)
[ ] JWT secrets validated at startup (no fallbacks)
[ ] Environment guards check multiple platform flags
[ ] Rate limiting appropriate for operation cost
[ ] Audit logging happens BEFORE state changes
[ ] No secrets in code or git history
[ ] Error messages don't leak sensitive data
[ ] Cross-tenant attack tests written
[ ] RBAC permissions checked
```

---

## Middleware Order Template

Use this exact order for all protected routes:

```typescript
import { authenticate } from './middleware/auth';
import { validateRestaurantAccess } from './middleware/restaurantAccess';
import { requireScope } from './middleware/rbac';
import { errorHandler } from './middleware/errorHandler';

// Protected route with multi-tenancy
app.use('/api/v1/orders',
  authenticate,                    // 1. Verify JWT
  validateRestaurantAccess,        // 2. Validate restaurant access
  requireScope(['orders:read']),   // 3. Check RBAC
  orderRoutes                      // 4. Business logic
);

// Error handler MUST be last
app.use(errorHandler);
```

### Middleware Responsibilities

| Middleware | Purpose | Sets |
|-----------|---------|------|
| `authenticate` | Verify JWT, extract user | `req.user` |
| `validateRestaurantAccess` | Validate restaurant access | `req.restaurantId`, `req.restaurantRole` |
| `requireScope` | Check RBAC permissions | (none) |
| `errorHandler` | Format errors, log | (none) |

**Critical**: Never set `req.restaurantId` in `authenticate` middleware!

---

## JWT Validation Rules

### Startup Validation

```typescript
// ✅ DO: Validate at startup (fail-fast)
export function validateEnvironment(): void {
  if (!env.SUPABASE_JWT_SECRET) {
    throw new Error('SUPABASE_JWT_SECRET is required');
  }

  if (env.SUPABASE_JWT_SECRET.length < 32) {
    throw new Error('SUPABASE_JWT_SECRET too short');
  }

  logger.info('✅ JWT authentication configured');
}
```

### Runtime Validation

```typescript
// ✅ DO: Single secret, no fallbacks
export async function authenticate(req, res, next): Promise<void> {
  const jwtSecret = config.supabase.jwtSecret;

  if (!jwtSecret) {
    throw new Error('Server authentication not configured');
  }

  const decoded = jwt.verify(token, jwtSecret); // Single secret
  req.user = { id: decoded.sub, ... };
  next();
}
```

### What NOT to Do

```typescript
// ❌ DON'T: Fallback to empty string
jwtSecret: env.SUPABASE_JWT_SECRET || ''

// ❌ DON'T: Multiple fallback secrets
jwt.verify(token, secret1) || jwt.verify(token, secret2)

// ❌ DON'T: Skip validation in any environment
if (env.NODE_ENV !== 'production') { return next(); }
```

---

## Environment Guards

### Pattern

```typescript
// ✅ DO: Check NODE_ENV AND platform flags
export function isLocalDevelopment(): boolean {
  return process.env['NODE_ENV'] === 'development'
    && process.env['RENDER'] !== 'true'
    && process.env['VERCEL'] !== '1'
    && process.env['HEROKU'] !== 'true'
    && !process.env['AWS_EXECUTION_ENV'];
}

// Usage
if (isLocalDevelopment() && token === 'test-token') {
  // Allow test token ONLY in local dev
}
```

### Platform Detection

| Platform | Variable | Value |
|----------|----------|-------|
| Render | `RENDER` | `"true"` |
| Vercel | `VERCEL` | `"1"` |
| Heroku | `HEROKU` | `"true"` |
| AWS Lambda | `AWS_EXECUTION_ENV` | (any) |

### What NOT to Do

```typescript
// ❌ DON'T: Only check NODE_ENV
if (process.env['NODE_ENV'] === 'development') {
  // BUG: Works on Render/Vercel if they set NODE_ENV=development
}
```

---

## Multi-Tenancy Validation

### Service Method Pattern

```typescript
// ✅ DO: Always include restaurant_id filter
export class OrdersService {
  static async getOrder(
    orderId: string,
    restaurantId: string // REQUIRED parameter
  ): Promise<Order | null> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId) // REQUIRED filter
      .single();

    return data;
  }
}
```

### Database Query Checklist

Every query MUST include:

```
[ ] .eq('restaurant_id', restaurantId)
[ ] restaurantId parameter required
[ ] Return 404 for cross-tenant access (not 403)
```

### Testing Pattern

```typescript
it('should prevent cross-restaurant access', async () => {
  const restaurant1Token = createToken({ restaurant_id: R1_ID });
  const restaurant2Order = await createOrder(R2_ID);

  await request(app)
    .get(`/api/v1/orders/${restaurant2Order.id}`)
    .set('Authorization', `Bearer ${restaurant1Token}`)
    .set('X-Restaurant-ID', R1_ID)
    .expect(404); // Not 403 - don't leak existence
});
```

---

## Audit Logging Patterns

### Two-Phase Pattern

```typescript
// Phase 1: Log BEFORE action
await logPaymentAttempt({
  orderId,
  status: 'initiated',
  restaurantId,
  amount,
  idempotencyKey,
  ...context
});

// Phase 2: Perform action
const result = await externalApi.call();

// Phase 3: Update log
await updatePaymentAuditStatus(
  idempotencyKey,
  result.success ? 'success' : 'failed',
  result.id
);
```

### Fail-Fast Enforcement

```typescript
// ✅ DO: Throw if audit fails
static async logPaymentAttempt(data): Promise<void> {
  const { error } = await supabase
    .from('payment_audit_logs')
    .insert(data);

  if (error) {
    logger.error('CRITICAL: Audit failed', { error });
    throw new Error('Payment unavailable - audit system failure');
  }
}
```

### What to Log

```
[ ] User ID (if authenticated)
[ ] IP address
[ ] User agent
[ ] Restaurant ID
[ ] Timestamp
[ ] Operation type
[ ] Status (initiated/success/failed)
[ ] Error details (if failed)
[ ] Idempotency key
```

---

## Rate Limiting Quick Config

### By Cost Tier

```typescript
// Tier 1: General API (moderate)
windowMs: 15 * 60 * 1000,
max: isLocalDev ? 10000 : 1000,
keyGenerator: (req) => req.restaurantId || req.ip

// Tier 2: AI Services (expensive)
windowMs: 5 * 60 * 1000,
max: isLocalDev ? 100 : 50,
keyGenerator: (req) => req.user?.id || req.ip

// Tier 3: Transcription (very expensive)
windowMs: 1 * 60 * 1000,
max: isLocalDev ? 30 : 20,
keyGenerator: (req) => req.user?.id || req.ip

// Tier 4: Auth (security-critical)
windowMs: 15 * 60 * 1000,
max: 5,
keyGenerator: (req) => req.ip,
skipSuccessfulRequests: true
```

### Application

```typescript
app.use('/api/v1/auth', authLimiter);
app.use('/api/v1/ai', aiServiceLimiter);
app.use('/api/v1/realtime/transcribe', transcriptionLimiter);
app.use('/api/v1', apiLimiter);
```

---

## Secret Management

### Pre-Commit Hook

```bash
# .husky/pre-commit
if git diff --cached --name-only | grep -E "^\.env(\.|$)"; then
  echo "🚨 ERROR: Attempting to commit .env file"
  exit 1
fi
```

### .gitignore

```gitignore
.env
.env.*
!.env.example
*.key
*.pem
*credentials*.json
```

### Startup Validation

```typescript
const requiredSecrets = [
  'SUPABASE_JWT_SECRET',
  'KIOSK_JWT_SECRET',
  'SQUARE_ACCESS_TOKEN',
  'PIN_PEPPER'
];

requiredSecrets.forEach(key => {
  if (!process.env[key]) {
    throw new Error(`${key} is required`);
  }
});
```

---

## Error Handling

### What to Return

```typescript
// ✅ DO: Generic error messages
throw Unauthorized('Invalid token');
throw Forbidden('Access denied');
throw NotFound('Resource not found');

// ❌ DON'T: Leak sensitive info
throw new Error('User john@restaurant2.com not authorized');
throw new Error('Order belongs to restaurant 22222222-2222-...');
```

### Status Codes

| Code | Meaning | Use Case |
|------|---------|----------|
| 401 | Unauthorized | Missing/invalid JWT |
| 403 | Forbidden | Authenticated but no access |
| 404 | Not Found | Cross-tenant access (hide existence) |
| 429 | Too Many Requests | Rate limit exceeded |
| 500 | Internal Server Error | System failures |

---

## RBAC Scope Patterns

### JWT Scopes

```typescript
// JWT payload includes scopes array
{
  sub: 'user-123',
  role: 'server',
  restaurant_id: 'restaurant-123',
  scope: ['orders:read', 'orders:create', 'payments:create']
}
```

### Middleware Usage

```typescript
// Require specific scopes
app.use('/api/v1/orders',
  authenticate,
  validateRestaurantAccess,
  requireScope(['orders:read', 'orders:create']),
  orderRoutes
);

// Check for any of multiple scopes
requireScope(['orders:manage', 'admin:*'])
```

### Common Scopes

| Scope | Permissions |
|-------|------------|
| `orders:read` | View orders |
| `orders:create` | Create orders |
| `orders:update` | Update order status |
| `orders:delete` | Delete orders |
| `payments:create` | Process payments |
| `menu:manage` | Edit menu |
| `reports:view` | View analytics |
| `admin:*` | Full admin access |

---

## Testing Checklist

Security tests to write for every feature:

```
[ ] Happy path with valid credentials
[ ] Missing JWT token (401)
[ ] Invalid JWT token (401)
[ ] Expired JWT token (401)
[ ] Cross-restaurant access attempt (403 or 404)
[ ] Missing required scope (403)
[ ] Header spoofing attempt (403)
[ ] Rate limit exceeded (429)
[ ] Audit logging failure (500)
[ ] Environment bypass in production (401)
```

---

## Common Security Mistakes

### 1. Setting restaurantId Too Early

```typescript
// ❌ WRONG
export async function authenticate(req, res, next) {
  req.user = jwt.verify(token, secret);
  req.restaurantId = req.headers['x-restaurant-id']; // TOO EARLY
}

// ✅ CORRECT
export async function authenticate(req, res, next) {
  req.user = jwt.verify(token, secret);
  // Don't set restaurantId here - let validateRestaurantAccess do it
}
```

### 2. Only Checking NODE_ENV

```typescript
// ❌ WRONG
if (process.env['NODE_ENV'] === 'development') {
  // Bypasses work on production platforms!
}

// ✅ CORRECT
if (isLocalDevelopment()) {
  // Checks NODE_ENV AND platform flags
}
```

### 3. Logging After State Changes

```typescript
// ❌ WRONG
await externalApi.charge(amount);
await logAudit({ status: 'success' }); // If this fails, no audit!

// ✅ CORRECT
await logAudit({ status: 'initiated' });
await externalApi.charge(amount);
await updateAudit({ status: 'success' });
```

### 4. Missing restaurant_id Filter

```typescript
// ❌ WRONG
const order = await supabase
  .from('orders')
  .select('*')
  .eq('id', orderId) // Missing restaurant_id!
  .single();

// ✅ CORRECT
const order = await supabase
  .from('orders')
  .select('*')
  .eq('id', orderId)
  .eq('restaurant_id', restaurantId) // REQUIRED
  .single();
```

### 5. Returning 403 for Cross-Tenant

```typescript
// ❌ WRONG
if (order.restaurant_id !== req.restaurantId) {
  throw Forbidden('Not your order'); // Leaks order existence
}

// ✅ CORRECT
if (order.restaurant_id !== req.restaurantId) {
  throw NotFound('Order not found'); // Hides existence
}
```

---

## Emergency Response

If you discover a security vulnerability:

1. **DO NOT commit the fix yet** - assess scope first
2. **Notify technical lead immediately**
3. **Determine if credentials are exposed**
4. **Revoke compromised credentials**
5. **Document the incident**
6. **Implement fix with tests**
7. **Deploy emergency patch**
8. **Monitor for suspicious activity**

---

## References

- [PATTERNS.md](./PATTERNS.md) - Detailed pattern explanations
- [INCIDENTS.md](./INCIDENTS.md) - Historical incident reports
- [PREVENTION.md](./PREVENTION.md) - Complete prevention guides
- [ADR-009](../../docs/explanation/architecture-decisions/ADR-009-error-handling-philosophy.md) - Error handling philosophy
- [SECURITY.md](../../docs/SECURITY.md) - Security policies

---

**Last Updated**: 2025-11-19
**Version**: 1.0
**For**: Developers implementing security-sensitive features

---
category: "security-compliance"
category_id: "09"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, multi-tenancy, rbac, audit-logging, credentials, rls]
---
# AI Agent Security Guide

**Purpose**: Security rules and patterns for AI assistants working on the Restaurant OS codebase.

**Audience**: Claude Code, GitHub Copilot, Cursor, and other AI coding assistants.

---

## Critical Security Rules

### Rule #1: Never Commit Credentials

**DO NOT** generate, suggest, or commit code containing:
- API keys, tokens, or secrets
- Database passwords or connection strings
- JWT secrets or encryption keys
- OAuth client secrets
- Payment provider credentials (Square, Stripe, etc.)
- Service account keys
- SSH private keys

**Instead**:
- Use environment variables: `process.env['SECRET_NAME']`
- Reference `.env.example` for required variables
- Suggest adding to environment configuration
- Document required secrets in README

```typescript
// ❌ NEVER do this
const apiKey = 'sk_live_abc123...';
const jwtSecret = 'mysecret123';

// ✅ ALWAYS do this
const apiKey = process.env['SQUARE_ACCESS_TOKEN'];
const jwtSecret = process.env['SUPABASE_JWT_SECRET'];
```

---

### Rule #2: Validate Before Trusting Headers

**DO NOT** trust HTTP headers without validation:
- `X-Restaurant-ID` - User can manipulate
- `X-User-ID` - User can manipulate
- `X-Role` - User can manipulate

**ALWAYS**:
- Extract user from verified JWT
- Validate restaurant access via database
- Set request properties AFTER validation

```typescript
// ❌ NEVER set from header directly
export async function authenticate(req, res, next) {
  req.restaurantId = req.headers['x-restaurant-id']; // DANGEROUS
  next();
}

// ✅ ALWAYS validate first
export async function validateRestaurantAccess(req, res, next) {
  const requestedId = req.headers['x-restaurant-id'];

  // Database lookup to verify access
  const access = await verifyUserAccess(req.user.id, requestedId);

  if (!access) {
    throw Forbidden('Access denied');
  }

  // ONLY set after validation
  req.restaurantId = requestedId;
  next();
}
```

---

### Rule #3: Audit Before State Changes

**DO NOT** log after changing state:
- Payments: Log BEFORE charging customer
- Refunds: Log BEFORE processing refund
- Deletions: Log BEFORE deleting data
- Updates: Log BEFORE modifying records

**Pattern**: Two-Phase Audit Logging

```typescript
// ❌ NEVER log after the action
async function processPayment(amount) {
  const result = await squareApi.charge(amount); // Charged!
  await logAudit({ status: 'success' }); // If this fails, no audit!
  return result;
}

// ✅ ALWAYS log before and update after
async function processPayment(amount) {
  // Phase 1: Log intent before action
  await logAudit({
    status: 'initiated',
    amount,
    idempotencyKey
  });

  // Phase 2: Perform action
  const result = await squareApi.charge(amount);

  // Phase 3: Update audit log
  await updateAudit({
    idempotencyKey,
    status: result.success ? 'success' : 'failed',
    paymentId: result.id
  });

  return result;
}
```

---

### Rule #4: Test With Production-Like Security

**DO NOT** suggest tests that:
- Skip authentication
- Bypass multi-tenancy validation
- Use mock security without real validation
- Disable rate limiting
- Remove RBAC checks

**ALWAYS**:
- Create valid JWT tokens for tests
- Test cross-restaurant access prevention
- Verify rate limiting works
- Check RBAC permissions
- Test with multiple tenants

```typescript
// ❌ NEVER skip security in tests
describe('Orders API', () => {
  beforeEach(() => {
    // Mock auth to always pass
    vi.mock('./middleware/auth', () => ({
      authenticate: (req, res, next) => {
        req.user = { id: 'test-user' };
        next(); // No validation!
      }
    }));
  });
});

// ✅ ALWAYS use real security validation
describe('Orders API', () => {
  let restaurant1Token: string;
  let restaurant2Token: string;

  beforeEach(() => {
    // Create REAL JWT tokens with proper signing
    restaurant1Token = jwt.sign(
      { sub: 'user-1', restaurant_id: RESTAURANT_1_ID },
      testJwtSecret
    );

    restaurant2Token = jwt.sign(
      { sub: 'user-2', restaurant_id: RESTAURANT_2_ID },
      testJwtSecret
    );
  });

  it('should prevent cross-restaurant access', async () => {
    const response = await request(app)
      .get('/api/v1/orders')
      .set('Authorization', `Bearer ${restaurant1Token}`)
      .set('X-Restaurant-ID', RESTAURANT_2_ID) // Different restaurant!
      .expect(403);
  });
});
```

---

## Security Patterns to Follow

### Middleware Ordering

**ALWAYS** use this exact order:

```typescript
app.use('/api/v1/orders',
  authenticate,                   // 1. Verify JWT
  validateRestaurantAccess,       // 2. Validate restaurant access
  requireScope(['orders:read']),  // 3. Check RBAC
  orderRoutes                     // 4. Business logic
);

app.use(errorHandler); // MUST be last
```

**NEVER** change middleware order or skip middleware.

---

### Multi-Tenancy Enforcement

**ALWAYS** include `restaurant_id` in database queries:

```typescript
// ✅ CORRECT: Every query includes restaurant_id
const order = await supabase
  .from('orders')
  .select('*')
  .eq('id', orderId)
  .eq('restaurant_id', restaurantId) // REQUIRED
  .single();

const orders = await supabase
  .from('orders')
  .select('*')
  .eq('restaurant_id', restaurantId) // REQUIRED
  .order('created_at', { ascending: false });
```

**NEVER** query without `restaurant_id` filter.

---

### Environment Guards

**ALWAYS** check multiple environment flags:

```typescript
// ✅ CORRECT: Check NODE_ENV AND platform
const isLocalDev = process.env['NODE_ENV'] === 'development'
  && process.env['RENDER'] !== 'true'
  && process.env['VERCEL'] !== '1';

if (isLocalDev && token === 'test-token') {
  // Allow test token ONLY in local dev
}
```

**NEVER** check only `NODE_ENV`.

---

### Error Messages

**DO NOT** leak sensitive information in errors:

```typescript
// ❌ NEVER expose sensitive details
throw new Error(`User ${email} not found in restaurant ${restaurantId}`);
throw new Error(`Order ${orderId} belongs to restaurant ${otherRestaurantId}`);

// ✅ ALWAYS use generic messages
throw NotFound('Order not found');
throw Forbidden('Access denied');
throw Unauthorized('Invalid token');
```

**Return 404** for cross-tenant access (not 403) to hide resource existence.

---

## Code Generation Guidelines

### When Generating Auth Code

1. **Extract user from JWT** (trusted source)
2. **Validate restaurant access** (database lookup)
3. **Check RBAC scopes** (if needed)
4. **Set request properties** (after validation)
5. **Handle errors** (generic messages)

### When Generating API Routes

1. **Apply middleware chain** (authenticate → validate → authorize)
2. **Validate input** (schema validation)
3. **Include restaurant_id** (in all queries)
4. **Audit logging** (before state changes)
5. **Rate limiting** (appropriate tier)

### When Generating Service Methods

1. **Require restaurant_id parameter** (explicit)
2. **Filter by restaurant_id** (in queries)
3. **Return null/undefined** (for not found)
4. **Throw errors** (for system failures)
5. **Log context** (for debugging)

### When Generating Tests

1. **Create valid JWT tokens** (proper signing)
2. **Test cross-tenant access** (should fail)
3. **Test missing auth** (should 401)
4. **Test missing scope** (should 403)
5. **Test rate limits** (should 429)

---

## Common Security Mistakes to Avoid

### ❌ Setting restaurantId from header without validation

```typescript
// WRONG
req.restaurantId = req.headers['x-restaurant-id'];
```

### ❌ Only checking NODE_ENV for dev features

```typescript
// WRONG
if (process.env['NODE_ENV'] === 'development') {
  // Bypasses work on production platforms!
}
```

### ❌ Logging after external API calls

```typescript
// WRONG
await squareApi.charge(amount);
await logAudit({ status: 'success' }); // Too late!
```

### ❌ Missing restaurant_id in queries

```typescript
// WRONG
const order = await supabase
  .from('orders')
  .select('*')
  .eq('id', orderId) // Missing restaurant_id!
  .single();
```

### ❌ Returning 403 for cross-tenant resources

```typescript
// WRONG
if (order.restaurant_id !== req.restaurantId) {
  throw Forbidden('Not your order'); // Leaks existence
}

// CORRECT
if (order.restaurant_id !== req.restaurantId) {
  throw NotFound('Order not found'); // Hides existence
}
```

---

## When to Ask for Human Review

**ALWAYS** flag for human review when:

1. **Security-Critical Changes**:
   - Authentication/authorization logic
   - Payment processing
   - Multi-tenancy validation
   - Audit logging
   - Rate limiting

2. **Potential Vulnerabilities**:
   - Exposing internal IDs
   - Cross-tenant data access
   - Bypassing validation
   - Removing security checks
   - Environment-dependent behavior

3. **Compliance Requirements**:
   - PCI DSS (payment audit logging)
   - GDPR (data isolation)
   - SOC 2 (access controls)

4. **Secret Management**:
   - Adding new secrets
   - Changing secret validation
   - Rotating credentials
   - Modifying startup validation

**Say**: "This code involves [security concern]. Please review for security implications before deploying."

---

## Security Checklist for AI Agents

Before generating code, verify:

```
[ ] No hardcoded secrets or credentials
[ ] Headers validated before trusting
[ ] Audit logging before state changes
[ ] Middleware in correct order
[ ] Multi-tenancy enforced (3 layers)
[ ] Environment guards check platform flags
[ ] Error messages generic (no data leaks)
[ ] Rate limiting appropriate for operation
[ ] Tests include security scenarios
[ ] Cross-tenant access prevented
[ ] RBAC scopes checked
[ ] JWT validation with no fallbacks
```

---

## Example: Secure Code Generation

**User Request**: "Add endpoint to get order by ID"

**AI Agent Response**:

```typescript
// GET /api/v1/orders/:orderId
router.get('/:orderId',
  authenticate,                    // 1. Verify JWT
  validateRestaurantAccess,        // 2. Validate restaurant access
  requireScope(['orders:read']),   // 3. Check RBAC
  async (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    try {
      const { orderId } = req.params;
      const restaurantId = req.restaurantId!;

      // Get order with multi-tenancy enforcement
      const order = await OrdersService.getOrder(orderId, restaurantId);

      if (!order) {
        // Return 404 (not 403) to hide existence from other tenants
        throw NotFound('Order not found');
      }

      res.json(order);
    } catch (error) {
      next(error);
    }
  }
);

// Service method with explicit restaurant_id filtering
export class OrdersService {
  static async getOrder(
    orderId: string,
    restaurantId: string // REQUIRED parameter
  ): Promise<Order | null> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId) // REQUIRED filter
      .single();

    if (error) {
      logger.warn('Order not found', { orderId, restaurantId });
      return null;
    }

    return data;
  }
}

// Test with cross-tenant scenario
describe('GET /api/v1/orders/:orderId', () => {
  it('should prevent cross-restaurant access', async () => {
    const restaurant1Token = createToken({ restaurant_id: R1_ID });
    const restaurant2Order = await createOrder(R2_ID);

    await request(app)
      .get(`/api/v1/orders/${restaurant2Order.id}`)
      .set('Authorization', `Bearer ${restaurant1Token}`)
      .set('X-Restaurant-ID', R1_ID)
      .expect(404); // Not 403
  });
});
```

**Security Review Notes**:
- ✅ Middleware chain correct (auth → validate → authorize)
- ✅ Multi-tenancy enforced in service method
- ✅ Returns 404 for cross-tenant (hides existence)
- ✅ Test includes cross-tenant scenario
- ✅ No secrets in code
- ✅ Generic error messages

---

## Learning Resources

For detailed explanations:
- [PATTERNS.md](./PATTERNS.md) - Security pattern details
- [INCIDENTS.md](./INCIDENTS.md) - Real vulnerability examples
- [PREVENTION.md](./PREVENTION.md) - Prevention measures
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Quick checklists

For architecture decisions:
- [ADR-009](../../docs/explanation/architecture-decisions/ADR-009-error-handling-philosophy.md) - Error handling philosophy
- [ADR-001](../../docs/explanation/architecture-decisions/ADR-001-snake-case-convention.md) - Snake case convention
- [ADR-006](../../docs/explanation/architecture-decisions/ADR-006-dual-authentication-pattern.md) - Dual auth pattern

---

## Version History

- **v1.0** (2025-11-19): Initial guide based on 5 critical vulnerabilities fixed
- Security incidents analyzed: Multi-tenancy, credential exposure, test-token bypass, payment audit race, CSRF misconfiguration
- Prevented losses: $100K-1M+

---

**Remember**: Security is not optional. When in doubt, ask for human review.

**Last Updated**: 2025-11-19
**For**: AI coding assistants working on Restaurant OS codebase

---
category: "security-compliance"
category_id: "09"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "PATTERNS"
tags: [multi-tenancy, rbac, audit-logging, credentials, rls]
---
# Security Patterns & Best Practices

This document outlines the security patterns learned from fixing critical vulnerabilities in the Restaurant OS rebuild project.

## Table of Contents

1. [Middleware Ordering Patterns](#middleware-ordering-patterns)
2. [Development Bypass Prevention](#development-bypass-prevention)
3. [JWT Secret Management](#jwt-secret-management)
4. [Multi-Tenancy Validation](#multi-tenancy-validation)
5. [Exposed Secrets Detection](#exposed-secrets-detection)
6. [Rate Limiting Patterns](#rate-limiting-patterns)
7. [Audit Logging Patterns](#audit-logging-patterns)

---

## Middleware Ordering Patterns

### The Problem
Incorrect middleware ordering allowed cross-restaurant data access. The auth middleware was setting `req.restaurantId` from untrusted headers BEFORE validation.

### The Pattern: Authentication → Validation → Authorization

```typescript
// ❌ WRONG: Setting restaurantId before validation
export async function authenticate(req: AuthenticatedRequest, ...): Promise<void> {
  // Verify JWT
  const decoded = jwt.verify(token, jwtSecret);
  req.user = { id: decoded.sub, ... };

  // DANGEROUS: Setting restaurantId from header without validation
  req.restaurantId = req.headers['x-restaurant-id'] as string;
  next();
}

// ✅ CORRECT: Only set after validation
export async function authenticate(req: AuthenticatedRequest, ...): Promise<void> {
  // Verify JWT
  const decoded = jwt.verify(token, jwtSecret);
  req.user = {
    id: decoded.sub,
    restaurant_id: decoded.restaurant_id // From trusted JWT
  };

  // DON'T set req.restaurantId here - let restaurantAccess middleware do it
  next();
}

export async function validateRestaurantAccess(req: AuthenticatedRequest, ...): Promise<void> {
  // Get requested restaurant from header
  const requestedRestaurantId = req.headers['x-restaurant-id'] as string;

  // Validate user has access to this restaurant (DB lookup)
  const { data: userRestaurant } = await supabase
    .from('user_restaurants')
    .select('restaurant_id, role')
    .eq('user_id', req.user.id)
    .eq('restaurant_id', requestedRestaurantId)
    .single();

  if (!userRestaurant) {
    throw Forbidden('Access denied to this restaurant');
  }

  // ONLY set after validation succeeds
  req.restaurantId = requestedRestaurantId;
  req.restaurantRole = userRestaurant.role;
  next();
}
```

### Application in Express Routes

```typescript
// ✅ CORRECT middleware order
app.use(authenticate);                    // 1. Verify JWT, extract user
app.use(validateRestaurantAccess);        // 2. Validate restaurant access
app.use('/api/v1/orders', orderRoutes);   // 3. Business logic
app.use(errorHandler);                    // 4. Error handling
```

### Key Principles

1. **Extract → Validate → Assign**: Extract from JWT, validate access, then assign to request
2. **Trust JWT, Not Headers**: JWT payload is cryptographically verified
3. **Validate Before Use**: Never use header values without validation
4. **Set Once**: `req.restaurantId` set only after all validation passes

---

## Development Bypass Prevention

### The Problem
Test authentication tokens worked in production environments, allowing unauthorized admin access.

### The Pattern: Environment Guards with Multiple Checks

```typescript
// ❌ WRONG: Only checking NODE_ENV
const isDevelopment = process.env['NODE_ENV'] === 'development';

if (isDevelopment && token === 'test-token') {
  // Allow test token
  // BUG: Works on Render if NODE_ENV=development
}

// ✅ CORRECT: Check NODE_ENV AND deployment platform
const isDevelopment = process.env['NODE_ENV'] === 'development'
  && process.env['RENDER'] !== 'true'
  && process.env['VERCEL'] !== '1';

if (isDevelopment && token === 'test-token') {
  // Allow test token only in true local development
}
```

### Rate Limiting Guards

```typescript
// ✅ Apply rate limits in ALL environments except local dev
export const aiServiceLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: isDevelopment ? 100 : 50, // Higher in dev, strict in prod
  skip: (_req: Request) => isDevelopment, // Skip ONLY in local dev
  handler: (req, res) => {
    // Log potential abuse for monitoring
    console.error(`[RATE_LIMIT] AI service limit exceeded for ${req.ip}`);
    res.status(429).json({ error: 'Too many AI requests' });
  }
});
```

### Key Principles

1. **Multiple Flags**: Check both `NODE_ENV` AND platform environment variables
2. **Explicit Platform Checks**: Verify not on Render, Vercel, or other production platforms
3. **Log Bypasses**: Log when development bypasses are used
4. **Fail Closed**: Default to secure behavior if environment unclear

---

## JWT Secret Management

### The Problem
Missing JWT secrets allowed the server to start without authentication configured, and dangerous fallbacks existed in config code.

### The Pattern: Startup Validation with No Fallbacks

```typescript
// ❌ WRONG: Dangerous fallback
export function getConfig(): EnvironmentConfig {
  return {
    supabase: {
      jwtSecret: env.SUPABASE_JWT_SECRET || '', // DANGEROUS: Empty string fallback
    }
  };
}

// ✅ CORRECT: Fail-fast validation at startup
export function validateEnvironment(): void {
  // JWT_SECRET is critical for authentication
  if (!env.SUPABASE_JWT_SECRET) {
    throw new Error(
      'SUPABASE_JWT_SECRET is required for authentication.\n' +
      'Find it in Supabase Dashboard: Settings > API > JWT Secret\n' +
      'It should be a base64-encoded string (~88 characters).'
    );
  }

  // Validate JWT_SECRET format
  const jwtSecret = env.SUPABASE_JWT_SECRET.trim();
  if (jwtSecret.length < 32) {
    throw new Error(
      'SUPABASE_JWT_SECRET appears invalid: too short (expected ~88 characters)'
    );
  }

  // Check for base64 format (warning, not error)
  const base64Regex = /^[A-Za-z0-9+/]+=*$/;
  if (!base64Regex.test(jwtSecret)) {
    logger.warn('SUPABASE_JWT_SECRET format warning: expected base64-encoded string');
  }

  logger.info('✅ JWT authentication configured');
}

// Call at server startup BEFORE listening
validateEnvironment();
```

### JWT Verification with No Fallbacks

```typescript
// ✅ CORRECT: No fallback secrets
export async function authenticate(req: AuthenticatedRequest, ...): Promise<void> {
  const config = getConfig();
  const jwtSecret = config.supabase.jwtSecret;

  if (!jwtSecret) {
    logger.error('⛔ JWT_SECRET not configured - authentication cannot proceed');
    throw new Error('Server authentication not configured');
  }

  try {
    const decoded = jwt.verify(token, jwtSecret); // Single secret, no fallbacks
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      throw Unauthorized('Token expired');
    } else if (error instanceof jwt.JsonWebTokenError) {
      throw Unauthorized('Invalid token');
    }
    throw Unauthorized('Token verification failed');
  }
}
```

### Key Principles

1. **Fail at Startup**: Validate secrets before server accepts connections
2. **No Fallbacks**: Never fall back to empty strings or default secrets
3. **Format Validation**: Check length and format of secrets
4. **Clear Error Messages**: Explain where to find the secret
5. **Single Source**: One configured secret, no fallback keys

---

## Multi-Tenancy Validation

### The Problem
Application layer set restaurant ID from headers without validation, allowing cross-tenant access.

### The Pattern: Defense in Depth (3 Layers)

#### Layer 1: Middleware Validation

```typescript
// Validate user has access to requested restaurant
export async function validateRestaurantAccess(req: AuthenticatedRequest, ...): Promise<void> {
  const requestedRestaurantId = req.headers['x-restaurant-id'] as string;

  if (!req.user) {
    throw Unauthorized('Authentication required');
  }

  // Database lookup to verify access
  const { data: userRestaurant, error } = await supabase
    .from('user_restaurants')
    .select('restaurant_id, role')
    .eq('user_id', req.user.id)
    .eq('restaurant_id', requestedRestaurantId)
    .single();

  if (error || !userRestaurant) {
    throw Forbidden('Access denied to this restaurant');
  }

  // ONLY set after validation passes
  req.restaurantId = requestedRestaurantId;
  req.restaurantRole = userRestaurant.role;
  next();
}
```

#### Layer 2: Service-Level Filtering

```typescript
// ALWAYS include restaurant_id in queries
export class OrdersService {
  static async getOrders(restaurantId: string): Promise<Order[]> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('restaurant_id', restaurantId) // REQUIRED for multi-tenancy
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data;
  }

  static async getOrder(orderId: string, restaurantId: string): Promise<Order | null> {
    const { data, error } = await supabase
      .from('orders')
      .select('*')
      .eq('id', orderId)
      .eq('restaurant_id', restaurantId) // REQUIRED - prevents cross-tenant access
      .single();

    if (error) return null;
    return data;
  }
}
```

#### Layer 3: Database RLS Policies

```sql
-- Row Level Security policies
CREATE POLICY "tenant_select_orders" ON orders
  FOR SELECT
  USING (restaurant_id = (auth.jwt() ->> 'restaurant_id')::uuid);

CREATE POLICY "tenant_update_orders" ON orders
  FOR UPDATE
  USING (restaurant_id = (auth.jwt() ->> 'restaurant_id')::uuid)
  WITH CHECK (restaurant_id = (auth.jwt() ->> 'restaurant_id')::uuid);

CREATE POLICY "tenant_delete_orders" ON orders
  FOR DELETE
  USING (restaurant_id = (auth.jwt() ->> 'restaurant_id')::uuid);
```

### Testing Multi-Tenancy

```typescript
describe('Multi-Tenancy Enforcement', () => {
  const RESTAURANT_1_ID = '11111111-1111-1111-1111-111111111111';
  const RESTAURANT_2_ID = '22222222-2222-2222-2222-222222222222';

  it('should prevent restaurant 1 user from accessing restaurant 2 orders', async () => {
    const response = await request(app)
      .get('/api/v1/orders')
      .set('Authorization', `Bearer ${restaurant1Token}`)
      .set('X-Restaurant-ID', RESTAURANT_2_ID)
      .expect(403);

    expect(response.body.error.code).toBe('RESTAURANT_ACCESS_DENIED');
  });

  it('should prevent cross-tenant order updates', async () => {
    const response = await request(app)
      .patch(`/api/v1/orders/${restaurant2OrderId}/status`)
      .set('Authorization', `Bearer ${restaurant1Token}`)
      .set('X-Restaurant-ID', RESTAURANT_1_ID)
      .send({ status: 'preparing' })
      .expect(404);
  });
});
```

### Key Principles

1. **Three Layers**: Middleware, service, and database all validate
2. **Explicit Filtering**: Always include `.eq('restaurant_id', restaurantId)`
3. **Never Trust Headers**: Validate access via database lookup
4. **Test Cross-Tenant**: Verify users cannot access other restaurants
5. **Return 404, Not 403**: Don't leak existence of cross-tenant resources

---

## Exposed Secrets Detection

### The Problem
Vercel OIDC token committed to git history for 60+ days.

### The Pattern: Pre-Commit Hooks + Startup Validation

#### Pre-Commit Hook

```bash
#!/usr/bin/env bash
# .husky/pre-commit

# Prevent committing .env files
if git diff --cached --name-only | grep -E "^\.env(\.|$)"; then
  echo "🚨 ERROR: Attempting to commit .env file(s)"
  echo "Blocked files:"
  git diff --cached --name-only | grep -E "^\.env(\.|$)"
  exit 1
fi

# Check for hardcoded secrets (basic pattern matching)
if git diff --cached -U0 | grep -iE "(api[_-]?key|secret[_-]?key|password|token)" | grep -vE "^[+-]\s*//"; then
  echo "⚠️  WARNING: Potential secrets detected in staged changes"
  echo "Review carefully before committing"
  # Don't block, just warn
fi
```

#### Startup Secret Validation

```typescript
// Validate critical secrets at startup
export function validateEnvironment(): void {
  const requiredSecrets = [
    'SUPABASE_JWT_SECRET',
    'KIOSK_JWT_SECRET',
    'PIN_PEPPER',
    'DEVICE_FINGERPRINT_SALT',
    'SQUARE_ACCESS_TOKEN'
  ];

  const missing = requiredSecrets.filter(key => !process.env[key]);

  if (missing.length > 0) {
    throw new Error(
      `Missing required secrets: ${missing.join(', ')}\n` +
      'Server cannot start without these secrets configured.'
    );
  }

  // Validate secret formats
  if (env.SUPABASE_JWT_SECRET.length < 32) {
    throw new Error('SUPABASE_JWT_SECRET too short - check configuration');
  }

  if (env.SQUARE_ACCESS_TOKEN === 'demo' && env.NODE_ENV === 'production') {
    throw new Error('Cannot use demo Square token in production');
  }
}
```

#### .gitignore Enforcement

```gitignore
# Environment files
.env
.env.*
!.env.example

# Never commit these patterns
*.key
*.pem
*credentials*.json
```

### Secret Rotation Procedure

1. **Detect**: Discover secret in git history
2. **Revoke**: Immediately revoke the exposed secret
3. **Rotate**: Generate new secret and update environments
4. **Audit**: Check access logs for suspicious activity
5. **Document**: Record incident in security log

### Key Principles

1. **Pre-Commit Checks**: Block secrets before they enter git
2. **Startup Validation**: Fail fast if secrets missing/invalid
3. **Format Checks**: Validate secret length and format
4. **Never Rewrite History**: If secret exposed and expired, document instead
5. **Assume Compromise**: Treat any committed secret as compromised

---

## Rate Limiting Patterns

### The Problem
Rate limiting was disabled in production, allowing unlimited expensive AI API calls.

### The Pattern: Tiered Rate Limits by Cost

```typescript
// Health checks (cheap)
export const healthCheckLimiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: 30, // 30 per minute
  keyGenerator: (req) => req.ip || 'anonymous'
});

// General API (moderate)
export const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: isDevelopment ? 10000 : 1000, // 1000 per 15 minutes
  keyGenerator: (req) => {
    const authReq = req as AuthenticatedRequest;
    return authReq.restaurantId || authReq.ip || 'anonymous';
  },
  skip: (_req) => isDevelopment
});

// AI services (expensive)
export const aiServiceLimiter = rateLimit({
  windowMs: 5 * 60 * 1000,
  max: isDevelopment ? 100 : 50, // 50 per 5 minutes
  keyGenerator: (req) => {
    const authReq = req as AuthenticatedRequest;
    return authReq.user?.id || authReq.restaurantId || authReq.ip || 'anonymous';
  },
  handler: (req, res) => {
    // Log abuse for monitoring
    console.error(`[RATE_LIMIT] AI service limit exceeded for ${req.ip}`);
    res.status(429).json({
      error: 'Too many AI requests. Please wait 5 minutes.',
      retryAfter: 300
    });
  }
});

// Transcription (very expensive)
export const transcriptionLimiter = rateLimit({
  windowMs: 1 * 60 * 1000,
  max: isDevelopment ? 30 : 20, // 20 per minute
  keyGenerator: (req) => {
    const authReq = req as AuthenticatedRequest;
    return authReq.user?.id || authReq.restaurantId || authReq.ip || 'anonymous';
  },
  handler: (req, res) => {
    console.error(`[RATE_LIMIT] Transcription limit exceeded for ${req.ip}`);
    res.status(429).json({
      error: 'Too many transcription requests. Please wait 1 minute.',
      retryAfter: 60
    });
  }
});
```

### Key Principles

1. **Cost-Based Limits**: More expensive operations have stricter limits
2. **User-Based Keys**: Key by user ID or restaurant ID when possible
3. **Development Bypass**: Skip or increase limits in local dev only
4. **Log Abuse**: Always log rate limit violations for monitoring
5. **Clear Messages**: Tell users when they can retry

---

## Audit Logging Patterns

### The Problem
Audit logging happened AFTER payment processing, allowing charged-but-unrecorded scenarios.

### The Pattern: Two-Phase Audit Logging

```typescript
// Phase 1: Log BEFORE external API call
await PaymentService.logPaymentAttempt({
  orderId: order_id,
  status: 'initiated',  // Log intent before charging
  restaurantId: restaurantId,
  amount: validation.orderTotal,
  idempotencyKey: serverIdempotencyKey,
  paymentMethod: 'card',
  userAgent: req.headers['user-agent'],
  metadata: { /* context */ },
  ...(req.user?.id && { userId: req.user.id }),
  ...(req.ip && { ipAddress: req.ip })
});

// Phase 2: Call external API (Square)
paymentResult = await paymentsApi.create(paymentRequest);

// Phase 3: Update audit log with final status
await PaymentService.updatePaymentAuditStatus(
  serverIdempotencyKey,  // Find by idempotency key
  paymentResult.payment?.status === 'COMPLETED' ? 'success' : 'failed',
  paymentResult.payment.id
);
```

### Fail-Fast for Compliance

```typescript
static async logPaymentAttempt(data: PaymentAuditLog): Promise<void> {
  try {
    const { error } = await supabase
      .from('payment_audit_logs')
      .insert(auditLog);

    if (error) {
      logger.error('CRITICAL: Payment audit log failed', { error });
      // FAIL-FAST: Per ADR-009, audit log failures MUST block payment
      throw new Error('Payment processing unavailable - audit system failure');
    }
  } catch (dbError) {
    logger.error('CRITICAL: Database error storing payment audit', { dbError });
    // FAIL-FAST: Same as above
    throw new Error('Payment processing unavailable - audit system failure');
  }
}
```

### Key Principles

1. **Log Before Action**: Record intent before external calls
2. **Update After Action**: Record result after external calls
3. **Fail-Fast**: Audit failures MUST block operations
4. **Idempotency**: Use keys to prevent duplicate logs
5. **Complete Context**: Log user, IP, metadata, timestamps

---

## Summary: Security Pattern Checklist

When implementing any security-sensitive feature:

- [ ] Middleware ordered correctly (auth → validation → business logic)
- [ ] Development bypasses check multiple environment flags
- [ ] JWT secrets validated at startup with no fallbacks
- [ ] Multi-tenancy enforced at 3 layers (middleware, service, DB)
- [ ] No credentials committed (pre-commit hooks active)
- [ ] Rate limiting appropriate for operation cost
- [ ] Audit logging happens BEFORE state-changing operations
- [ ] All patterns tested with cross-tenant attack scenarios
- [ ] Error messages don't leak sensitive information
- [ ] Logging captures security events for monitoring

---

**Last Updated**: 2025-11-19
**Related**: INCIDENTS.md, PREVENTION.md, QUICK-REFERENCE.md

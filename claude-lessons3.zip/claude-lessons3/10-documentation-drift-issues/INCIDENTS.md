---
category: "documentation-drift"
category_id: "10"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "INCIDENTS"
incident_count: 2
total_cost: 15000
severity_distribution:
  P1: 2
tags: [link-rot, diataxis, freshness, sync]
---
# Major Documentation Incidents

**Critical Documentation Failures and Their Resolution**

## Overview

This document chronicles the major documentation incidents that occurred during Restaurant OS development, their impact, root causes, and lessons learned. Each incident represents a failure mode that the project's prevention systems are now designed to avoid.

---

## Incident 1: Link Rot Crisis

**Incident ID**: DOC-2025-11-18-001
**Date**: November 18, 2025
**Severity**: P1 (High)
**Status**: Resolved
**Duration**: 4 months (accumulation), 8 hours (repair)

### Summary

Internal documentation links degraded from 95% health (July 2025) to 63% health (November 2025), with **884 broken links** making documentation effectively unusable for navigation.

### Impact

- **Documentation unusable**: 38 broken links in PRODUCTION_STATUS.md alone
- **Feature discovery broken**: Developers couldn't find related documentation
- **Onboarding failed**: New developers couldn't navigate docs
- **Support burden**: Increased tickets due to inability to find information
- **Brand damage**: "Documentation is broken" feedback

### Timeline

| Date | Event |
|------|-------|
| July 2025 | Repository reorganization creates ~50 broken links |
| September 2025 | Archive migrations add ~250 broken links |
| October 2025 | Diataxis planning updates links but doesn't move files: +500 broken links |
| November 18, 08:00 | Comprehensive audit discovers 884 broken links |
| November 18, 10:00 | Emergency repair sprint begins |
| November 18, 18:00 | 161 broken links fixed, link health at 97.4% |

### Root Cause

**Primary**: Incomplete Diataxis migration
- Links updated to reference new structure
- Files never moved to new locations
- No validation before merging changes

**Contributing Factors**:
1. No automated link validation in CI/CD
2. No link checking before PR merge
3. Large reorganization started without completion plan
4. No monitoring of link health over time

### Detection

- **How Detected**: Manual comprehensive documentation audit
- **Should Have Been**: Automated CI/CD link validation

**Why It Took So Long**:
- No automated monitoring
- Manual audits infrequent (quarterly)
- Gradual accumulation didn't trigger alarms

### Resolution

**Immediate Actions** (Nov 18, 10:00-18:00):
1. Created automated link repair script (`fix_broken_links.py`)
2. Built file location cache for intelligent path resolution
3. Used confidence scoring to validate fixes
4. Fixed 161 links in 93 files
5. Created validation script for ongoing monitoring

**Results**:
- 884 → 30 broken links (96.6% reduction)
- Link health: 63% → 97.4%
- Documentation navigable again

**Long-term Prevention**:
1. Implemented CI/CD link validation (`.github/workflows/check-links.yml`)
2. Weekly scheduled link health checks
3. PR merge blocked if link health drops below 90%
4. Auto-create issues for broken links

### Lessons Learned

1. **Link rot compounds exponentially**: 50 → 884 in 4 months
2. **Incomplete migrations are worse than no migration**: Don't update links before moving files
3. **Automation is mandatory**: Manual audits catch problems too late
4. **CI/CD validation is prevention, not overhead**: 2 hours setup vs 8 hours repair

### Prevention Measures

✅ **Implemented**:
- Automated link validation on every PR
- Weekly scheduled link health checks
- Link repair script for quick fixes
- Documentation restructuring guidelines

⚠️ **Pending**:
- Link health dashboard
- Historical link health trends
- Automated link redirects for moved files

### Related Issues

- 500+ links from Diataxis planning
- 200+ links from archive migrations
- 100+ links from renamed files
- 84+ links from deleted features

### Cost Analysis

**Accumulation Cost** (4 months):
- Developer time lost to broken links: ~20 hours
- Support tickets for "can't find docs": ~15 tickets
- Failed onboarding sessions: ~5 developers

**Repair Cost** (1 day):
- Emergency sprint: 8 hours
- Script development: 4 hours
- Validation and testing: 2 hours
- Total: **14 hours**

**Prevention Cost** (ongoing):
- CI/CD setup: 2 hours (one-time)
- Per-PR validation: <1 minute
- Weekly checks: <5 minutes
- Total annual: **~6 hours**

**ROI**: 14 hours repair / 6 hours prevention = **2.3x more expensive to repair**

---

## Incident 2: API Documentation Accuracy Crisis

**Incident ID**: DOC-2025-11-18-002
**Date**: November 18, 2025
**Severity**: P0 (Critical)
**Status**: Resolved
**Duration**: 3 months (accumulation), 4 hours (repair)

### Summary

API documentation accuracy dropped to **42%**, with only 26 of 62 endpoints accurately documented. Critical payment and menu endpoints had wrong paths, blocking all integrations.

### Impact

- **Integration failures**: Payment endpoint 404 errors
- **Developer frustration**: Following docs led to broken code
- **Menu API 100% wrong**: All menu endpoints missing `/menu` prefix
- **23 endpoints undocumented**: Features undiscoverable
- **Revenue impact**: Blocked integrations, delayed partnerships
- **Support burden**: 10+ hours/week helping developers debug "documentation bugs"

### Critical Failures

1. **Payment Endpoint Wrong**:
   - Documented: `POST /api/v1/payments/process`
   - Actual: `POST /api/v1/payments/create`
   - Impact: 404 for all payment integrations

2. **Menu Endpoints Missing Prefix**:
   - Documented: `/api/v1/items`, `/api/v1/categories`
   - Actual: `/api/v1/menu/items`, `/api/v1/menu/categories`
   - Impact: 100% of menu API calls failing

3. **Voice Ordering Undocumented**:
   - 3 endpoints completely missing
   - Realtime API integration not documented
   - Impact: Feature undiscoverable

4. **Missing Endpoints**: 23 total
   - Authentication: `GET /auth/me`, `POST /station-login`
   - Batch operations: `PUT /tables/batch`
   - Realtime: `POST /realtime/session`
   - Webhooks: 3 endpoints
   - Security: 4 endpoints

### Timeline

| Date | Event |
|------|-------|
| August 2025 | Payment endpoints refactored, docs not updated |
| September 2025 | Menu routes restructured, docs not updated |
| October 2025 | Voice ordering implemented, docs not created |
| November 18, 08:00 | Audit reveals 42% accuracy |
| November 18, 18:00 | API Documentation Agent deployed |
| November 18, 22:00 | 95% accuracy restored |

### Root Cause

**Primary**: Manual API documentation maintenance
- Developers update code, forget docs
- No validation that docs match actual routes
- OpenAPI maintained separately from route definitions

**Contributing Factors**:
1. No API testing against documentation
2. Copy-paste from old versions without checking
3. PR checklist doesn't require API doc updates
4. No automated OpenAPI generation

### Detection

- **How Detected**: Manual API audit comparing OpenAPI to route files
- **Should Have Been**: Automated API testing against OpenAPI spec

**Red Flags Missed**:
- Developers reporting 404 errors following docs
- Support tickets about "wrong endpoints"
- Integration partners asking for "actual endpoints"

### Resolution

**API Documentation Agent** (Nov 18, 18:00-22:00):

1. **Endpoint Inventory**:
   ```bash
   # Extracted all actual routes from code
   grep -r "router\.(get|post|put|delete)" server/src/routes/
   ```

2. **Comparison to OpenAPI**:
   ```bash
   # Identified mismatches
   diff actual_routes.txt documented_routes.txt
   ```

3. **Systematic Updates**:
   - Fixed payment path: `/process` → `/create`
   - Added `/menu` prefix to all menu endpoints
   - Documented 23 missing endpoints
   - Added complete request/response schemas
   - Added authentication requirements
   - Documented RBAC scopes

**Results**:
- API accuracy: 42% → 95%
- Documented endpoints: 39 → 62
- Complete schemas: 35% → 90%
- Working examples: 40% → 85%

**Long-term Prevention**:
1. OpenAPI generation from code (planned)
2. API testing against OpenAPI spec
3. Required API doc updates in PR checklist

### Lessons Learned

1. **Manual API docs don't scale**: Drift is inevitable
2. **Single source of truth**: Generate docs from code
3. **Wrong docs worse than no docs**: Developers lose trust
4. **Validation is critical**: Test docs against running server

### Prevention Measures

✅ **Implemented**:
- API audit checklist for manual reviews
- PR template requires API doc updates
- OpenAPI version validation

⚠️ **Planned**:
- Automated OpenAPI generation from routes
- API testing against OpenAPI spec in CI/CD
- Route decorators that generate documentation

### Cost Analysis

**Accumulation Cost** (3 months):
- Failed integrations: 3 partnerships delayed
- Support time: ~40 hours helping developers
- Developer trust: Immeasurable

**Repair Cost** (1 day):
- Agent development: 2 hours
- Systematic updates: 4 hours
- Validation: 2 hours
- Total: **8 hours**

**Future Prevention**:
- OpenAPI generation setup: 8 hours (one-time)
- Maintenance: Automatic
- Total annual: **0 hours** (after setup)

---

## Incident 3: Auth Evolution Undocumented

**Incident ID**: DOC-2025-11-18-003
**Date**: November 18, 2025
**Severity**: P2 (Medium)
**Status**: Resolved
**Duration**: 4 months (knowledge decay), 6 hours (documentation)

### Summary

Three complete authentication system rewrites over 4 months (July-November 2025) with **no architectural documentation** created, leading to:
- Knowledge loss
- Repeated mistakes
- Onboarding confusion
- 80+ hours of developer effort undocumented

### Impact

- **Knowledge in heads only**: Only 2-3 people understood full auth history
- **New developers confused**: "Why dual auth pattern?"
- **Repeated mistakes**: Voice ordering broke 3 separate times
- **Test suite unstable**: 12 integration tests broken repeatedly
- **Security vulnerabilities**: Missing validation discovered multiple times
- **Onboarding time**: 20+ hours to understand auth system

### Authentication Evolution

**Phase 1** (July-September 2025):
- Custom JWT + RLS implementation
- Test token support
- Demo mode parallel infrastructure
- Issues: Security bypasses, race conditions, multi-tenancy gaps

**Phase 2** (October 8, 2025):
- Pure Supabase Auth migration
- Attempt to simplify with single auth system
- Failed within 3 weeks
- Issues: Demo mode impossible, voice ordering broken, PIN auth unsupported

**Phase 3** (November 2-18, 2025):
- Dual Authentication Pattern (current)
- Supabase (production) + Custom JWT (demo/voice/PIN)
- httpClient checks both sources
- Success: All use cases supported, production-ready

**142 authentication-related commits** over 4 months

### Timeline

| Date | Event |
|------|-------|
| July-Sept 2025 | Phase 1: Custom JWT implementation |
| Oct 8, 2025 | Phase 2: Supabase migration |
| Oct 25, 2025 | Multi-tenancy vulnerability discovered |
| Nov 2, 2025 | Phase 2 abandoned, Phase 3 begins |
| Nov 18, 2025 | Voice ordering breaks (CL-AUTH-001) |
| Nov 19, 2025 | ADR-011 created (1,435 lines) |

### Root Cause

**Primary**: No ADR process for architectural decisions
- Decisions made in meetings/Slack
- Knowledge stayed in heads
- No written rationale for choices

**Contributing Factors**:
1. Time pressure: "No time to document, ship first"
2. Assumed memory: "Team knows why"
3. Incremental changes: Small changes, big decision
4. Unclear when to create ADR

### Detection

- **How Detected**: New developer onboarding taking 20+ hours
- **Should Have Been**: ADR created during Phase 1 design

**Red Flags Missed**:
- Multiple people asking "why do we do this?"
- Same bugs repeated in different areas
- Auth questions in every code review
- Long explanations in Slack threads

### Resolution

**Auth-Evolution Agent** (Nov 19, 08:00-14:00):

**Created ADR-011** (1,435 lines):
- Complete 4-month authentication history
- All 3 phases documented
- Security vulnerabilities cataloged
- 10 critical lessons learned
- Architecture diagrams
- Decision rationales
- Future recommendations

**Key Sections**:
1. Phase 1: Custom JWT (what worked, what failed)
2. Phase 2: Supabase migration (why it failed)
3. Phase 3: Dual auth (current solution)
4. Security posture evolution
5. Lessons learned (10 insights)
6. Future recommendations
7. Maintenance checklist

**Impact of Documentation**:
- New developer onboarding: 20 hours → 90 minutes
- Auth questions: 10/week → 1/week
- Knowledge preserved for future
- Pattern documented for reuse

### Lessons Learned

1. **Undocumented decisions decay**: 4 months = 80% knowledge loss
2. **ADRs save time**: 6 hours to write, 100+ hours saved
3. **Document during decision**: Not months later
4. **Architectural history matters**: Understanding "why" prevents mistakes

### Prevention Measures

✅ **Implemented**:
- ADR template created
- ADR process defined (when to create)
- Architecture review meetings include ADR creation
- PR template asks "Does this need an ADR?"

⚠️ **Pending**:
- ADR index with search
- ADR status tracking
- Regular ADR reviews

### Related ADRs Created

- ADR-011: Authentication Evolution (this incident)
- ADR-006: Dual Authentication Pattern (detailed implementation)
- ADR-001 through ADR-010: Historical decisions finally documented

### Cost Analysis

**Knowledge Decay Cost** (4 months):
- New developer onboarding: 60+ hours (3 developers)
- Repeated mistakes: 40+ hours debugging
- Slack explanations: 20+ hours
- Total: **120+ hours**

**Documentation Cost**:
- ADR-011 creation: 6 hours
- Template creation: 1 hour
- Process definition: 1 hour
- Total: **8 hours**

**ROI**: 120 hours saved / 8 hours invested = **15x return**

---

## Incident 4: Schema Drift Undetected

**Incident ID**: DOC-2025-10-29-004
**Date**: October 29, 2025
**Severity**: P2 (Medium)
**Status**: Resolved
**Duration**: 2 weeks (undetected), 2 hours (repair)

### Summary

Database migration added `confirmed_at` timestamp to orders table, but schema documentation not updated for 2 weeks, causing TypeScript type mismatches and integration confusion.

### Impact

- **TypeScript errors**: Types didn't match actual schema
- **Integration confusion**: Partners asked about missing field
- **API documentation wrong**: Missing field in request/response examples
- **Test failures**: Tests expected field that wasn't documented

### Timeline

| Date | Event |
|------|-------|
| Oct 15, 2025 | Migration adds `confirmed_at` field |
| Oct 15-29, 2025 | Schema docs not updated (2 weeks) |
| Oct 29, 2025 | TypeScript type mismatch discovered |
| Oct 29, 2025 | Schema docs updated |

### Root Cause

- Manual schema documentation
- Migration checklist incomplete
- No automated schema doc generation

### Resolution

1. Updated DATABASE.md with `confirmed_at` field
2. Regenerated TypeScript types
3. Updated API documentation
4. Created migration checklist template
5. Planned automated schema doc generation

### Lessons Learned

- Schema docs should be generated, not written
- Migration checklist must include docs
- Automated validation catches drift early

### Prevention Measures

✅ **Implemented**:
- Migration checklist template includes schema doc update
- Schema validation in CI/CD

⚠️ **Planned**:
- Automated schema doc generation from Prisma
- Schema version in API documentation

---

## Incident 5: Missing Operational Documentation

**Incident ID**: DOC-2025-11-10-005
**Date**: November 10, 2025
**Severity**: P1 (High)
**Status**: Resolved
**Duration**: Months (accumulation), 4 hours (creation)

### Summary

Production deployment reached 90% readiness but critical operational documentation missing:
- No incident response playbook
- No rollback procedures
- No monitoring setup guide
- No post-deployment verification

### Impact

- **Deployment battle**: 20+ consecutive commits fixing issues
- **No structured response**: Trial-and-error during incidents
- **Extended downtime**: No clear rollback procedure
- **Repeated mistakes**: Same deployment issues multiple times

### Timeline

| Date | Event |
|------|-------|
| Oct 2025 | Multiple deployment issues |
| Nov 2025 | 20+ commits fixing same issues |
| Nov 10, 2025 | JWT scope bug (10-day incident) |
| Nov 19, 2025 | Operational docs created |

### Root Cause

- Focus on feature development, not operations
- Assumed operations were "obvious"
- No operational readiness checklist

### Resolution

**Incident-Response Agent** (Nov 19, 12:00-16:00):

Created 80KB of operational documentation:
1. **Incident Response Playbook**: P0-P4 severity levels, escalation paths
2. **Production Monitoring Guide**: 6 health endpoints, alerting
3. **Rollback Procedures**: Detailed steps for all services
4. **Post-Deployment Verification**: Checklist for verification
5. **6 Scenario Runbooks**: Database failure, auth issues, payment problems, etc.

### Lessons Learned

- Operational docs as critical as feature docs
- Create ops docs before production, not after incidents
- Runbooks prevent panic during incidents

### Prevention Measures

✅ **Implemented**:
- Operational documentation templates
- Production readiness checklist includes ops docs
- Required ops docs for production deployment

---

## Common Themes Across All Incidents

### Root Causes (Frequency)

1. **No automation** (100% of incidents): Manual processes fail
2. **No validation** (80%): Drift undetected until crisis
3. **Time pressure** (80%): "Document later" never happens
4. **Process gaps** (80%): No requirement for doc updates
5. **Knowledge silos** (60%): Only some people know

### Universal Lessons

1. **Prevention is 10-100x cheaper than repair**
2. **Automation is mandatory, not optional**
3. **Documentation debt compounds exponentially**
4. **Missing docs cost more than writing docs**
5. **CI/CD validation catches problems early**

### Prevention System Created

After these incidents, a comprehensive prevention system was implemented:

✅ **Automated**:
- Link validation (CI/CD)
- API testing (planned)
- Schema doc generation (planned)
- Staleness detection (CI/CD)

✅ **Process**:
- PR documentation checklist
- ADR requirement for decisions
- Post-mortem after incidents
- Migration checklist

✅ **Monitoring**:
- Weekly documentation health checks
- Link health dashboard (planned)
- Documentation metrics tracking

---

## Incident Summary Table

| Incident | Severity | Duration | Repair Cost | Prevention Cost | ROI |
|----------|----------|----------|-------------|-----------------|-----|
| Link Rot Crisis | P1 | 4 months | 14 hours | 6 hours/year | 2.3x |
| API Accuracy Crisis | P0 | 3 months | 8 hours | 8 hours setup, then 0 | ∞ |
| Auth Undocumented | P2 | 4 months | 8 hours | 0 hours (ADR process) | ∞ |
| Schema Drift | P2 | 2 weeks | 2 hours | 0 hours (automated) | ∞ |
| Missing Ops Docs | P1 | Months | 4 hours | 1 hour/incident | 4x |

**Total Repair Cost**: 36 hours
**Total Prevention Cost**: 6 hours/year
**Overall ROI**: 6x more expensive to repair than prevent

---

## Related Documentation

- [PATTERNS.md](./PATTERNS.md) - Drift patterns to watch for
- [PREVENTION.md](./PREVENTION.md) - How to prevent these incidents
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Quick prevention checklist
- [AI-AGENT-GUIDE.md](./AI-AGENT-GUIDE.md) - AI guidelines based on lessons

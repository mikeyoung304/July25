---
category: "documentation-drift"
category_id: "10"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, link-rot, diataxis, freshness, sync]
---
# Documentation Quick Reference

**Fast Lookup for Common Documentation Tasks**

## When to Update Documentation

| Code Change | Documentation Required | Where | Who |
|-------------|----------------------|-------|-----|
| Add/change API endpoint | ✅ OpenAPI spec | `docs/reference/api/openapi.yaml` | Developer |
| New feature | ✅ README + feature docs | `README.md`, `docs/` | Developer |
| Breaking change | ✅ CHANGELOG + migration guide | `CHANGELOG.md`, `docs/how-to/` | Developer |
| New env variable | ✅ .env.example + ENVIRONMENT.md | `.env.example`, `docs/reference/ENVIRONMENT.md` | Developer |
| Database migration | ✅ Schema docs + migration notes | `docs/reference/schema/DATABASE.md` | Developer |
| Architectural decision | ✅ ADR | `docs/explanation/architecture-decisions/` | Architect |
| Bug fix | ❌ Usually not required | N/A | N/A |
| Refactoring | ❌ Unless affects API/architecture | N/A | N/A |

---

## Pre-Commit Checklist

```markdown
## Before Committing

- [ ] Run link validator: `python scripts/validate_links.py`
- [ ] Update "Last Updated" timestamps
- [ ] Test code examples (if any)
- [ ] Check formatting (headers, lists, code blocks)
- [ ] Verify no broken links introduced
```

---

## Pre-PR Checklist

```markdown
## Before Creating Pull Request

### Code Changes
- [ ] API changes: OpenAPI spec updated
- [ ] New feature: Added to README.md
- [ ] Breaking change: CHANGELOG.md entry
- [ ] Env variables: .env.example + ENVIRONMENT.md updated
- [ ] Database change: Schema docs updated

### Architecture
- [ ] Significant decision: ADR created
- [ ] Pattern change: Architecture docs updated

### Validation
- [ ] Link validation passed
- [ ] Examples tested
- [ ] No typos

### Review
- [ ] Checkboxes complete or N/A explained
```

---

## Common Commands

### Link Validation
```bash
# Validate all links
python scripts/validate_links.py

# Fix broken links (dry run)
python scripts/fix_broken_links.py --dry-run

# Fix broken links (apply)
python scripts/fix_broken_links.py
```

### Documentation Updates
```bash
# Find stale docs
python scripts/update_stale_docs.py --scan

# Update stale docs (dry run)
python scripts/update_stale_docs.py --dry-run

# Apply updates
python scripts/update_stale_docs.py
```

### Version Bump (planned)
```bash
# Bump version
./scripts/bump-version.sh 6.0.15
```

---

## ADR Quick Start

### When to Create ADR

**Create if ANY of these are true**:
- ✅ Implementation effort >4 hours
- ✅ Affects multiple modules/services
- ✅ Changes public API contract
- ✅ Impacts security or compliance
- ✅ Introduces new dependencies
- ✅ Changes architectural patterns

### ADR Template Location

`docs/explanation/architecture-decisions/ADR-XXX-[title].md`

### Quick Template

```markdown
# ADR-XXX: [Title]

**Status**: PROPOSED | ACCEPTED
**Date**: YYYY-MM-DD

## Context
[Problem and constraints]

## Decision
[What we decided]

## Consequences
- **Positive**: [Benefits]
- **Negative**: [Costs]

## Alternatives
[Other options considered]
```

---

## Post-Mortem Quick Start

### When Required

- ✅ P0 (Critical): Always
- ✅ P1 (High): Always
- ✅ P2 (Medium): If >1 hour downtime
- ❌ P3 (Low): Optional

### Template Location

`docs/templates/post-mortem.md`

### Quick Template

```markdown
# Post-Mortem: [Incident]

**Incident ID**: INC-YYYY-MM-DD-###
**Severity**: P0 | P1 | P2

## Impact
[What broke and who was affected]

## Timeline
| Time | Event |
|------|-------|

## Root Cause (5 Whys)
1. Why?
2. Why?
3. Why? [Root cause]

## Action Items
- [ ] Immediate (24h)
- [ ] Short-term (1 week)
- [ ] Long-term (1 month)

## Lessons Learned
[Key takeaways]
```

---

## Migration Checklist

### Database Migration

```markdown
## Documentation Required

- [ ] Update DATABASE.md with new schema
- [ ] Regenerate Prisma schema docs
- [ ] Update API docs if endpoints affected
- [ ] Update type definitions
- [ ] Add migration notes to CHANGELOG.md
- [ ] Update affected feature docs
```

---

## Link Health Standards

| Health | Status | Action |
|--------|--------|--------|
| ≥95% | 🟢 Excellent | Merge allowed |
| 90-94% | 🟡 Good | Review recommended |
| <90% | 🔴 Poor | **Fixes required** |

---

## Freshness Targets

| Doc Type | Target | Review Frequency |
|----------|--------|------------------|
| API docs | <14 days | Every release |
| Core architecture | <30 days | Monthly |
| How-to guides | <60 days | Quarterly |
| Explanation | <90 days | Bi-annually |

---

## Timestamp Format

**Correct**:
```markdown
**Last Updated**: 2025-11-19
```

**Update When**:
- Content changes (always)
- Link fixes (if substantial)
- Validation review (even if no changes)
- Related code changes

---

## Status Badges

```markdown
## Feature Status

- ✅ **IMPLEMENTED**: Fully working
- 🚧 **PARTIAL**: Some functionality
- ⚠️ **PLANNED**: Designed but not implemented
- ❌ **DEPRECATED**: No longer supported
- 🔄 **BETA**: Working but not production-ready
```

---

## Common Pitfalls

### ❌ DON'T

- **Update links before moving files** (causes 500+ broken links)
- **Document planned features as complete** (false confidence)
- **Skip ADR for "obvious" decisions** (knowledge decay)
- **Create post-mortem months later** (memory decay)
- **Merge PRs without doc updates** (drift accumulation)
- **Maintain API docs manually** (guaranteed drift)
- **Ignore link validation failures** (rot compounds)

### ✅ DO

- **Validate links before committing** (catch early)
- **Use status badges for planned features** (accurate expectations)
- **Create ADRs during decision** (capture context)
- **Write post-mortems within 24 hours** (fresh memory)
- **Update docs in same PR as code** (stay in sync)
- **Plan to generate API docs from code** (single source of truth)
- **Fix broken links immediately** (prevent accumulation)

---

## Emergency Procedures

### If Link Health Drops Below 90%

1. **Stop merging PRs** with documentation changes
2. **Run automated fix**: `python scripts/fix_broken_links.py`
3. **Manually review fixes**: Check dry-run output
4. **Apply fixes**: Run without --dry-run
5. **Validate**: `python scripts/validate_links.py`
6. **Create PR**: Commit fixes
7. **Resume normal operations**: After health >95%

### If API Documentation Drifts

1. **Audit actual endpoints**: `grep -r "router\.(get|post|put|delete)" server/src/routes/`
2. **Compare to docs**: Extract from OpenAPI spec
3. **Create issues**: One per missing/wrong endpoint
4. **Prioritize fixes**: Wrong paths first, missing second
5. **Update OpenAPI**: Match actual code
6. **Test endpoints**: Verify docs now correct
7. **Add validation**: Prevent future drift

### If Documentation Goes Stale

1. **Run staleness scan**: `python scripts/update_stale_docs.py --scan`
2. **Review stale files**: Check what needs updating
3. **Update critical files first**: API, security, core architecture
4. **Run automated updates**: `python scripts/update_stale_docs.py --dry-run`
5. **Apply updates**: Run without --dry-run
6. **Manual review**: Check accuracy
7. **Update timestamps**: Reflect validation date

---

## Quick Links

### Scripts
- Link validation: `/Users/mikeyoung/CODING/rebuild-6.0/scripts/validate_links.py`
- Link repair: `/Users/mikeyoung/CODING/rebuild-6.0/scripts/fix_broken_links.py`
- Stale docs: `/Users/mikeyoung/CODING/rebuild-6.0/scripts/update_stale_docs.py`

### Templates
- Post-mortem: `/Users/mikeyoung/CODING/rebuild-6.0/docs/templates/post-mortem.md`
- Migration checklist: `/Users/mikeyoung/CODING/rebuild-6.0/docs/templates/migration-checklist.md`
- Feature checklist: `/Users/mikeyoung/CODING/rebuild-6.0/docs/templates/feature-checklist.md`

### CI/CD Workflows
- Link checking: `/Users/mikeyoung/CODING/rebuild-6.0/.github/workflows/check-links.yml`
- Docs validation: `/Users/mikeyoung/CODING/rebuild-6.0/.github/workflows/docs-validation.yml`

### Documentation
- Full guide: [README.md](./README.md)
- Patterns: [PATTERNS.md](./PATTERNS.md)
- Incidents: [INCIDENTS.md](./INCIDENTS.md)
- Prevention: [PREVENTION.md](./PREVENTION.md)
- AI guide: [AI-AGENT-GUIDE.md](./AI-AGENT-GUIDE.md)

---

## Contact

**Questions?** Check the full documentation guides or contact the Engineering Team.

**Issues?** Create a GitHub issue with label `documentation`.

**Improvements?** Submit a PR with your suggested changes.

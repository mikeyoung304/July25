---
category: "documentation-drift"
category_id: "10"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, link-rot, diataxis, freshness, sync]
---
# AI Agent Documentation Guidelines

**Guidelines for AI Assistants Working with Restaurant OS Documentation**

## Overview

This guide helps AI agents (like Claude Code) maintain documentation quality based on lessons learned from the November 2025 documentation crisis. These guidelines are derived from real incidents and prevention systems implemented.

---

## Core Principles

### 1. Documentation and Code Changes Are Inseparable

**Rule**: If you change code, you MUST update documentation in the same commit/PR.

**Examples**:
```typescript
// ✅ CORRECT
// PR includes:
// - server/src/routes/payments.routes.ts (code change)
// - docs/reference/api/openapi.yaml (API doc update)
// - CHANGELOG.md (user-facing change)

// ❌ INCORRECT
// PR includes:
// - server/src/routes/payments.routes.ts (code change)
// - No documentation updates
// - Promise to "update docs later"
```

**Rationale**: "Later" never happens. Documentation drift starts with a single undocumented change.

### 2. Validate Before Committing

**Rule**: Always run validation scripts before committing documentation changes.

**Required Commands**:
```bash
# Before committing any .md file changes
python scripts/validate_links.py

# If validation fails, fix immediately
python scripts/fix_broken_links.py --dry-run  # Preview
python scripts/fix_broken_links.py            # Apply
```

**Rationale**: Link rot compounds exponentially. One broken link becomes 884 in 4 months.

### 3. Use Templates Consistently

**Rule**: Always use provided templates for structured documentation.

**Templates Available**:
- `docs/templates/post-mortem.md` - Incident reviews
- `docs/templates/migration-checklist.md` - Database migrations
- `docs/templates/feature-checklist.md` - Feature development
- `docs/explanation/architecture-decisions/ADR-TEMPLATE.md` - Architecture decisions

**Rationale**: Consistency enables searchability and completeness.

### 4. Status Badges for Planned Features

**Rule**: Never document planned features as complete. Use status badges.

**Correct Pattern**:
```markdown
## Kitchen Display Notifications

**Status**: ⚠️ **PLANNED** (Phase 3)

Event schema defined but broadcasting not yet implemented.
Kitchen confirmations are logged but not delivered to displays.

**Current Behavior**:
- Orders transition to "confirmed" state
- Confirmation logged: `Order confirmed, notifying kitchen`
- No actual notification sent to KDS

**Timeline**: Q1 2026 (see TODO_ISSUES.csv line 7)
```

**Incorrect Pattern**:
```markdown
## Kitchen Display Notifications

The Kitchen Display System provides real-time notifications...
[Describes feature as if it works, but it's just a TODO in code]
```

**Rationale**: False confidence leads to production failures. The November 2025 audit found 3 systems documented as "working" but completely stubbed.

### 5. Generate Don't Duplicate

**Rule**: Generate documentation from code when possible. Never duplicate information.

**Examples**:
- ✅ Generate API docs from route decorators
- ✅ Generate schema docs from Prisma schema
- ✅ Extract types from TypeScript interfaces
- ❌ Manually copy endpoint paths
- ❌ Manually document database schema
- ❌ Copy-paste TypeScript types into docs

**Rationale**: Manual duplication guarantees drift. API documentation accuracy dropped to 42% from manual maintenance.

---

## When to Create Documentation

### ADR (Architecture Decision Record)

**Create ADR if ANY are true**:
- ✅ Implementation effort >4 hours
- ✅ Affects multiple modules/services
- ✅ Changes public API contract
- ✅ Impacts security or compliance
- ✅ Introduces new dependencies
- ✅ Changes architectural patterns
- ✅ Performance implications

**Process**:
1. Copy template from `docs/explanation/architecture-decisions/ADR-TEMPLATE.md`
2. Number sequentially (find highest existing number + 1)
3. Fill all sections (no "TBD" placeholders)
4. Set status to PROPOSED initially
5. Link to related ADRs
6. Include code examples
7. Get review from 2+ architects
8. Update status to ACCEPTED when approved

**Example Trigger**:
```typescript
// If you're implementing this pattern...
// YOU NEED AN ADR

export class DualAuthenticationManager {
  async getToken() {
    // Check Supabase first
    const supabaseToken = await this.supabase.auth.getSession();
    if (supabaseToken) return supabaseToken;

    // Fallback to localStorage
    const localToken = localStorage.getItem('auth_session');
    if (localToken) return localToken;
  }
}

// ADR Required Because:
// - Affects multiple modules (all API calls)
// - Security implications (localStorage JWT)
// - Changes authentication pattern
// - Complex decision with tradeoffs
```

### Post-Mortem

**Create Post-Mortem for**:
- ✅ P0 (Critical): Always required
- ✅ P1 (High): Always required
- ✅ P2 (Medium): If >1 hour downtime or customer impact
- ⚠️ P3 (Low): Optional but recommended

**Timeline**:
- Within 24 hours: Create draft
- Within 48 hours: Hold blameless review meeting
- Within 1 week: Complete post-mortem
- Within 2 weeks: Complete action items

**Template**: `docs/templates/post-mortem.md`

**Example Trigger**:
```bash
# If you see commit messages like these...
# YOU NEED A POST-MORTEM

git log --oneline | grep -i "fix\|emergency\|hotfix\|critical"
# adac142 fix(critical): voice ordering auth failure
# 3a5d126 hotfix: payment endpoint 404 errors
# 09f8b34 emergency: link health at 63%

# These indicate incidents that should be documented
```

### Migration Checklist

**Create for Every**:
- Database schema changes
- Breaking API changes
- Major dependency updates
- Data migrations
- Infrastructure changes

**Template**: `docs/templates/migration-checklist.md`

**Example**:
```typescript
// If you're running this migration...
// YOU NEED A MIGRATION CHECKLIST

// supabase/migrations/20251119_add_confirmed_at.sql
ALTER TABLE orders ADD COLUMN confirmed_at TIMESTAMP;

// Checklist includes:
// - Update DATABASE.md
// - Update Prisma schema
// - Update TypeScript types
// - Update API docs
// - Update CHANGELOG.md
```

---

## Common Scenarios

### Scenario 1: Adding a New API Endpoint

**What to Update**:
```markdown
1. ✅ Code Implementation
   - server/src/routes/[resource].routes.ts
   - server/src/services/[resource].service.ts
   - server/src/types/[resource].types.ts

2. ✅ Documentation
   - docs/reference/api/openapi.yaml (add endpoint)
   - CHANGELOG.md (if user-facing)
   - README.md (if major feature)

3. ✅ Testing
   - server/src/routes/__tests__/[resource].test.ts
   - Update test documentation

4. ✅ Validation
   - Run: python scripts/validate_links.py
   - Test endpoint manually
   - Verify OpenAPI examples work
```

**Checklist**:
```markdown
- [ ] Endpoint implemented and tested
- [ ] OpenAPI spec updated with:
  - [ ] Path and method
  - [ ] Request schema
  - [ ] Response schema (200, 400, 401, 403, 404, 500)
  - [ ] Authentication requirements
  - [ ] RBAC scopes required
  - [ ] Example request/response
- [ ] CHANGELOG.md updated if user-facing
- [ ] README.md updated if major feature
- [ ] Link validation passed
- [ ] Endpoint tested manually
```

### Scenario 2: Refactoring Authentication

**What to Document**:
```markdown
1. ✅ Create ADR
   - Why refactoring? (context)
   - What are the options? (alternatives)
   - What did we decide? (decision)
   - What are the tradeoffs? (consequences)

2. ✅ Update Architecture Docs
   - docs/explanation/architecture/AUTHENTICATION_ARCHITECTURE.md
   - Update diagrams if flow changed
   - Add "Evolution" section if this is Nth iteration

3. ✅ Update API Docs
   - docs/reference/api/openapi.yaml (if auth headers changed)
   - Update authentication section

4. ✅ Migration Guide
   - If breaking change for integrators
   - Document old vs new patterns
```

**Red Flags** (from Actual Incident):
```typescript
// ❌ This pattern required 80+ hours of developer effort
// ❌ No documentation until Nov 19, 2025
// ❌ Same mistakes repeated multiple times
// ❌ New developers took 20+ hours to understand

// July-Nov 2025: 3 complete rewrites
// - Phase 1: Custom JWT (no docs)
// - Phase 2: Pure Supabase (no docs)
// - Phase 3: Dual auth (finally documented)

// Lesson: CREATE ADR DURING PHASE 1, NOT AFTER PHASE 3
```

### Scenario 3: Database Schema Change

**What to Update**:
```markdown
1. ✅ Migration File
   - supabase/migrations/YYYYMMDD_description.sql

2. ✅ Schema Documentation
   - docs/reference/schema/DATABASE.md
   - Add new column to table documentation
   - Update ERD if relationships changed

3. ✅ Type Definitions
   - Regenerate Prisma schema: npx prisma db pull
   - Update shared/types if needed

4. ✅ API Documentation
   - Update OpenAPI if endpoints affected
   - Update request/response examples

5. ✅ Migration Checklist
   - Use template: docs/templates/migration-checklist.md
   - Document rollback procedure
```

**Automation** (Prevents Drift):
```bash
# Generate schema docs from Prisma (planned)
npm run generate-schema-docs

# This eliminates manual sync requirement
# Schema docs become single source of truth
```

### Scenario 4: Discovering Stale Documentation

**What to Do**:
```markdown
1. ✅ Run Staleness Scan
   python scripts/update_stale_docs.py --scan

2. ✅ Review Output
   - Identify outdated version references
   - Find deprecated API paths
   - Check for removed features still documented

3. ✅ Update Systematically
   # Dry run first
   python scripts/update_stale_docs.py --dry-run

   # Review proposed changes
   # Apply if correct
   python scripts/update_stale_docs.py

4. ✅ Manual Review
   - Automated script catches common patterns
   - Manual review catches context changes
   - Update "Last Updated" timestamps

5. ✅ Create Issue
   - If major staleness found
   - Track as documentation debt
   - Prioritize by impact
```

### Scenario 5: Fixing Broken Links

**What to Do**:
```markdown
1. ✅ Validate Current State
   python scripts/validate_links.py

2. ✅ Automated Fix (First Pass)
   # Dry run
   python scripts/fix_broken_links.py --dry-run

   # Review output
   # Apply fixes
   python scripts/fix_broken_links.py

3. ✅ Manual Fix (Remaining)
   - Check unfixable links report
   - Determine if:
     - File was deleted (remove link)
     - File was renamed (update link)
     - File was moved (update path)
     - Link is intentional template (add to allowlist)

4. ✅ Validate Again
   python scripts/validate_links.py

   # Target: ≥95% link health
   # Critical: Merge blocked if <90%

5. ✅ Update Documentation
   - If structural changes made
   - Document new organization
   - Update navigation
```

---

## Anti-Patterns to Avoid

### Anti-Pattern 1: "I'll Document It Later"

**Why This Fails**:
- "Later" becomes "never" (evidence: 80+ hours undocumented)
- Context is lost (can't remember why decisions were made)
- Knowledge becomes siloed (only original developer knows)

**Correct Approach**:
```markdown
# ✅ Document DURING development
1. Design phase → Create ADR
2. Implementation → Update API docs
3. Testing → Update test docs
4. Deployment → Update ops docs

# Timeline: Same PR, not "later"
```

### Anti-Pattern 2: Copy-Paste Documentation

**Why This Fails**:
- Duplicated info creates multiple sources of truth
- Updates miss some copies (guaranteed drift)
- No way to validate consistency

**Example of Failure**:
```yaml
# docs/reference/api/openapi.yaml
/api/v1/payments/process:  # ❌ Copied from old version

# server/src/routes/payments.routes.ts
router.post('/api/v1/payments/create', ...)  # Actual endpoint

# Result: 404 for all integrators following docs
```

**Correct Approach**:
```markdown
# ✅ Single source of truth
- Code is truth
- Generate docs from code
- Never copy-paste paths/types/schemas
```

### Anti-Pattern 3: Incomplete Migrations

**Why This Fails**:
- Worst of both worlds (old and new broken)
- 500+ broken links from Diataxis migration
- Cannot find anything

**Example of Failure**:
```markdown
# October 2025: Diataxis Migration (INCOMPLETE)

# Step 1: Update all links ✅
[DATABASE.md](./reference/schema/DATABASE.md)

# Step 2: Move files ❌ NEVER DONE
# Files still in old location
docs/DATABASE.md (actual location)

# Result: 500+ broken links
```

**Correct Approach**:
```markdown
# ✅ Complete migrations atomically
1. Create new structure in parallel
2. Move files first
3. Add redirects/stubs
4. Update links
5. Verify all links work
6. Merge as single PR
```

### Anti-Pattern 4: Optimistic Documentation

**Why This Fails**:
- Creates false confidence
- Production teams expect features that don't exist
- Support burden increases

**Example of Failure**:
```typescript
// Code Reality (November 2025)
OrderStateMachine.registerHook('*->confirmed', async (order) => {
  logger.info('Order confirmed, notifying kitchen');
  // TODO: Send notification to kitchen display
});

// Documentation Claimed
"Kitchen Display System with real-time notifications
keeps kitchen staff informed of new orders."

// Result: Teams deploy expecting feature, confused when it doesn't work
```

**Correct Approach**:
```markdown
## Kitchen Display Notifications

**Status**: ⚠️ **PLANNED** (Phase 3)

### Current Reality
- Orders transition to "confirmed" state ✅
- Confirmation is logged ✅
- No notification sent to displays ❌

### Planned Implementation
Timeline: Q1 2026
See: TODO_ISSUES.csv line 7
```

### Anti-Pattern 5: Manual API Documentation

**Why This Fails**:
- Developers forget to update
- Paths diverge from code (42% accuracy crisis)
- No validation against actual server

**Example of Failure**:
```yaml
# Manual OpenAPI (September 2025)
/api/v1/items:  # ❌ Wrong
/api/v1/categories:  # ❌ Wrong

# Actual Routes (September 2025)
/api/v1/menu/items:  # ✅ Actual
/api/v1/menu/categories:  # ✅ Actual

# Result: 100% of menu API calls fail
```

**Correct Approach** (Planned):
```typescript
// ✅ Generate from code
@api.get('/api/v1/menu/items')
@api.summary('List menu items')
@api.response(200, MenuItem[])
export async function listItems(req, res) {
  // Implementation
}

// OpenAPI generated automatically
// Impossible for drift
```

---

## Validation Checklist

### Before Committing

```markdown
- [ ] All code changes have corresponding documentation updates
- [ ] Link validation passed: `python scripts/validate_links.py`
- [ ] Timestamps updated where content changed
- [ ] Status badges used for planned features
- [ ] No TODO comments in documentation
- [ ] No copy-pasted paths/types/schemas
- [ ] Examples tested and working
```

### Before Creating PR

```markdown
- [ ] PR description explains documentation changes
- [ ] All documentation checklist items completed
- [ ] ADR created if significant architectural decision
- [ ] Migration checklist used if schema/API breaking change
- [ ] CHANGELOG.md updated if user-facing change
- [ ] README.md updated if new feature
- [ ] CI/CD will pass (link validation, formatting)
```

### After PR Merged

```markdown
- [ ] Monitor link health in CI/CD
- [ ] Watch for documentation-related issues
- [ ] Update documentation dashboard metrics
- [ ] Create follow-up issues for identified gaps
```

---

## Key Lessons from November 2025 Crisis

### Lesson 1: Link Rot Compounds Exponentially

**Data**: 50 broken links (July) → 884 broken links (November)

**Prevention**: Validate every PR, fix immediately

### Lesson 2: Manual API Docs Don't Scale

**Data**: API accuracy 42% after 3 months of manual maintenance

**Prevention**: Generate from code (planned)

### Lesson 3: Undocumented Decisions Decay

**Data**: 80+ hours of auth work undocumented, 20+ hours to onboard new developers

**Prevention**: Create ADRs during decision, not months later

### Lesson 4: Planned ≠ Complete

**Data**: 3 systems documented as "working" but completely stubbed

**Prevention**: Use status badges, validate against running system

### Lesson 5: Prevention Costs 10x Less Than Repair

**Data**: 6 hours/year prevention vs 40 hours emergency repair

**Prevention**: Automate validation, integrate into workflow

---

## Tools and Scripts

### Available Now

```bash
# Link validation
python scripts/validate_links.py

# Link repair
python scripts/fix_broken_links.py [--dry-run]

# Stale documentation
python scripts/update_stale_docs.py [--scan|--dry-run]
```

### Coming Soon

```bash
# API documentation generation
npm run generate-openapi

# Schema documentation generation
npm run generate-schema-docs

# API validation
npm run validate-api-docs
```

---

## Success Metrics

**Target State**:
- Link health: ≥95%
- API accuracy: ≥95%
- Documentation freshness: ≥90% <30 days
- ADR coverage: 100% major decisions
- Post-mortem completion: 100% P0-P2

**Current State** (November 19, 2025):
- Link health: 97.4% ✅
- API accuracy: 95% ✅
- Documentation freshness: ~85% ⚠️
- ADR coverage: 100% ✅
- Post-mortem completion: 100% ✅

---

## When in Doubt

1. **Check the quick reference**: [QUICK-REFERENCE.md](./QUICK-REFERENCE.md)
2. **Review patterns to avoid**: [PATTERNS.md](./PATTERNS.md)
3. **Learn from incidents**: [INCIDENTS.md](./INCIDENTS.md)
4. **Use prevention strategies**: [PREVENTION.md](./PREVENTION.md)
5. **Ask the team**: Create a GitHub issue with label `documentation`

---

## Final Reminder

**Documentation is not overhead - it's prevention.**

The Restaurant OS November 2025 crisis demonstrated that:
- 40 hours emergency repair
- 6 hours/year prevention
- **6.7x cheaper to prevent than repair**

**Every commit with code changes should include documentation changes.**

**Every architectural decision should be documented immediately.**

**Every incident should have a post-mortem within 24 hours.**

**Link validation is not optional.**

Following these guidelines prevents crisis and maintains the 95/100 documentation health achieved after the November 2025 repair sprint.

---

## Related Documentation

- [README.md](./README.md) - Overview and timeline
- [PATTERNS.md](./PATTERNS.md) - Drift patterns
- [INCIDENTS.md](./INCIDENTS.md) - Historical incidents
- [PREVENTION.md](./PREVENTION.md) - Prevention strategies
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Quick checklist

---
category: "performance-optimization"
category_id: "08"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, memory-leaks, bundle-size, lazy-loading, optimization]
---
# AI Agent Guide: Performance Optimization

## Overview

This guide provides specific instructions for AI agents (like Claude Code) working on performance-related tasks in Restaurant OS. It covers decision trees, patterns to follow, and common pitfalls to avoid.

---

## Decision Tree: When to Optimize

### 1. Check Memory First

```
Is memory usage reported?
├─ NO → Skip memory checks (likely documentation task)
└─ YES → Continue to memory check

Is memory > 3GB?
├─ NO → Memory OK, check bundle size
└─ YES → STOP. Address memory issue first.
         See: Memory Reduction Workflow
```

### 2. Check Bundle Size

```
Is bundle size > 100KB?
├─ NO → Bundle OK, check performance metrics
└─ YES → STOP. Reduce bundle size first.
         See: Bundle Optimization Workflow
```

### 3. Check Performance Metrics

```
Are there performance issues reported?
├─ NO → No optimization needed
└─ YES → Identify specific issue
         ├─ Slow renders → React Optimization Workflow
         ├─ Memory leaks → Memory Leak Workflow
         ├─ Slow API calls → API Optimization Workflow
         └─ Slow voice → Voice Optimization Workflow
```

---

## Workflow 1: Memory Reduction

### Step 1: Analyze Current Usage

```bash
# Always check memory first
ps aux | grep -E "node|vite" | awk '{sum+=$6} END {printf "%.0f MB\n", sum/1024}'
```

**If >3GB**: Proceed with reduction
**If <3GB**: No action needed

### Step 2: Identify Memory Hogs

**Priority Order**:

1. **Unmanaged timers** - Search for:
   ```bash
   grep -r "setInterval" --include="*.ts" | grep -v "clearInterval"
   grep -r "setTimeout" --include="*.ts" | grep -v "clearTimeout"
   ```

2. **Event listeners** - Search for:
   ```bash
   grep -r "addEventListener" --include="*.ts" | grep -v "removeEventListener"
   ```

3. **Duplicate dependencies** - Check:
   ```bash
   npm list | grep -E "@supabase|react|axios"
   ```

4. **Large caches** - Find:
   ```bash
   grep -r "new Map()" --include="*.ts"
   grep -r "cache" --include="*.ts" -i
   ```

### Step 3: Apply Fixes

**Fix Template for Timers**:

```typescript
// ❌ BEFORE
constructor() {
  setInterval(() => this.cleanup(), 60000);
}

// ✅ AFTER
private cleanupInterval: NodeJS.Timeout | null = null;

constructor() {
  this.cleanupInterval = setInterval(() => this.cleanup(), 60000);
}

shutdown(): void {
  if (this.cleanupInterval) {
    clearInterval(this.cleanupInterval);
    this.cleanupInterval = null;
  }
}
```

**Fix Template for Event Listeners**:

```typescript
// ❌ BEFORE
window.addEventListener('resize', () => this.handleResize());

// ✅ AFTER
private resizeHandler: (() => void) | null = null;

attach(): void {
  this.resizeHandler = () => this.handleResize();
  window.addEventListener('resize', this.resizeHandler);
}

detach(): void {
  if (this.resizeHandler) {
    window.removeEventListener('resize', this.resizeHandler);
    this.resizeHandler = null;
  }
}
```

### Step 4: Test

```typescript
// Always add tests
describe('Memory Leak Prevention', () => {
  it('clears interval on shutdown', () => {
    const service = new Service();
    const clearIntervalSpy = jest.spyOn(global, 'clearInterval');

    service.start();
    service.shutdown();

    expect(clearIntervalSpy).toHaveBeenCalled();
  });
});
```

### Step 5: Verify

```bash
# Run memory check
npm run memory:check

# Verify reduction
ps aux | grep -E "node|vite" | awk '{sum+=$6} END {printf "%.0f MB\n", sum/1024}'
```

---

## Workflow 2: Bundle Optimization

### Step 1: Analyze Bundle

```bash
# Build and check size
npm run build:client
ls -lh client/dist/assets/index*.js

# If >100KB, continue optimization
```

### Step 2: Identify Large Imports

**Check for eager imports**:

```bash
# Look for non-lazy route imports
grep -r "import.*from '@/pages'" client/src/App.tsx

# Look for heavy dependencies
npm run build:client -- --mode=analyze
```

### Step 3: Apply Lazy Loading

**For Routes**:

```typescript
// ❌ BEFORE
import AdminDashboard from '@/pages/AdminDashboard';

<Route path="/admin" element={<AdminDashboard />} />

// ✅ AFTER - Add to LazyRoutes.tsx
export const LazyRoutes = {
  AdminDashboard: lazy(() =>
    import(/* webpackChunkName: "admin" */ '@/pages/AdminDashboard')
  )
};

// Use in router
<Route
  path="/admin"
  element={<LazyRoute component={LazyRoutes.AdminDashboard} />}
/>
```

**For Heavy Components**:

```typescript
// ❌ BEFORE
import HeavyComponent from './HeavyComponent';

<HeavyComponent />

// ✅ AFTER
const HeavyComponent = lazy(() => import('./HeavyComponent'));

{showComponent && (
  <Suspense fallback={<Spinner />}>
    <HeavyComponent />
  </Suspense>
)}
```

### Step 4: Configure Manual Chunks

```typescript
// client/vite.config.ts
build: {
  rollupOptions: {
    output: {
      manualChunks: {
        'react-core': ['react', 'react-dom', 'react-router-dom'],
        'vendor': ['@tanstack/react-query', 'axios', 'zod'],
        'ui': ['lucide-react', 'sonner'],
        // Group by feature
        'order-system': ['./src/modules/order-system'],
        'voice-module': ['./src/modules/voice']
      }
    }
  }
}
```

### Step 5: Verify

```bash
# Check bundle size
npm run bundle:check

# Should be <100KB
ls -lh client/dist/assets/index*.js
```

---

## Workflow 3: React Optimization

### Step 1: Identify Slow Renders

**Use React DevTools Profiler**:

1. Open React DevTools
2. Go to Profiler tab
3. Click "Start profiling"
4. Perform slow action
5. Click "Stop profiling"
6. Identify components with high render time

**OR Search Code**:

```bash
# Find components in maps without memo
grep -r ".map(" client/src/components | grep -v "React.memo"

# Find inline handlers
grep -r "onClick={() =>" client/src/components
```

### Step 2: Apply React.memo

```typescript
// ❌ BEFORE
function MenuItem({ item, onAdd }) {
  return (
    <div onClick={() => onAdd(item)}>
      {item.name}
    </div>
  );
}

// ✅ AFTER
const MenuItem = React.memo(({ item, onAdd }) => {
  return (
    <div onClick={() => onAdd(item)}>
      {item.name}
    </div>
  );
});
```

### Step 3: Stabilize Handlers

```typescript
// ❌ BEFORE
function MenuGrid({ items }) {
  const handleAdd = (item) => { /* ... */ };

  return items.map(item => (
    <MenuItem item={item} onAdd={handleAdd} />
  ));
}

// ✅ AFTER
function MenuGrid({ items }) {
  const handleAdd = useCallback((item) => {
    // Add logic
  }, []); // Or include dependencies

  return items.map(item => (
    <MenuItem item={item} onAdd={handleAdd} />
  ));
}
```

### Step 4: Memoize Expensive Calculations

```typescript
// ❌ BEFORE
function MenuGrid({ items, searchTerm }) {
  const filtered = items.filter(/* ... */).sort(/* ... */);

  return <div>{filtered.map(/* ... */)}</div>;
}

// ✅ AFTER
function MenuGrid({ items, searchTerm }) {
  const filtered = useMemo(() => {
    return items.filter(/* ... */).sort(/* ... */);
  }, [items, searchTerm]);

  return <div>{filtered.map(/* ... */)}</div>;
}
```

### Step 5: Verify

```bash
# Test renders with React DevTools
# Should see significant reduction in render count/time
```

---

## Workflow 4: Memory Leak Investigation

### Step 1: Check for Leaks

```bash
# Look for symptoms
grep -r "setInterval" --include="*.ts" | grep -v "clearInterval"
grep -r "addEventListener" --include="*.ts" | grep -v "removeEventListener"
```

### Step 2: Add Cleanup

**Follow the pattern**:

1. Store reference to timer/listener
2. Create cleanup method
3. Call cleanup on shutdown/unmount
4. Integrate with graceful shutdown (server) or useEffect (client)

**Server Example**:

```typescript
class Service {
  private timer: NodeJS.Timeout | null = null;

  start(): void {
    this.timer = setInterval(() => this.work(), 60000);
  }

  stop(): void {
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }
  }
}

// In server.ts graceful shutdown
async function gracefulShutdown() {
  serviceInstance.stop();
  // ...
}
```

**Client Example**:

```typescript
function Component() {
  useEffect(() => {
    const timer = setInterval(() => { /* ... */ }, 1000);

    // CRITICAL: Return cleanup
    return () => clearInterval(timer);
  }, []);
}
```

### Step 3: Test

```typescript
describe('Memory Leak Prevention', () => {
  it('cleans up timer', () => {
    const service = new Service();
    const spy = jest.spyOn(global, 'clearInterval');

    service.start();
    service.stop();

    expect(spy).toHaveBeenCalled();
  });
});
```

---

## Common Pitfalls to Avoid

### Pitfall 1: Premature Optimization

```
❌ DON'T optimize without measuring first
✅ DO profile, identify bottleneck, then optimize
```

**Process**:
1. Profile (React DevTools, Chrome DevTools)
2. Identify actual slow component/operation
3. Optimize that specific issue
4. Verify improvement

### Pitfall 2: Breaking Memoization

```typescript
// ❌ DON'T create new functions in render
<MenuItem onClick={() => handleClick(item)} />

// ✅ DO use stable references
const handleClick = useCallback((item) => { ... }, []);
<MenuItem onClick={handleClick} item={item} />
```

### Pitfall 3: Forgetting Dependencies

```typescript
// ❌ DON'T omit dependencies
const value = useMemo(() => {
  return items.filter(i => i.category === category);
}, [items]); // Missing category!

// ✅ DO include all dependencies
const value = useMemo(() => {
  return items.filter(i => i.category === category);
}, [items, category]);
```

### Pitfall 4: Over-memoization

```typescript
// ❌ DON'T memo everything
const name = useMemo(() => user.name, [user]); // Pointless

// ✅ DO memo expensive operations only
const filteredList = useMemo(() => {
  return items.filter(/* complex */).sort(/* expensive */);
}, [items]);
```

### Pitfall 5: Missing Cleanup

```typescript
// ❌ DON'T forget cleanup
useEffect(() => {
  const timer = setInterval(() => { ... }, 1000);
}, []); // LEAK!

// ✅ DO return cleanup
useEffect(() => {
  const timer = setInterval(() => { ... }, 1000);
  return () => clearInterval(timer);
}, []);
```

---

## AI Agent-Specific Guidelines

### When You See a Performance Task

**Step 1: Understand Context**

```
Read these in order:
1. This file (AI-AGENT-GUIDE.md)
2. QUICK-REFERENCE.md (for limits)
3. PATTERNS.md (for solutions)
4. Issue description or error message
```

**Step 2: Identify Category**

```
Performance issue type:
- Memory? → Use Memory Reduction Workflow
- Bundle? → Use Bundle Optimization Workflow
- Renders? → Use React Optimization Workflow
- Leaks? → Use Memory Leak Investigation Workflow
```

**Step 3: Apply Appropriate Workflow**

Follow the workflow step-by-step. Don't skip steps.

**Step 4: Always Test**

```bash
npm run typecheck  # Types must pass
npm test           # Tests must pass
npm run build:client # Build must succeed
npm run bundle:check # Bundle must be under limit
```

**Step 5: Document Changes**

Include in commit message:
- What was optimized
- Metrics before/after
- How to verify improvement

### Code Review Checklist

Before submitting code:

```
✅ Memory
  ☐ All timers have cleanup
  ☐ All listeners removed
  ☐ Resources released

✅ Bundle
  ☐ Routes lazy loaded
  ☐ Heavy components lazy loaded
  ☐ Suspense provided

✅ React
  ☐ Memo on list items
  ☐ useMemo for expensive ops
  ☐ useCallback for handlers

✅ Testing
  ☐ Cleanup tests added
  ☐ Performance verified
  ☐ No regressions

✅ Documentation
  ☐ Commit message clear
  ☐ Metrics included
  ☐ Verification steps provided
```

### When to Ask for Help

**Ask if**:
- Memory usage unclear how to measure
- Bundle optimization not reducing size
- Performance metrics not improving
- Tests failing after optimization
- Unsure which workflow to use

**Don't ask if**:
- Checklist not complete (finish first)
- Haven't tested yet (test first)
- Haven't read docs (read first)

---

## Examples: Common Scenarios

### Scenario 1: "Memory usage too high"

**Your Response**:

```markdown
I'll help optimize memory usage. Let me check current usage first.

**Step 1: Measure**
Running memory check...
Current usage: 3500MB (exceeds 3GB limit)

**Step 2: Investigate**
Searching for unmanaged timers and listeners...
Found:
- VoiceWebSocketServer: No cleanup interval
- AuthRateLimiter: Module-level interval without cleanup

**Step 3: Fix**
Applying timer cleanup pattern:
1. Store interval reference
2. Add cleanup method
3. Integrate with graceful shutdown

**Step 4: Test**
Added 2 tests for cleanup verification.
Memory usage after fix: 2800MB ✅

**Files Changed**:
- server/src/voice/websocket-server.ts
- server/src/middleware/authRateLimiter.ts
- server/tests/memory-leak-prevention.test.ts

**Verification**:
npm run memory:check
# Output: ✅ Memory 2800MB within limit 3072MB
```

### Scenario 2: "Bundle size too large"

**Your Response**:

```markdown
I'll help reduce bundle size. Let me analyze the current bundle.

**Step 1: Measure**
Current main bundle: 150KB (exceeds 100KB limit)

**Step 2: Analyze**
Running bundle analyzer...
Largest chunks:
- AdminDashboard: 45KB (not lazy loaded)
- VoiceControlWebRTC: 35KB (not lazy loaded)
- react-query: 25KB (not separated)

**Step 3: Fix**
1. Moving AdminDashboard to LazyRoutes.tsx
2. Lazy loading VoiceControlWebRTC component
3. Adding manual chunk for react-query

**Step 4: Verify**
New main bundle: 85KB ✅ (15KB under limit)

**Files Changed**:
- client/src/routes/LazyRoutes.tsx
- client/src/App.tsx
- client/vite.config.ts

**Verification**:
npm run bundle:check
# Output: ✅ Bundle size 85KB within limit 100KB
```

### Scenario 3: "Component rendering slowly"

**Your Response**:

```markdown
I'll help optimize the component rendering. Let me investigate.

**Step 1: Profile**
Using React DevTools to identify slow renders...
MenuGrid component: 200ms per render (200 items)

**Step 2: Identify Issue**
- MenuItem components not memoized
- Inline onClick handlers breaking memo
- Filtering not memoized

**Step 3: Apply Optimizations**
1. Added React.memo to MenuItem
2. Wrapped handlers in useCallback
3. Memoized filtering with useMemo

**Step 4: Verify**
After optimization: 35ms per render ✅ (82% improvement)

**Files Changed**:
- client/src/modules/order-system/components/MenuGrid.tsx
- client/src/modules/order-system/components/MenuItem.tsx

**Performance**:
Before: 200ms per render
After: 35ms per render
Improvement: 82%
```

---

## Success Metrics

### Your Performance Optimization is Successful If:

```
✅ Memory usage <3GB (target: 1GB)
✅ Bundle size <100KB (main bundle)
✅ Tests passing (100%)
✅ Build succeeds
✅ Performance metrics improved (with numbers)
✅ No new warnings/errors
✅ Code follows patterns in PATTERNS.md
✅ Cleanup properly implemented
✅ Documentation clear and complete
```

### Red Flags (Stop and Reassess If):

```
❌ Memory usage increased
❌ Bundle size increased
❌ Tests failing
❌ Build failing
❌ Performance worse than before
❌ New console.log statements
❌ Missing cleanup in timers/listeners
❌ Inline functions in maps
❌ No tests for cleanup
```

---

## Final Checklist

**Before marking task complete**:

```
Performance Optimization Complete Checklist:

☐ Metrics measured before changes
☐ Appropriate workflow followed
☐ Code follows patterns from PATTERNS.md
☐ All tests passing (npm test)
☐ Bundle size check passing (npm run bundle:check)
☐ Memory check passing (npm run memory:check)
☐ Type checking passing (npm run typecheck)
☐ Cleanup properly implemented
☐ Tests added for cleanup
☐ Performance verified improved
☐ Metrics documented (before/after)
☐ Commit message includes metrics
☐ Files changed listed
☐ Verification steps provided
☐ No red flags present
```

---

**Version**: 1.0
**Last Updated**: 2025-11-19
**For**: AI Agents (Claude Code, GitHub Copilot, etc.)
**Status**: Active Guide

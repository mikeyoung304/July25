---
category: "performance-optimization"
category_id: "08"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "INCIDENTS"
incident_count: 3
total_cost: 10000
severity_distribution:
  P1: 3
tags: [memory-leaks, bundle-size, lazy-loading, optimization]
---
# Performance Optimization Incidents

## Overview

This document chronicles the major performance incidents encountered during Restaurant OS development, their impact, root causes, and resolutions. These serve as learning examples for future development.

---

## Incident 1: P0.8 Memory Leaks

**Date**: 2025-11-10
**Priority**: P0 (Critical - Stability)
**Status**: ✅ RESOLVED
**Duration**: 1.5 hours investigation + implementation

### Impact

- **Memory growth**: 1-20 MB/day from unmanaged timers
- **Active intervals**: 10-15 unmanaged across codebase
- **Event listeners**: 5-10 duplicate global listeners
- **Clean shutdown**: Incomplete, forced exit after 3 seconds

### Root Causes

#### 1. VoiceWebSocketServer Cleanup Interval

**File**: `server/src/voice/websocket-server.ts:32`

**Problem**:
```typescript
constructor() {
  // LEAK: No reference stored, cannot be cleared
  setInterval(() => this.cleanupInactiveSessions(), 60000);
}
```

**Impact**: Interval ran for entire server lifetime, preventing clean shutdown.

#### 2. AuthRateLimiter Cleanup Interval

**File**: `server/src/middleware/authRateLimiter.ts:249-259`

**Problem**:
```typescript
// LEAK: Module-level, no way to clear
setInterval(() => {
  for (const [clientId, attempts] of suspiciousIPs.entries()) {
    if (attempts < 3) {
      suspiciousIPs.delete(clientId);
    }
  }
}, 60 * 60 * 1000); // Every hour
```

**Impact**: Maps (suspiciousIPs, blockedIPs) grew indefinitely, could reach thousands of entries under attack.

#### 3. Error Tracker Window Listeners

**File**: `shared/monitoring/error-tracker.ts:61,71,278,284,288`

**Problem**:
```typescript
// LEAK: 5 global listeners with NO cleanup
window.addEventListener('error', (event) => { ... })
window.addEventListener('unhandledrejection', (event) => { ... })
window.addEventListener('popstate', () => { ... })
window.addEventListener('focus', () => { ... })
window.addEventListener('blur', () => { ... })
```

**Impact**: Multiple ErrorTracker instances created duplicate listeners, causing memory leaks and performance degradation.

#### 4. TwilioBridge Global Interval

**File**: `server/src/voice/twilio-bridge.ts`

**Problem**: Unmanaged 60-second interval identified in timer audit.

#### 5. RealTimeMenuTools Cart Cleanup

**File**: `server/src/ai/functions/realtime-menu-tools.ts`

**Problem**: Unmanaged 300-second (5-minute) cart cleanup interval.

### Investigation Approach

Utilized **5 parallel subagents** to analyze different subsystems:

1. **Graceful Shutdown Agent** - server.ts patterns
2. **Event Listener Agent** - addEventListener/on patterns
3. **WebSocket Agent** - WebSocket lifecycle
4. **AI Services Agent** - AI service cleanup
5. **Timer/Interval Agent** - setTimeout/setInterval usage

**Coverage**: 50+ files, 8,000+ lines reviewed

### Resolution

**Fixes Implemented**:

1. ✅ Stored timer references and added cleanup methods
2. ✅ Created startRateLimiterCleanup() / stopRateLimiterCleanup()
3. ✅ Enhanced graceful shutdown to call all cleanup methods
4. ✅ Added error handler cleanup (stops session on error)
5. ✅ Increased shutdown timeout from 3s to 5s

**Test Coverage**: 16 new tests (100% pass rate)

**Test File**: `server/tests/memory-leak-prevention.test.ts`

### Results

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Memory growth | 1-20 MB/day | <1 MB/day | 90-95% |
| Active intervals | 10-15 unmanaged | 0 | 100% |
| Event listeners | 5-10 duplicates | 0 | 100% |
| Clean shutdown | 3s force exit | 5s complete | ✅ |

### Post-Mortem Learnings

1. **Module-level intervals** must store references for cleanup
2. **Graceful shutdown** must explicitly call all cleanup methods
3. **Error handlers** must clean up resources before returning
4. **Comprehensive tests** prevent regression

**Documentation**: `/docs/investigations/P0_MEMORY_LEAK_ANALYSIS.md`

---

## Incident 2: 12GB Memory Bloat

**Date**: 2025-08-25
**Priority**: P0 (Critical - Developer Experience)
**Status**: ✅ RESOLVED
**Duration**: Multiple commits over 2 weeks

### Impact

- **Development builds**: Required 12GB RAM
- **Developer machines**: Unable to run on 8GB laptops
- **Build time**: Excessive due to memory pressure
- **Deployment**: Frequent OOM errors in CI/CD

### Root Causes

#### 1. Supabase SDK Version Mismatch

**Problem**: Client using @supabase/supabase-js 2.52.1, server using 2.39.7

**Impact**: Duplicate SDK instances loaded in memory (~150MB)

**Fix**: Updated server to 2.52.1 (commit 128e5dee)

#### 2. Excessive NODE_OPTIONS Limits

**Problem**:
```json
{
  "dev": "NODE_OPTIONS='--max-old-space-size=12288' ..."
}
```

**Impact**: Masking actual memory issues, allowing bloat to grow.

**Fix**: Reduced to 4GB, then 3GB, forcing optimization (commit 8c732642)

#### 3. Unbounded Response Cache

**Problem**:
```typescript
class ResponseCache {
  private maxSize = 100;  // Too large
  private maxMemory = 10 * 1024 * 1024; // 10MB
  private cleanupInterval = 60000; // Too slow
}
```

**Impact**: Cache growing to 100 entries × ~100KB each = ~10MB

**Fix**: Reduced maxSize to 50, maxMemory to 5MB, cleanupInterval to 30s

#### 4. WebRTC Audio Element Leaks

**Problem**: Audio elements not properly disposed after voice sessions.

**Fix**:
```typescript
cleanup(): void {
  if (this.audioElement) {
    this.audioElement.pause();
    this.audioElement.srcObject = null;
    this.audioElement.load(); // Force buffer release
    this.audioElement = null;
  }
}
```

**Impact**: 80-120MB saved per voice session

#### 5. Console.log String Retention

**Problem**: 33 console.log statements in WebRTCConnection.ts retaining strings in production.

**Fix**: Migrated all to logger (20-40MB savings)

#### 6. Dead Code Accumulation

**Problem**: 351 lines of dead code (unifiedApiClient.ts, normalize.ts) still bundled.

**Fix**: Deleted unused files after grep verification (0 imports)

### Resolution Timeline

```
12GB (Initial)
  ↓ Supabase version alignment (-150MB)
8GB
  ↓ NODE_OPTIONS reduction + cache limits (-2GB)
4GB (Commit 8c732642)
  ↓ WebRTC cleanup + console.log migration (-500MB)
3GB (Commit 128e5dee) ✅ Current
  ↓ (Future work)
1GB (Target)
```

### Results

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Dev memory | 12GB | 3GB | 75% |
| Build memory | 12GB | 3GB | 75% |
| OOM errors | Frequent | Rare | ~90% |
| Developer access | 16GB+ required | 8GB+ sufficient | ✅ |

### Post-Mortem Learnings

1. **Version alignment** critical for shared dependencies
2. **Memory limits** should force optimization, not hide problems
3. **Cache bounds** required on all caching mechanisms
4. **Resource cleanup** must be explicit and tested
5. **Dead code** should be removed promptly

---

## Incident 3: 1MB Bundle Explosion

**Date**: 2025-08-25
**Priority**: P1 (High - User Experience)
**Status**: ✅ RESOLVED
**Duration**: 1 day implementation

### Impact

- **Initial bundle**: 1MB (1024KB)
- **First paint**: ~3-5 seconds on 3G
- **Lighthouse score**: 65/100 (failing)
- **User complaints**: Slow loading

### Root Causes

#### 1. No Code Splitting

**Problem**: All routes bundled into main chunk.

```typescript
// ❌ BAD: Everything loaded upfront
import AdminDashboard from '@/pages/AdminDashboard';
import KitchenDisplay from '@/pages/KitchenDisplayOptimized';
import KioskPage from '@/pages/KioskPage';
```

**Impact**: 1MB main bundle, slow initial load.

#### 2. Heavy Components Not Lazy

**Problem**: VoiceControlWebRTC (~50KB) loaded even when not used.

**Impact**: Voice module loaded for all users, most never use it.

#### 3. Vendor Bundling

**Problem**: React, React-DOM, libraries all in one chunk.

**Impact**: Cache invalidation on any change, large single chunk.

#### 4. No Manual Chunking Strategy

**Problem**: Vite default chunking not optimal for app structure.

**Impact**: Inefficient chunk distribution.

### Resolution

**Commit**: 8e5c7630 - "feat: implement code splitting - reduce main bundle from 1MB to 93KB"

#### 1. Route-Based Lazy Loading

```typescript
// ✅ GOOD: Lazy load all routes
export const LazyRoutes = {
  AdminDashboard: lazy(() =>
    import(/* webpackChunkName: "admin" */ '@/pages/AdminDashboard')
  ),
  KitchenDisplay: lazy(() =>
    import(/* webpackChunkName: "kitchen" */ '@/pages/KitchenDisplayOptimized')
  ),
  // ... all routes
};
```

**File**: `/client/src/routes/LazyRoutes.tsx`

#### 2. Component-Level Lazy Loading

```typescript
// Heavy voice component only loads when modal opens
const VoiceControlWebRTC = lazy(() =>
  import('./VoiceControlWebRTC')
);

{showVoice && (
  <Suspense fallback={<Spinner />}>
    <VoiceControlWebRTC />
  </Suspense>
)}
```

#### 3. Intelligent Manual Chunking

```typescript
// vite.config.ts
build: {
  rollupOptions: {
    output: {
      manualChunks: {
        'react-core': ['react', 'react-dom', 'react-router-dom'],
        'vendor': ['@tanstack/react-query', 'axios', 'zod'],
        'ui': ['lucide-react', 'sonner', '@radix-ui/react-dialog'],
        'order-system': ['./src/modules/order-system'],
        'voice-module': ['./src/modules/voice']
      }
    }
  }
}
```

### Results

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Main bundle | 1024KB | 93KB | 91% |
| React Core | (bundled) | 45KB | ✅ Isolated |
| Vendor | (bundled) | 50KB | ✅ Isolated |
| Voice Module | (bundled) | 50KB | ✅ Lazy |
| Initial load time | 3-5s | 0.9-1.5s | 70% |
| Lighthouse score | 65/100 | 92/100 | +27 points |

### Post-Mortem Learnings

1. **Lazy loading** should be default for all routes
2. **Heavy components** need component-level code splitting
3. **Manual chunking** provides better control than defaults
4. **Performance budgets** enforce good patterns (CI/CD)

**Documentation**: `/docs/analysis/bundle-report.md`

---

## Incident 4: Voice Processing Latency

**Date**: 2025-11-07
**Priority**: P1 (High - Feature Usability)
**Status**: ⚠️ PARTIALLY RESOLVED
**Duration**: Ongoing optimization

### Impact

- **Total latency**: 1800-2500ms (best to worst case)
- **Budget**: 1000ms target
- **User experience**: Perceived lag, repeat orders
- **Feature adoption**: Lower than expected

### Root Causes

#### Voice Pipeline Breakdown

```
User presses button     →  0ms
Audio capture starts    →  +120ms  (Browser API)
WebRTC connection ready →  +280ms  (Connection establishment)
User speaks             →  +500ms  (Variable)
AI transcription        →  +350ms  (OpenAI API)
Fuzzy matching          →  +15ms   (Local)
Order added to cart     →  +10ms   (State update)
UI updated              →  +25ms   (React render)
--------------------------------
Total (best case):        ~1300ms
Total (typical):          ~1800ms ⚠️
Total (worst case):       ~2500ms ❌
```

#### Bottlenecks Identified

1. **WebRTC Connection** (280ms)
   - Connection established after button press
   - Could be pre-established when modal opens
   - **Potential savings**: -280ms

2. **Network Latency** (150-400ms variable)
   - OpenAI API round-trip time
   - Cannot be controlled
   - **Mitigation**: Optimistic UI, progress indicators

3. **AI Transcription** (350ms)
   - OpenAI Realtime API processing
   - Service dependency, cannot optimize
   - **Mitigation**: Streaming transcription (not yet implemented)

### Partial Resolution

**Optimizations Applied**:

1. ✅ Reduced fuzzy matching time (100ms → 15ms)
2. ✅ Optimized state updates (batching)
3. ✅ Improved UI feedback (immediate "listening" state)

**Results**:
- Best case: 1300ms (within budget ✅)
- Typical: 1800ms (over budget by 800ms ⚠️)
- Worst case: 2500ms (over budget by 1500ms ❌)

### Remaining Work

**High Priority**:

1. **Pre-establish WebRTC Connection** (-280ms)
   ```typescript
   useEffect(() => {
     if (showVoiceModal) {
       // Pre-connect when modal opens
       preConnectWebRTC();
     }
   }, [showVoiceModal]);
   ```

2. **Optimistic UI Updates** (perceived performance)
   ```typescript
   // Show "transcribing..." immediately
   // Add item to cart optimistically
   // Rollback on error
   ```

3. **Streaming Transcription** (lower perceived latency)
   - Show partial transcription as it arrives
   - User sees progress immediately

4. **Response Caching** (for common phrases)
   - Cache "burger", "fries", "coke" → menu items
   - Instant response for cached phrases

**Expected Results After Fixes**:
- Best case: 1020ms (within budget ✅)
- Typical: 1520ms (over by 520ms, but acceptable ✅)
- Worst case: 2220ms (better, with good UX ✅)

### Post-Mortem Learnings

1. **Network latency** is the primary bottleneck (uncontrollable)
2. **Perceived performance** matters more than actual latency
3. **Optimistic UI** can mask latency effectively
4. **Pre-connection** is critical for real-time features
5. **Performance budgets** may need adjustment for external dependencies

**Documentation**: `/docs/archive/2025-11/PERFORMANCE_REPORT.md`

---

## Incident 5: React Re-render Storms

**Date**: 2025-10-15 (ongoing)
**Priority**: P2 (Medium - Performance)
**Status**: ✅ MOSTLY RESOLVED
**Duration**: Multiple commits

### Impact

- **Menu scrolling**: Lag on 200+ item menus
- **Cart updates**: 100-200ms delay on quantity change
- **Kitchen display**: Slow updates on new orders
- **CPU usage**: High on order-heavy pages

### Root Causes

#### 1. Missing React.memo

**Problem**: Heavy components re-rendering on parent updates.

```typescript
// ❌ BAD: MenuItem re-renders when parent updates
function MenuItem({ item, onAdd }) {
  return (
    <div onClick={() => onAdd(item)}>
      {item.name} - ${item.price}
    </div>
  );
}
```

**Impact**: 200 menu items = 200 re-renders on unrelated state change.

#### 2. Unstable Handler References

**Problem**: New function instances breaking memoization.

```typescript
// ❌ BAD: New handleAdd function every render
function MenuGrid({ items }) {
  const handleAdd = (item) => { /* ... */ };

  return items.map(item =>
    <MenuItem item={item} onAdd={handleAdd} />
  );
}
```

**Impact**: React.memo useless if props always different.

#### 3. Expensive Inline Calculations

**Problem**: Filtering/sorting on every render.

```typescript
// ❌ BAD: Re-runs on every render
function MenuGrid({ items, searchTerm }) {
  const filteredItems = items.filter(/* ... */).sort(/* ... */);
  return <div>{filteredItems.map(/* ... */)}</div>;
}
```

**Impact**: 200ms+ calculation on every parent update.

#### 4. Infinite Re-render Loop

**Problem**: Modal props triggering parent updates.

```typescript
// ❌ BAD: Infinite loop in useToast
useEffect(() => {
  setModalProps({ onClose: () => closeModal() });
}, [closeModal]); // closeModal changes, triggers effect, changes modalProps, triggers effect...
```

**Impact**: Browser hang, 100% CPU usage.

**Fix**: Commit 982c7cd2 - "fix: critical infinite loop bug in useToast and modal prop sync"

### Resolution

**Optimizations Applied**:

1. ✅ Added React.memo to MenuItem components
2. ✅ Wrapped handlers in useCallback
3. ✅ Added useMemo for expensive calculations
4. ✅ Fixed infinite loop in useToast
5. ✅ Stabilized modal prop references

**Commit**: 597278eb - "perf: memoize heavy components, stabilize handlers, cleanup timers/listeners"

### Results

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| Menu scroll FPS | 30-40 | 55-60 | ~50% |
| Cart update time | 100-200ms | 30-50ms | 70% |
| Re-renders/action | 200+ | 10-20 | 90% |
| Infinite loops | 1 critical | 0 | 100% |

### Post-Mortem Learnings

1. **React.memo** required for list item components
2. **useCallback** critical for handler stability
3. **useMemo** for expensive filtering/sorting
4. **Effect dependencies** must be carefully managed
5. **Performance profiling** should be regular, not reactive

---

## Summary Statistics

### Issues Resolved

| Incident | Priority | Impact | Resolution Time | Status |
|----------|----------|--------|-----------------|--------|
| P0.8 Memory Leaks | P0 | Critical | 1.5 hours | ✅ Complete |
| 12GB Memory Bloat | P0 | Critical | 2 weeks | ✅ Complete |
| 1MB Bundle Explosion | P1 | High | 1 day | ✅ Complete |
| Voice Processing Latency | P1 | High | Ongoing | ⚠️ Partial |
| React Re-render Storms | P2 | Medium | Multiple | ✅ Mostly Complete |

### Overall Impact

- **Memory usage**: 12GB → 3GB (75% reduction)
- **Bundle size**: 1MB → 93KB (91% reduction)
- **Memory leaks**: 1-20 MB/day → <1 MB/day (90-95% reduction)
- **Re-renders**: 200+ → 10-20 (90% reduction)
- **Developer experience**: ✅ Dramatically improved
- **User experience**: ✅ Significantly improved

### Key Learnings

1. **Performance is a feature** - Must be tracked and enforced
2. **Proactive monitoring** - Don't wait for issues to appear
3. **Incremental optimization** - 12GB → 4GB → 3GB → 1GB (target)
4. **Comprehensive testing** - 16 tests prevent regression
5. **Documentation matters** - Future developers learn from incidents

---

**Version**: 1.0
**Last Updated**: 2025-11-19
**Next Review**: 2026-02-19 (3 months)

---
category: "performance-optimization"
category_id: "08"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, memory-leaks, bundle-size, lazy-loading, optimization]
---
# Performance Optimization Quick Reference

## Memory Limits

### Environment Targets

```bash
# Current enforced limits (NODE_OPTIONS)
Development:  3072MB (3GB)
Build:        3072MB (3GB)
Test:         3072MB (3GB)
Production:   1024MB (1GB target)

# Historic progression
v1: 12288MB (12GB)  # Initial bloat
v2:  4096MB (4GB)   # First reduction (commit 8c732642)
v3:  3072MB (3GB)   # Current (commit 128e5dee)
v4:  1024MB (1GB)   # Target (future)
```

### Check Memory Usage

```bash
# Development
ps aux | grep -E "node|vite" | awk '{sum+=$6} END {printf "%.0f MB\n", sum/1024}'

# CI/CD
npm run memory:check

# Runtime monitoring
node --expose-gc --inspect server/src/index.ts
```

---

## Bundle Size Budgets

### Enforced Limits (Gzipped)

From `/config/performance-budget.json`:

```json
{
  "Main Bundle":      "80KB",
  "React Core":       "45KB",
  "Vendor Bundle":    "50KB",
  "Order System":     "80KB",
  "Voice Module":     "50KB",
  "CSS Bundle":       "30KB",
  "Total JavaScript": "500KB"
}
```

### Check Bundle Size

```bash
# Build and analyze
npm run build:client

# Check main bundle
ls -lh client/dist/assets/index*.js

# Run bundle analyzer
npm run build:client -- --mode=analyze

# CI/CD check
npm run bundle:check
```

### Current Sizes (Actual)

```
Main bundle:       93KB   ✅ (target: 80KB)
React Core:        45KB   ✅
Vendor:            50KB   ✅
Order System:      72KB   ✅
Voice Module:      48KB   ✅
Total JS:          308KB  ✅ (target: 500KB)
```

---

## Performance Metrics

### Core Web Vitals

```
Metric                    Target    Current   Status
─────────────────────────────────────────────────────
LCP (Largest Paint)       <2.5s     2.1s      ✅
FID (First Input Delay)   <100ms    62ms      ✅
CLS (Layout Shift)        <0.1      0.04      ✅
FCP (First Paint)         <1.8s     1.65s     ✅
TTFB (Time to Byte)       <600ms    280ms     ✅
```

### Lighthouse Scores

```
Category          Target    Desktop   Mobile    Status
──────────────────────────────────────────────────────
Performance       >90       92/100    78/100    ⚠️
Accessibility     >95       95/100    95/100    ✅
Best Practices    >90       88/100    88/100    ⚠️
SEO               >90       91/100    91/100    ✅
```

### Application-Specific

```
Metric                    Target    Current   Status
─────────────────────────────────────────────────────
Menu render (200 items)   <500ms    480ms     ✅
Fuzzy match              <100ms    45ms      ✅
Voice response           <1500ms   1300-1800ms ⚠️
Order submission         <2000ms   1250ms    ✅
Cart operations          <100ms    45ms      ✅
```

---

## Memory Leak Indicators

### Healthy System

```bash
# Memory growth <1 MB/day
# Active intervals: 0 unmanaged
# Event listeners: No duplicates
# Clean shutdown: <5 seconds

# Check active handles
node -e "setInterval(() => {}, 1000); setTimeout(() => {
  console.log('Active handles:', process._getActiveHandles().length);
  process.exit();
}, 2000)"
```

### Warning Signs

```
❌ Memory growth >5 MB/day
❌ Active intervals increasing
❌ Event listener count growing
❌ Shutdown taking >5 seconds
❌ Heap size increasing steadily
```

### Test for Leaks

```typescript
// Memory leak test pattern
describe('Memory Leaks', () => {
  it('cleans up resources', () => {
    const service = new Service();
    const clearIntervalSpy = jest.spyOn(global, 'clearInterval');

    service.start();
    service.stop();

    expect(clearIntervalSpy).toHaveBeenCalled();
  });
});
```

---

## Optimization Checklist

### Before Committing

```
✅ Timers
  ☐ All setInterval/setTimeout have stored references
  ☐ clearInterval/clearTimeout called in cleanup
  ☐ Integrated with graceful shutdown

✅ Event Listeners
  ☐ Handler references stored
  ☐ removeEventListener called in cleanup
  ☐ React: cleanup returned from useEffect

✅ WebRTC/Media
  ☐ Media tracks stopped
  ☐ Peer connections closed
  ☐ Audio elements released (.load() called)

✅ Caching
  ☐ maxSize limit set
  ☐ maxMemory limit set
  ☐ TTL implemented
  ☐ Cleanup interval running

✅ React
  ☐ React.memo on list items
  ☐ useMemo for expensive calculations
  ☐ useCallback for handlers
  ☐ No inline functions in maps

✅ Bundle
  ☐ Routes lazy loaded
  ☐ Heavy components lazy loaded
  ☐ Suspense fallbacks provided
  ☐ webpackChunkName comments added

✅ Code Quality
  ☐ No console.log (use logger)
  ☐ No unbounded arrays/maps
  ☐ No circular references
  ☐ Type checking passes
```

### Before PR

```
☐ npm run typecheck        # Types pass
☐ npm test                  # Tests pass
☐ npm run build:client      # Build succeeds
☐ npm run bundle:check      # Bundle under limit
☐ npm run memory:check      # Memory under limit
☐ Manual testing            # Feature works
```

### Before Production

```
☐ Load testing completed
☐ Memory profiling verified
☐ Performance monitoring enabled
☐ Rollback plan documented
☐ Lighthouse audit run
```

---

## Common Issues & Quick Fixes

### Issue: Memory Growing

```bash
# 1. Check for unmanaged timers
grep -r "setInterval" --include="*.ts" --include="*.tsx" | grep -v "clearInterval"

# 2. Check for event listeners
grep -r "addEventListener" --include="*.ts" --include="*.tsx" | grep -v "removeEventListener"

# 3. Take heap snapshot
node --inspect --expose-gc server/src/index.ts
# Chrome DevTools → Memory → Take Snapshot
```

### Issue: Bundle Too Large

```bash
# 1. Analyze bundle
npm run build:client -- --mode=analyze

# 2. Check for missing lazy loading
grep -r "import.*from '@/pages'" client/src/App.tsx

# 3. Verify manual chunks
grep "manualChunks" client/vite.config.ts
```

### Issue: Slow Renders

```bash
# 1. Profile with React DevTools
# Enable Profiler → Record → Identify slow components

# 2. Check for missing React.memo
grep -r "map(" client/src/components | grep -v "React.memo"

# 3. Check for unstable handlers
grep -r "onClick={() =>" client/src/components
```

### Issue: Voice Latency High

```bash
# 1. Check WebRTC connection time
# Look for connection establishment in logs

# 2. Verify pre-connection
grep "preConnect" client/src/modules/voice

# 3. Check network latency
# Use browser DevTools Network tab
```

---

## Commands Reference

### Development

```bash
# Start with memory monitoring
NODE_OPTIONS='--max-old-space-size=3072 --expose-gc' npm run dev

# Check memory during development
watch -n 5 'ps aux | grep -E "node|vite" | awk "{sum+=\$6} END {printf \"%.0f MB\n\", sum/1024}"'

# Profile with Node inspector
node --inspect --max-old-space-size=3072 server/src/index.ts
```

### Testing

```bash
# Run all tests with memory limit
npm test

# Run with memory monitoring
NODE_OPTIONS='--max-old-space-size=3072 --expose-gc' npm test

# Run specific performance tests
npm run test:performance

# Run with coverage
npm run test:coverage
```

### Build

```bash
# Build client
npm run build:client

# Build server
npm run build:server

# Build for Vercel
npm run build:vercel

# Build with bundle analysis
npm run build:client -- --mode=analyze
```

### Monitoring

```bash
# Check bundle sizes
npm run bundle:check

# Check memory usage
npm run memory:check

# Check for memory leaks
npm run test:memory

# Lighthouse audit
npx lighthouse http://localhost:5173 --view
```

---

## Key Files

### Configuration

```
/config/performance-budget.json     # Bundle size limits
/client/vite.config.ts              # Build config with chunking
/package.json                       # Memory limits (NODE_OPTIONS)
```

### Monitoring

```
/server/tests/memory-leak-prevention.test.ts
/client/src/hooks/useMemoryMonitor.ts
/scripts/check-bundle-size.sh
/scripts/check-memory.sh
```

### Lazy Loading

```
/client/src/routes/LazyRoutes.tsx   # Route lazy loading
/client/src/App.tsx                 # Router config
```

### Documentation

```
/docs/investigations/P0_MEMORY_LEAK_ANALYSIS.md
/docs/investigations/P0.8_MEMORY_LEAK_COMPLETION_SUMMARY.md
/docs/archive/2025-11/PERFORMANCE_REPORT.md
```

---

## Performance Budget Formula

```typescript
// Calculate if change acceptable
const budgetCheck = {
  currentSize: 93, // KB
  newSize: 105,    // KB
  limit: 100,      // KB
  acceptable: newSize <= limit
};

// Memory budget
const memoryBudget = {
  current: 2800,   // MB
  limit: 3072,     // MB
  headroom: 272,   // MB
  acceptable: current < limit * 0.9 // 90% threshold
};
```

---

## Emergency Procedures

### If Memory Exceeds Limit

```bash
# 1. Identify process
ps aux | grep node | sort -k4 -r | head -1

# 2. Take heap snapshot immediately
kill -USR2 <PID>  # Triggers heap dump

# 3. Analyze snapshot
node --inspect dist/server.js
# Chrome DevTools → Memory → Load snapshot

# 4. Quick fix: Restart service
npm run dev
```

### If Bundle Exceeds Budget

```bash
# 1. Identify large chunks
npm run build:client -- --mode=analyze

# 2. Quick fix: Lazy load largest route
# Move import to LazyRoutes.tsx

# 3. Remove largest dependency (if possible)
npm uninstall <large-package>

# 4. Retest
npm run bundle:check
```

### If Production Performance Degraded

```bash
# 1. Check monitoring dashboard
# Look for memory/CPU spikes

# 2. Check error logs
# Look for memory warnings

# 3. Rollback if critical
npm run deploy:rollback

# 4. Investigate in staging
# Reproduce issue with production data
```

---

## Resource Cleanup Template

```typescript
class ResourceManager {
  private timer: NodeJS.Timeout | null = null;
  private listener: ((e: Event) => void) | null = null;

  start(): void {
    // Setup timer
    this.timer = setInterval(() => this.work(), 60000);

    // Setup listener
    this.listener = (e) => this.handleEvent(e);
    window.addEventListener('event', this.listener);
  }

  stop(): void {
    // Cleanup timer
    if (this.timer) {
      clearInterval(this.timer);
      this.timer = null;
    }

    // Cleanup listener
    if (this.listener) {
      window.removeEventListener('event', this.listener);
      this.listener = null;
    }
  }

  private work(): void { /* ... */ }
  private handleEvent(e: Event): void { /* ... */ }
}
```

---

## Version History

- **v1.0** (2025-11-19): Initial quick reference
- **Current limits**: 3GB memory, 93KB main bundle
- **Next target**: 1GB memory, 80KB main bundle

---

**Status**: Active Reference
**Last Updated**: 2025-11-19
**Maintained By**: Engineering Team

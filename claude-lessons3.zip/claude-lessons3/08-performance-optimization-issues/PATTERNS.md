---
category: "performance-optimization"
category_id: "08"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "PATTERNS"
tags: [memory-leaks, bundle-size, lazy-loading, optimization]
---
# Performance Optimization Patterns

## Overview

This document details the performance patterns, techniques, and best practices discovered and implemented during the Restaurant OS performance optimization initiative.

## Memory Leak Prevention

### Pattern 1: Timer Cleanup Pattern

**Problem**: Intervals and timeouts running indefinitely without cleanup.

**Solution**: Always store timer references and clear them.

```typescript
// ❌ BAD: No cleanup possible
class Service {
  constructor() {
    setInterval(() => this.cleanup(), 60000);
  }
}

// ✅ GOOD: Cleanup enabled
class Service {
  private cleanupInterval: NodeJS.Timeout | null = null;

  constructor() {
    this.cleanupInterval = setInterval(() => this.cleanup(), 60000);
  }

  shutdown(): void {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = null;
    }
  }
}
```

**Implementation**: Fixed in 5 critical locations (P0.8)
- VoiceWebSocketServer (60s cleanup)
- AuthRateLimiter (hourly cleanup)
- TwilioBridge
- RealTimeMenuTools (5min cart cleanup)

**Test**: `/server/tests/memory-leak-prevention.test.ts`

### Pattern 2: Event Listener Cleanup

**Problem**: Global event listeners never removed, accumulating on re-instantiation.

**Solution**: Store handler references, remove on cleanup.

```typescript
// ❌ BAD: Inline handlers can't be removed
window.addEventListener('error', (event) => {
  this.trackError(event);
});

// ✅ GOOD: Stored references for cleanup
class ErrorTracker {
  private errorHandler: ((event: ErrorEvent) => void) | null = null;

  attachListeners(): void {
    this.errorHandler = (event) => this.trackError(event);
    window.addEventListener('error', this.errorHandler);
  }

  cleanup(): void {
    if (this.errorHandler) {
      window.removeEventListener('error', this.errorHandler);
      this.errorHandler = null;
    }
  }
}
```

**Fixed in**: Error tracker (5 global listeners), cleanup-manager integration

### Pattern 3: WebRTC Resource Cleanup

**Problem**: Audio elements and media streams not released, causing memory accumulation.

**Solution**: Explicit cleanup with .load() to force buffer release.

```typescript
// ✅ GOOD: Complete WebRTC cleanup
cleanup(): void {
  // 1. Stop media streams
  if (this.mediaStream) {
    this.mediaStream.getTracks().forEach(track => track.stop());
    this.mediaStream = null;
  }

  // 2. Close peer connection
  if (this.peerConnection) {
    this.peerConnection.close();
    this.peerConnection = null;
  }

  // 3. Release audio element buffers
  if (this.audioElement) {
    this.audioElement.pause();
    this.audioElement.srcObject = null;
    this.audioElement.load(); // Force buffer release
    this.audioElement = null;
  }
}
```

**Impact**: Prevented 80-120MB leaks per voice session

## Bundle Optimization

### Pattern 4: Route-Based Code Splitting

**Problem**: 1MB initial bundle loading everything upfront.

**Solution**: Lazy load routes with React.lazy() and Suspense.

```typescript
// ✅ Lazy Routes Implementation
import { lazy, Suspense } from 'react';

export const LazyRoutes = {
  AdminDashboard: lazy(() =>
    import(/* webpackChunkName: "admin" */ '@/pages/AdminDashboard')
  ),
  KitchenDisplay: lazy(() =>
    import(/* webpackChunkName: "kitchen" */ '@/pages/KitchenDisplayOptimized')
  ),
  KioskPage: lazy(() =>
    import(/* webpackChunkName: "kiosk" */ '@/pages/KioskPage')
  ),
};

// Wrapper with suspense
export const LazyRoute = ({ component: Component, ...props }) => (
  <Suspense fallback={<LoadingSpinner />}>
    <Component {...props} />
  </Suspense>
);
```

**Results**:
- Main bundle: 1MB → 93KB (91% reduction)
- Initial load: ~70% faster
- All routes split into separate chunks

**Implementation**: `/client/src/routes/LazyRoutes.tsx`

### Pattern 5: Intelligent Vite Chunking

**Problem**: Vendor libraries bundled together causing large chunks.

**Solution**: Manual chunking strategy in vite.config.ts.

```typescript
// ✅ Vite Manual Chunks Strategy
build: {
  rollupOptions: {
    output: {
      manualChunks: {
        'react-core': ['react', 'react-dom', 'react-router-dom'],
        'vendor': ['@tanstack/react-query', 'axios', 'zod'],
        'ui': ['lucide-react', 'sonner', '@radix-ui/react-dialog'],
        'order-system': [
          './src/modules/order-system',
          './src/contexts/UnifiedCartContext'
        ],
        'voice-module': [
          './src/modules/voice',
          './src/modules/voice/services'
        ]
      }
    }
  }
}
```

**Results**:
- React Core: 45KB (isolated)
- Vendor: 50KB (isolated)
- Feature modules: 30-80KB each
- Better caching (core rarely changes)

### Pattern 6: Component-Level Code Splitting

**Problem**: Heavy components loading even when not used.

**Solution**: Lazy load heavy components independently.

```typescript
// ✅ Lazy Component Pattern
import { lazy, Suspense } from 'react';

// Heavy voice component only loads when needed
const VoiceControlWebRTC = lazy(() =>
  import('./VoiceControlWebRTC').then(m => ({ default: m.VoiceControlWebRTC }))
);

function VoiceOrderingMode() {
  const [showVoice, setShowVoice] = useState(false);

  return (
    <>
      <button onClick={() => setShowVoice(true)}>
        Start Voice Order
      </button>

      {showVoice && (
        <Suspense fallback={<Spinner />}>
          <VoiceControlWebRTC onClose={() => setShowVoice(false)} />
        </Suspense>
      )}
    </>
  );
}
```

**Impact**: Voice module only loads when activated (~50KB saved initially)

## React Performance Optimization

### Pattern 7: React.memo for Heavy Components

**Problem**: Components re-rendering unnecessarily on parent updates.

**Solution**: Memoize components with stable props.

```typescript
// ❌ BAD: Re-renders on every parent update
function MenuItem({ item, onAdd }) {
  return (
    <div onClick={() => onAdd(item)}>
      {item.name} - ${item.price}
    </div>
  );
}

// ✅ GOOD: Only re-renders when item or onAdd changes
const MenuItem = React.memo(({ item, onAdd }) => {
  return (
    <div onClick={() => onAdd(item)}>
      {item.name} - ${item.price}
    </div>
  );
}, (prevProps, nextProps) => {
  // Custom comparison for better control
  return prevProps.item.id === nextProps.item.id &&
         prevProps.onAdd === nextProps.onAdd;
});
```

**Applied to**:
- MenuGrid components
- KitchenDisplay order cards
- FloorPlanCanvas elements
- ServerMenuGrid items

**Results**: 60-70% fewer re-renders on menu/order updates

### Pattern 8: useMemo for Expensive Calculations

**Problem**: Expensive filtering/sorting running on every render.

**Solution**: Memoize calculations with dependency arrays.

```typescript
// ❌ BAD: Re-runs on every render
function MenuGrid({ items, searchTerm }) {
  const filteredItems = items.filter(item =>
    item.name.toLowerCase().includes(searchTerm.toLowerCase())
  );
  const sortedItems = filteredItems.sort((a, b) =>
    a.name.localeCompare(b.name)
  );

  return <div>{sortedItems.map(/* ... */)}</div>;
}

// ✅ GOOD: Only recalculates when dependencies change
function MenuGrid({ items, searchTerm }) {
  const filteredAndSorted = useMemo(() => {
    const filtered = items.filter(item =>
      item.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    return filtered.sort((a, b) => a.name.localeCompare(b.name));
  }, [items, searchTerm]);

  return <div>{filteredAndSorted.map(/* ... */)}</div>;
}
```

**Use cases**:
- Fuzzy matching (45ms → cached)
- Menu filtering (~85ms → cached)
- Order grouping
- Price calculations

**Results**: ~200ms saved per keystroke on search

### Pattern 9: useCallback for Stable Handlers

**Problem**: New function instances breaking memoization.

**Solution**: Wrap handlers in useCallback.

```typescript
// ❌ BAD: New function on every render breaks MenuItem memo
function MenuGrid({ items }) {
  const handleAdd = (item) => {
    // Add to cart
  };

  return items.map(item =>
    <MenuItem item={item} onAdd={handleAdd} />
  );
}

// ✅ GOOD: Stable reference preserves memoization
function MenuGrid({ items }) {
  const handleAdd = useCallback((item) => {
    // Add to cart
  }, []); // Empty deps if no external dependencies

  return items.map(item =>
    <MenuItem item={item} onAdd={handleAdd} />
  );
}
```

**Critical for**: Preventing infinite re-render loops in modals and forms

### Pattern 10: Debounced Search Input

**Problem**: Search triggers on every keystroke, causing lag.

**Solution**: Debounce input with useMemo wrapper.

```typescript
// ✅ Debounced Search Pattern
import { useMemo } from 'react';

function SearchBar({ onSearch }) {
  const debouncedSearch = useMemo(
    () => debounce((value: string) => onSearch(value), 150),
    [onSearch]
  );

  return (
    <input
      type="text"
      onChange={(e) => debouncedSearch(e.target.value)}
    />
  );
}
```

**Results**: Reduced search operations from 1/keystroke to 1/150ms

## Cache Management

### Pattern 11: Bounded Cache Pattern

**Problem**: Unbounded caches growing indefinitely.

**Solution**: Implement size and memory limits with TTL.

```typescript
// ✅ Bounded Cache Implementation
class ResponseCache {
  private cache = new Map();
  private maxSize = 50; // Was 100
  private maxMemory = 5 * 1024 * 1024; // 5MB (was 10MB)
  private cleanupInterval = 30000; // 30s (was 60s)

  set(key: string, value: any): void {
    // Enforce max size
    if (this.cache.size >= this.maxSize) {
      const firstKey = this.cache.keys().next().value;
      this.cache.delete(firstKey);
    }

    this.cache.set(key, {
      value,
      timestamp: Date.now(),
      size: this.estimateSize(value)
    });

    this.enforceMemoryLimit();
  }

  private enforceMemoryLimit(): void {
    let totalSize = 0;
    for (const entry of this.cache.values()) {
      totalSize += entry.size;
    }

    if (totalSize > this.maxMemory) {
      // Remove oldest entries
      const entries = Array.from(this.cache.entries())
        .sort((a, b) => a[1].timestamp - b[1].timestamp);

      for (const [key] of entries) {
        this.cache.delete(key);
        totalSize -= entries.find(e => e[0] === key)[1].size;
        if (totalSize <= this.maxMemory) break;
      }
    }
  }
}
```

**Impact**: 30-50MB memory savings from cache limits

## State Machine Safety

### Pattern 12: XState for Complex Flows

**Problem**: Voice ordering had deadlock in waiting_user_final state.

**Solution**: Use XState for complex state management.

```typescript
// ✅ State Machine Pattern
import { createMachine, assign } from 'xstate';

const voiceMachine = createMachine({
  id: 'voice',
  initial: 'idle',
  states: {
    idle: {
      on: { START: 'connecting' }
    },
    connecting: {
      on: {
        CONNECTED: 'listening',
        ERROR: 'error'
      }
    },
    listening: {
      on: {
        SPEECH_DETECTED: 'processing',
        TIMEOUT: 'idle'
      }
    },
    processing: {
      on: {
        COMPLETE: 'idle',
        ERROR: 'error'
      },
      // FIXED: Add timeout to prevent deadlock
      after: {
        5000: 'idle' // Auto-return after 5s
      }
    },
    error: {
      on: { RETRY: 'connecting' }
    }
  }
});
```

**Fixed**: Deadlock issues in voice ordering workflow

## Large List Virtualization

### Pattern 13: Virtual Scrolling (Recommended)

**Problem**: Rendering 500+ menu items causes lag (850ms).

**Solution**: Use react-window for virtualization.

```typescript
// ✅ Virtual List Pattern (not yet implemented, documented for future)
import { FixedSizeList as List } from 'react-window';

function MenuGrid({ items }) {
  const Row = ({ index, style }) => (
    <div style={style}>
      <MenuItem item={items[index]} />
    </div>
  );

  return (
    <List
      height={600}
      itemCount={items.length}
      itemSize={120}
      width="100%"
    >
      {Row}
    </List>
  );
}
```

**Expected results**: 850ms → 200ms for 500 items (75% improvement)

**Status**: Recommended for future implementation

## Memory Profiling

### Pattern 14: Continuous Memory Monitoring

**Problem**: Memory leaks difficult to detect without monitoring.

**Solution**: Add memory metrics to production.

```typescript
// ✅ Memory Monitoring Pattern
setInterval(() => {
  if (typeof process !== 'undefined') {
    const used = process.memoryUsage();
    logger.metric('memory.heap.used', Math.round(used.heapUsed / 1024 / 1024));
    logger.metric('memory.heap.total', Math.round(used.heapTotal / 1024 / 1024));
    logger.metric('memory.external', Math.round(used.external / 1024 / 1024));
  }
}, 60000); // Every minute
```

**Metrics tracked**:
- Heap used (MB)
- Heap total (MB)
- External memory (MB)
- GC frequency

## Performance Budget Enforcement

### Pattern 15: CI/CD Bundle Checks

**Problem**: Bundle size creeps up without enforcement.

**Solution**: Automated checks in CI/CD.

```bash
#!/bin/bash
# scripts/check-bundle-size.sh

MAX_SIZE=100000 # 100KB
BUNDLE_SIZE=$(stat -f%z client/dist/assets/index*.js)

if [ $BUNDLE_SIZE -gt $MAX_SIZE ]; then
  echo "❌ Bundle size ${BUNDLE_SIZE} exceeds limit ${MAX_SIZE}"
  exit 1
fi

echo "✅ Bundle size ${BUNDLE_SIZE} within limit ${MAX_SIZE}"
```

**GitHub Action**:
```yaml
- name: Check Bundle Size
  run: npm run build:client && ./scripts/check-bundle-size.sh
```

## Anti-Patterns to Avoid

### 1. Console.log in Production
```typescript
// ❌ NEVER: Retains strings in memory
console.log('Order created', orderData);

// ✅ ALWAYS: Use logger
logger.info('Order created', { orderId: orderData.id });
```

### 2. Unmanaged Subscriptions
```typescript
// ❌ NEVER: No cleanup
useEffect(() => {
  const subscription = observable.subscribe(handler);
}, []);

// ✅ ALWAYS: Return cleanup
useEffect(() => {
  const subscription = observable.subscribe(handler);
  return () => subscription.unsubscribe();
}, []);
```

### 3. Circular References
```typescript
// ❌ NEVER: Prevents garbage collection
const obj1 = { name: 'First' };
const obj2 = { name: 'Second' };
obj1.ref = obj2;
obj2.ref = obj1; // Circular!

// ✅ ALWAYS: Use weak references or break cycles
const obj1 = { name: 'First' };
const obj2 = { name: 'Second' };
obj1.refId = obj2.id; // Reference by ID
```

## Summary

These patterns represent hard-won lessons from the performance optimization initiative:

- **Memory leaks**: Always cleanup timers, listeners, and resources
- **Bundle size**: Lazy load routes and heavy components
- **React optimization**: Memo, useMemo, useCallback strategically
- **Caching**: Implement bounds on all caches
- **State management**: Use state machines for complex flows
- **Monitoring**: Track metrics continuously

**Key principle**: Performance is a feature, not a refactor.

---

**Version**: 1.0
**Last Updated**: 2025-11-19
**Status**: Production Proven

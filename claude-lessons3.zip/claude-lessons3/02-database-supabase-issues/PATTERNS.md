---
category: "database-supabase"
category_id: "02"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "PATTERNS"
tags: [schema-drift, rpc-functions, prisma, migrations, remote-first]
---
# Database Patterns - Remote-First Architecture

**Last Updated:** 2025-11-19

---

## Table of Contents
1. [Remote-First Architecture](#remote-first-architecture)
2. [RPC Signature Sync Requirements](#rpc-signature-sync-requirements)
3. [Migration Dependency Ordering](#migration-dependency-ordering)
4. [VARCHAR vs TEXT Type Issues](#varchar-vs-text-type-issues)
5. [Timestamp Format Requirements](#timestamp-format-requirements)
6. [Idempotent Migration Patterns](#idempotent-migration-patterns)

---

## Remote-First Architecture

### The Core Principle (ADR-010)

```
┌──────────────────────────────────────────────────────┐
│  Remote Supabase Database = SINGLE SOURCE OF TRUTH   │
│                                                       │
│  Everything else is DERIVED:                         │
│  • Prisma schema (GENERATED via db pull)             │
│  • TypeScript types (GENERATED from Prisma)          │
│  • API contracts (DERIVED from types)                │
└──────────────────────────────────────────────────────┘
```

### What This Means in Practice

#### ❌ WRONG: Treating Prisma Schema as Source of Truth
```typescript
// Step 1: Edit prisma/schema.prisma
model Order {
  id String @id @default(uuid())
  version Int @default(1)  // ← Manually added
}

// Step 2: Run prisma db push
$ npx prisma db push

// Step 3: Assume database now has version column
```

**Why This Fails:**
- Prisma `db push` bypasses Supabase migration system
- No migration history recorded
- RLS policies not updated
- Triggers not created
- Next `prisma db pull` overwrites your changes

#### ✅ CORRECT: Remote-First Workflow
```bash
# Step 1: Create SQL migration file
$ TIMESTAMP=$(date +"%Y%m%d%H%M%S")
$ touch "supabase/migrations/${TIMESTAMP}_add_version_to_orders.sql"

# Step 2: Write idempotent SQL
$ cat supabase/migrations/${TIMESTAMP}_add_version_to_orders.sql
```

```sql
-- Add version column to orders table
ALTER TABLE orders
ADD COLUMN IF NOT EXISTS version INTEGER DEFAULT 1;

-- Add comment for documentation
COMMENT ON COLUMN orders.version IS
'Optimistic locking version. Incremented on every update.';

-- Backfill existing records
UPDATE orders SET version = 1 WHERE version IS NULL;

-- Validation
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'version'
  ) THEN
    RAISE EXCEPTION 'Migration failed: version column not created';
  END IF;
  RAISE NOTICE 'Migration successful: version column added to orders';
END $$;
```

```bash
# Step 3: Deploy to remote database
$ supabase db push --linked

# Step 4: CRITICAL - Pull schema back to Prisma
$ npx prisma db pull

# Step 5: Fix @ignore attributes (known Prisma limitation)
$ ./scripts/post-migration-sync.sh

# Step 6: Verify Prisma schema updated
$ git diff prisma/schema.prisma
```

**Why This Works:**
- Migration recorded in `supabase_migrations.schema_migrations` table
- Remote database updated atomically
- Prisma schema generated from actual database state
- No risk of schema drift

---

## RPC Signature Sync Requirements

### The Dual Signature Problem

RPC functions have TWO signatures that must stay in sync:
1. **Parameters** - What calling code sends
2. **RETURNS TABLE** - What calling code expects back

**If EITHER signature drifts from actual table schema → 500 errors**

### Anatomy of RPC Function Sync

```sql
CREATE FUNCTION create_order_with_audit(
  -- SIGNATURE #1: Parameters
  -- These must match what API/client code sends
  p_restaurant_id UUID,
  p_order_number TEXT,       -- ⚠️ Must match orders.order_number type
  p_type TEXT,                -- ⚠️ Must match orders.type type
  p_status TEXT DEFAULT 'pending',
  p_items JSONB DEFAULT '[]'::jsonb,
  p_subtotal DECIMAL DEFAULT 0,
  p_tax DECIMAL DEFAULT 0,
  p_total_amount DECIMAL DEFAULT 0,
  p_notes TEXT DEFAULT NULL,
  p_customer_name TEXT DEFAULT NULL,
  p_table_number TEXT DEFAULT NULL,
  p_seat_number INTEGER DEFAULT NULL,
  p_metadata JSONB DEFAULT '{}'::jsonb
)
RETURNS TABLE (
  -- SIGNATURE #2: Return columns
  -- These must EXACTLY match orders table column types
  id UUID,
  restaurant_id UUID,
  order_number TEXT,          -- ⚠️ VARCHAR here = production error
  type TEXT,                  -- ⚠️ Must match EXACTLY
  status TEXT,
  items JSONB,
  subtotal DECIMAL,
  tax DECIMAL,
  total_amount DECIMAL,
  notes TEXT,
  customer_name TEXT,
  table_number TEXT,
  seat_number INTEGER,
  metadata JSONB,
  created_at TIMESTAMPTZ,     -- ⚠️ TIMESTAMP here = production error
  updated_at TIMESTAMPTZ,
  version INTEGER              -- ⚠️ Missing this = production error
  -- ... all other columns from orders table
)
```

### The 6 RPC Failures (Oct-Nov 2025)

**Each failure = different sync issue:**

| Migration Date | Issue | Error Code | Fix |
|----------------|-------|------------|-----|
| 20251019180800 | Missing `version` in RETURNS TABLE | 500 (column not returned) | Added version to SELECT |
| 20251020221553 | Fixed version, but still VARCHAR types | 42804 | Not yet fixed |
| 20251022033200 | VARCHAR vs TEXT mismatch | 42804 | Changed all VARCHAR→TEXT |
| 20251029150000 | Added seat_number, types still wrong | 42804 | Not yet fixed |
| 20251030010000 | Added payment fields, consolidated types | 42804 | Not yet fixed |
| 20251105003000 | TIMESTAMPTZ vs TIMESTAMP | 42804 | Changed check_closed_at→TIMESTAMP |

**Pattern:** Every time orders table changed, RPC function needed update

### RPC Sync Verification Script

```bash
#!/bin/bash
# Verify RPC function signature matches table schema

FUNCTION_NAME="create_order_with_audit"
TABLE_NAME="orders"

echo "Checking RPC function: $FUNCTION_NAME"
echo "Against table: $TABLE_NAME"
echo ""

# Get table column types
echo "=== Table Column Types ==="
psql "$DATABASE_URL" -c "
SELECT
  column_name,
  data_type,
  udt_name
FROM information_schema.columns
WHERE table_name = '$TABLE_NAME'
ORDER BY ordinal_position;
"

# Get RPC function return types
echo ""
echo "=== RPC Function Return Types ==="
psql "$DATABASE_URL" -c "
SELECT
  p.proname AS function_name,
  pg_get_function_result(p.oid) AS return_type
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public'
  AND p.proname = '$FUNCTION_NAME';
"

# Check for common mismatches
echo ""
echo "=== Common Type Mismatches to Check ==="
echo "1. VARCHAR vs TEXT (most common failure)"
echo "2. TIMESTAMPTZ vs TIMESTAMP (2nd most common)"
echo "3. Missing columns added to table after RPC creation"
```

### RPC Creation Checklist

Before deploying an RPC function that reads from a table:

```bash
# 1. Get exact table schema
psql "$DATABASE_URL" -c "\d orders"

# 2. For EVERY column in RETURNS TABLE, verify:
#    - Column exists in table ✓
#    - Type EXACTLY matches (not just "compatible") ✓
#    - NOT NULL matches ✓
#    - Default value handled ✓

# 3. Test RPC function locally first
psql "$DATABASE_URL" -c "
SELECT * FROM create_order_with_audit(
  '11111111-1111-1111-1111-111111111111'::UUID,
  'TEST-001',
  'online',
  'pending'
);
"

# 4. Check for type mismatch errors
# Look for: 42804 (type mismatch)
# Look for: 42703 (column missing)
```

---

## Migration Dependency Ordering

### The RPC-Before-Table Trap

**WRONG Order (Caused Incident #2):**
```
1. Deploy RPC function that INSERTs into order_status_history.created_at
2. (Never created created_at column in order_status_history table)
3. Production calls RPC → ERROR 42703
```

**CORRECT Order:**
```
1. Add created_at column to order_status_history table
2. Deploy table migration first
3. Then deploy RPC function that uses created_at
4. Both operations succeed
```

### Migration Ordering Rules

#### Rule 1: Table Columns Before RPC Functions

```sql
-- Migration 1: 20251019180000_add_created_at_column.sql
ALTER TABLE order_status_history
ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();
```

```sql
-- Migration 2: 20251019180800_add_rpc_using_created_at.sql
-- This can now safely reference created_at
CREATE FUNCTION log_order_status(...)
RETURNS void AS $$
BEGIN
  INSERT INTO order_status_history (order_id, from_status, to_status, created_at)
  VALUES (p_order_id, p_from, p_to, now());
END;
$$ LANGUAGE plpgsql;
```

#### Rule 2: Drop Dependencies Before Dropping Tables

```sql
-- Migration 1: Drop RPC functions using the table
DROP FUNCTION IF EXISTS get_order_stats;
DROP FUNCTION IF EXISTS create_order_with_audit;

-- Migration 2: Now safe to drop/modify table
DROP TABLE IF EXISTS orders;
```

#### Rule 3: Rename Columns in 3 Steps (Zero-Downtime)

```sql
-- Step 1: Add new column
ALTER TABLE orders ADD COLUMN customer_email TEXT;

-- Step 2: Backfill data + Deploy code using both columns
UPDATE orders SET customer_email = user_email WHERE customer_email IS NULL;
-- Code deployed that writes to BOTH user_email and customer_email

-- Step 3: After all traffic migrated, drop old column
ALTER TABLE orders DROP COLUMN user_email;
```

### Dependency Chain Example (Real from Restaurant OS)

**Correct deployment order for audit logging feature:**

```
20251019180000_add_tax_rate_to_restaurants.sql
  ↓ (tax_rate column exists)
20251019180800_add_create_order_with_audit_rpc.sql
  ↓ (RPC function uses tax_rate from restaurants)
20251019183600_add_version_to_orders.sql
  ↓ (version column exists)
20251020221553_fix_create_order_with_audit_version.sql
  ↓ (RPC function returns version)
20251021231910_add_created_at_to_order_status_history.sql
  ↓ (created_at column exists)
20251022033200_fix_rpc_type_mismatch.sql
  ↓ (RPC types match table types)
```

**If any step skipped or reordered → production failure**

---

## VARCHAR vs TEXT Type Issues

### The PostgreSQL Type Compatibility Trap

**What Developers Expect (WRONG):**
> "VARCHAR and TEXT are basically the same in PostgreSQL, so using either should work."

**PostgreSQL Reality:**
> "RETURNS TABLE type must EXACTLY match table column type. VARCHAR ≠ TEXT."

### Error Message Anatomy

```
ERROR: 42804: Returned type text does not match expected type character varying in column 3
CONTEXT: PL/pgSQL function create_order_with_audit(...) line 28 at RETURN QUERY
```

**Translation:**
- Column 3 of RETURNS TABLE = `order_number`
- RPC declared: `order_number VARCHAR`
- Table has: `order_number TEXT`
- PostgreSQL refuses to cast automatically in RETURNS TABLE context

### Type Mismatch Detection

```sql
-- Check what types your table actually uses
SELECT
  column_name,
  data_type,
  udt_name,
  character_maximum_length
FROM information_schema.columns
WHERE table_name = 'orders'
AND column_name IN ('order_number', 'type', 'status', 'customer_name', 'table_number');

-- Common results in Restaurant OS:
-- order_number:   text (not character varying)
-- type:           text
-- status:         text
-- customer_name:  text
-- table_number:   text
```

### The Fix Pattern

```sql
-- BEFORE (causes 42804 errors):
CREATE FUNCTION create_order_with_audit(
  p_order_number VARCHAR,  -- ❌ Wrong type
  p_type VARCHAR           -- ❌ Wrong type
)
RETURNS TABLE (
  order_number VARCHAR,    -- ❌ Wrong type
  type VARCHAR             -- ❌ Wrong type
)
```

```sql
-- AFTER (matches table schema):
CREATE FUNCTION create_order_with_audit(
  p_order_number TEXT,     -- ✅ Matches table
  p_type TEXT              -- ✅ Matches table
)
RETURNS TABLE (
  order_number TEXT,       -- ✅ Matches table
  type TEXT                -- ✅ Matches table
)
```

### Why Restaurant OS Uses TEXT Everywhere

**Decision:** Use `TEXT` for all string columns (no VARCHAR)

**Rationale:**
1. PostgreSQL treats TEXT and VARCHAR identically for storage/performance
2. TEXT has no length limit (no arbitrary VARCHAR(255) decisions)
3. Eliminates type mismatch errors between RPC and tables
4. Simpler mental model (one string type, not two)

**Exception:** Legacy columns in auth schema (Supabase managed)

---

## Timestamp Format Requirements

### Two Different Timestamp Issues

#### Issue 1: Migration Filename Timestamps

**WRONG (8 digits):**
```
supabase/migrations/20251019_add_feature.sql  ❌
```

**Why It Fails:**
```sql
-- Supabase schema_migrations table:
CREATE TABLE schema_migrations (
  version TEXT PRIMARY KEY  -- Must be unique!
);

-- Two migrations with same date = duplicate key error:
INSERT INTO schema_migrations VALUES ('20251019');  -- First succeeds
INSERT INTO schema_migrations VALUES ('20251019');  -- ERROR 23505: duplicate key
```

**CORRECT (14 digits):**
```
supabase/migrations/20251019143022_add_feature.sql  ✅
supabase/migrations/20251019143100_add_other.sql    ✅
```

**Generation:**
```bash
# Always use full timestamp with time component
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
echo "New migration: ${TIMESTAMP}_description.sql"
# Example output: 20251119143022_description.sql
```

#### Issue 2: Column Timestamp Types (TIMESTAMPTZ vs TIMESTAMP)

**Error Message:**
```
ERROR: 42804: Returned type timestamp without time zone does not match
expected type timestamp with time zone in column 32
```

**Root Cause:**
```sql
-- Table definition:
CREATE TABLE orders (
  check_closed_at TIMESTAMP  -- WITHOUT time zone
);

-- RPC function:
RETURNS TABLE (
  check_closed_at TIMESTAMPTZ  -- WITH time zone ❌
)
```

**The Fix:**
```sql
-- Query table schema first:
SELECT
  column_name,
  data_type,
  datetime_precision
FROM information_schema.columns
WHERE table_name = 'orders' AND column_name = 'check_closed_at';

-- Result: timestamp without time zone

-- Match RPC to table:
RETURNS TABLE (
  check_closed_at TIMESTAMP  -- WITHOUT time zone ✅
)
```

### Timestamp Type Decision Matrix

| Use Case | Type | Rationale |
|----------|------|-----------|
| Order timestamps (created_at, updated_at) | TIMESTAMPTZ | Cross-timezone ordering system |
| Scheduled events (auto_fire_time) | TIMESTAMPTZ | Restaurant may serve multiple timezones |
| Check closed (check_closed_at) | TIMESTAMP | Local restaurant time only |
| Migration versions | TEXT (YYYYMMDDHHmmss) | Unique identifier, not a date |

**Restaurant OS Standard:** Use TIMESTAMPTZ unless there's a specific reason for local time

---

## Idempotent Migration Patterns

### Why Idempotency Matters

**Scenario:** Migration partially deploys, then fails
- Without idempotency: Migration can't be re-run (error on 2nd attempt)
- With idempotency: Migration can be re-run safely

**Real Example from Oct 20 Reconciliation:**
```sql
-- NON-IDEMPOTENT (fails on re-run):
CREATE TABLE api_scopes (
  scope TEXT PRIMARY KEY
);
-- Second run: ERROR: relation "api_scopes" already exists

-- IDEMPOTENT (safe to re-run):
CREATE TABLE IF NOT EXISTS api_scopes (
  scope TEXT PRIMARY KEY
);
-- Second run: NOTICE: relation "api_scopes" already exists, skipping
```

### Idempotent Pattern Library

#### Pattern 1: CREATE TABLE
```sql
CREATE TABLE IF NOT EXISTS orders (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_number TEXT NOT NULL,
  created_at TIMESTAMPTZ DEFAULT now()
);
```

#### Pattern 2: ADD COLUMN
```sql
-- Check if column exists before adding
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'version'
  ) THEN
    ALTER TABLE orders ADD COLUMN version INTEGER DEFAULT 1;
  END IF;
END $$;

-- Or use simpler IF NOT EXISTS (PostgreSQL 9.6+):
ALTER TABLE orders ADD COLUMN IF NOT EXISTS version INTEGER DEFAULT 1;
```

#### Pattern 3: INSERT REFERENCE DATA
```sql
INSERT INTO api_scopes (scope, description) VALUES
  ('menu:read', 'View menu items'),
  ('orders:create', 'Create new orders')
ON CONFLICT (scope) DO NOTHING;  -- Key: ON CONFLICT DO NOTHING
```

#### Pattern 4: CREATE INDEX
```sql
CREATE INDEX IF NOT EXISTS idx_orders_restaurant_id
ON orders(restaurant_id);
```

#### Pattern 5: CREATE FUNCTION
```sql
-- Always use CREATE OR REPLACE for functions
CREATE OR REPLACE FUNCTION create_order_with_audit(...)
RETURNS TABLE (...) AS $$
BEGIN
  -- Function body
END;
$$ LANGUAGE plpgsql;

-- Or drop first if changing signature:
DROP FUNCTION IF EXISTS create_order_with_audit(UUID, TEXT, TEXT);
CREATE FUNCTION create_order_with_audit(...) ...
```

#### Pattern 6: UPDATE EXISTING DATA (Backfill)
```sql
-- Idempotent backfill pattern
UPDATE orders
SET version = 1
WHERE version IS NULL;  -- Key: WHERE clause prevents re-running on same rows

-- Count affected rows for validation
DO $$
DECLARE
  v_updated INTEGER;
BEGIN
  UPDATE orders SET version = 1 WHERE version IS NULL;
  GET DIAGNOSTICS v_updated = ROW_COUNT;
  RAISE NOTICE 'Backfilled % orders with version=1', v_updated;
END $$;
```

#### Pattern 7: DROP (Always Idempotent)
```sql
DROP TABLE IF EXISTS old_table;
DROP FUNCTION IF EXISTS old_function(...);
DROP INDEX IF EXISTS old_index;
```

### Complete Migration Template

```sql
-- Migration: [Description]
-- Date: YYYY-MM-DD
-- Related: Issue #XXX, ADR-XXX

-- Step 1: Create/modify table structure
CREATE TABLE IF NOT EXISTS new_table (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at TIMESTAMPTZ DEFAULT now()
);

-- Step 2: Add columns to existing tables
ALTER TABLE orders ADD COLUMN IF NOT EXISTS version INTEGER DEFAULT 1;

-- Step 3: Create indexes
CREATE INDEX IF NOT EXISTS idx_orders_version ON orders(version);

-- Step 4: Backfill existing data
UPDATE orders SET version = 1 WHERE version IS NULL;

-- Step 5: Create/update RPC functions
CREATE OR REPLACE FUNCTION get_order_stats(p_restaurant_id UUID)
RETURNS TABLE (...) AS $$
BEGIN
  -- Function body
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Step 6: Grant permissions
GRANT EXECUTE ON FUNCTION get_order_stats TO authenticated;

-- Step 7: Add comments for documentation
COMMENT ON COLUMN orders.version IS
'Optimistic locking version. Incremented on every update.';

-- Step 8: Notify PostgREST to reload schema (if using PostgREST)
NOTIFY pgrst, 'reload schema';

-- Step 9: Validation block
DO $$
BEGIN
  -- Check table exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_name = 'new_table'
  ) THEN
    RAISE EXCEPTION 'Migration failed: new_table not created';
  END IF;

  -- Check column exists
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'orders' AND column_name = 'version'
  ) THEN
    RAISE EXCEPTION 'Migration failed: version column not created';
  END IF;

  -- Check function exists
  IF NOT EXISTS (
    SELECT 1 FROM pg_proc p
    JOIN pg_namespace n ON p.pronamespace = n.oid
    WHERE n.nspname = 'public' AND p.proname = 'get_order_stats'
  ) THEN
    RAISE EXCEPTION 'Migration failed: get_order_stats function not created';
  END IF;

  RAISE NOTICE 'Migration successful: [feature description]';
END $$;
```

---

## Related Documentation

- **README.md** - Executive summary, quick diagnosis
- **INCIDENTS.md** - Real incident reports demonstrating these patterns
- **PREVENTION.md** - How to apply these patterns in practice
- **/docs/SUPABASE_CONNECTION_GUIDE.md** - Complete workflow guide
- **/supabase/migrations/.template.sql** - Starter template

---

**Maintained by:** Engineering Team
**Last Updated:** 2025-11-19

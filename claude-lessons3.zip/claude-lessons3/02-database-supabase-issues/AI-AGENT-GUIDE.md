---
category: "database-supabase"
category_id: "02"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, schema-drift, rpc-functions, prisma, migrations, remote-first]
---
# AI Agent Guide - Database Operations

**Last Updated:** 2025-11-19
**For:** Claude Code, GitHub Copilot, Cursor, and other AI coding assistants
**Critical:** These rules prevent $100K+ production incidents

---

## ABSOLUTE RULES (Never Break)

### Rule #1: NEVER Modify Prisma Schema Manually

```typescript
// ❌ ABSOLUTELY FORBIDDEN:
// File: prisma/schema.prisma

model Order {
  id String @id @default(uuid())
  version Int @default(1)  // ← DO NOT ADD THIS MANUALLY
}

// Then running: npx prisma db push
```

**Why This Breaks Production:**
- Prisma schema is GENERATED from remote database
- Manual edits create fiction, not reality
- Remote database is what production code executes against
- Next `npx prisma db pull` will overwrite your changes
- Code will reference columns that don't exist → 500 errors

**Correct Approach:**
1. Create SQL migration file
2. Deploy via `supabase db push --linked`
3. Run `npx prisma db pull` to update schema
4. Prisma schema now accurate

---

### Rule #2: Always Check RPC Functions After Table Changes

**Scenario:** User asks to add column to orders table

```
❌ WRONG WORKFLOW:
1. Create migration adding column to orders table
2. Deploy migration
3. Done ← MISSING STEP!

✅ CORRECT WORKFLOW:
1. Create migration adding column to orders table
2. Check if any RPC functions reference orders table
3. Update RPC functions to include new column
4. Deploy both migrations together
5. Verify RPC signature matches table schema
```

**How to Check:**
```bash
# Find all RPC functions that use orders table
grep -r "FROM orders" supabase/migrations/*.sql

# Common RPC functions in Restaurant OS:
# - create_order_with_audit
# - batch_update_tables
# - get_order_stats
```

**Real Incident:**
- Added `version` column to orders table (Oct 19)
- Forgot to update `create_order_with_audit` RPC
- RPC didn't return version → 500 errors
- 3 emergency hotfixes over 17 days

---

### Rule #3: Migration Timestamp Format: YYYYMMDDHHmmss (14 digits)

```bash
# ❌ WRONG (8 digits):
20251119_add_feature.sql

# ✅ CORRECT (14 digits):
20251119143022_add_feature.sql

# Generate correctly:
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
touch "supabase/migrations/${TIMESTAMP}_description.sql"
```

**Why This Matters:**
- Supabase stores version as PRIMARY KEY
- Multiple migrations with same timestamp = duplicate key error
- Production deployment fails
- 4 hours wasted on Oct 20 reconciling timestamp collisions

---

### Rule #4: Test Migration References Correct File Path

When user asks to test a migration:

```bash
# ❌ WRONG:
# User says: "Test the add_tax_rate migration"
# AI runs: psql "$DATABASE_URL" -f supabase/migrations/add_tax_rate.sql
# Error: File not found

# ✅ CORRECT:
# First find the exact filename:
ls supabase/migrations/*tax_rate*.sql
# Result: supabase/migrations/20251019180000_add_tax_rate_to_restaurants.sql

# Then run with full path:
psql "$DATABASE_URL" -f supabase/migrations/20251019180000_add_tax_rate_to_restaurants.sql
```

---

### Rule #5: Always Run post-migration-sync.sh After Migration

```bash
# ❌ INCOMPLETE:
supabase db push --linked
# Done ← Prisma schema not updated!

# ✅ COMPLETE:
supabase db push --linked
./scripts/post-migration-sync.sh
# Prisma schema now matches database
```

**What post-migration-sync.sh Does:**
1. Runs `npx prisma db pull` (introspect remote database)
2. Generates Prisma schema from actual database state
3. Fixes known Prisma bugs (@ignore attributes)
4. Shows git diff of schema changes
5. Generates TypeScript types

**Why It's Critical:**
- Without this, Prisma schema becomes stale
- TypeScript types don't match database
- Code completion suggests wrong fields
- Runtime errors: "column does not exist"

---

## Common Mistakes AI Agents Make

### Mistake #1: Editing Prisma Schema Instead of Creating Migration

**User Request:** "Add a version field to the orders model"

**Wrong Response:**
```
I'll add the version field to the Prisma schema:

[Shows edit to prisma/schema.prisma adding version field]

Then run: npx prisma db push
```

**Correct Response:**
```
I'll create a SQL migration to add the version field:

1. Creating migration file with unique timestamp
2. Writing SQL to add column with validation
3. Will deploy via supabase db push --linked
4. Then run post-migration-sync.sh to update Prisma schema

Here's the migration:

[Shows SQL migration file]

Important: This follows the remote-first pattern (ADR-010).
The Prisma schema will be GENERATED after deployment.
```

---

### Mistake #2: Not Checking RPC Function Dependencies

**User Request:** "Add seat_number column to orders table"

**Wrong Response:**
```sql
-- Migration: Add seat_number to orders
ALTER TABLE orders ADD COLUMN seat_number INTEGER;
```

**Correct Response:**
```
I need to check if any RPC functions reference the orders table:

[Searches for RPC functions]

Found: create_order_with_audit returns orders table columns

Since this RPC returns ALL columns from orders table, I need to:
1. Add seat_number column to orders table
2. Update create_order_with_audit to include seat_number in RETURNS TABLE
3. Update create_order_with_audit SELECT to include seat_number

Here are both migrations:

[Shows table migration + RPC update migration]
```

---

### Mistake #3: Using VARCHAR Instead of TEXT

**User Request:** "Create RPC function to create orders"

**Wrong Response:**
```sql
CREATE FUNCTION create_order_with_audit(
  p_order_number VARCHAR,  -- ❌ Wrong type
  p_type VARCHAR           -- ❌ Wrong type
)
RETURNS TABLE (
  order_number VARCHAR,    -- ❌ Wrong type
  type VARCHAR             -- ❌ Wrong type
)
```

**Correct Response:**
```
Let me first check the orders table schema:

[Runs: psql "$DATABASE_URL" -c "\d orders"]

I see that orders table uses TEXT for string columns, not VARCHAR.
This is important because PostgreSQL requires exact type matching
in RETURNS TABLE (VARCHAR ≠ TEXT in this context).

Here's the correct function:

CREATE FUNCTION create_order_with_audit(
  p_order_number TEXT,     -- ✅ Matches table
  p_type TEXT              -- ✅ Matches table
)
RETURNS TABLE (
  order_number TEXT,       -- ✅ Matches table
  type TEXT                -- ✅ Matches table
)
```

---

### Mistake #4: Not Validating Migration Deployed

**User Request:** "Deploy the tax_rate migration"

**Wrong Response:**
```bash
supabase db push --linked

# Response: "Migration deployed successfully"
```

**Correct Response:**
```bash
# Step 1: Deploy migration
supabase db push --linked

# Step 2: Verify it was actually deployed
supabase migration list --linked

# Step 3: Verify column exists in database
psql "$DATABASE_URL" -c "\d restaurants" | grep tax_rate

# Step 4: Update Prisma schema
./scripts/post-migration-sync.sh

# Result: Migration verified deployed, schema synced
```

---

### Mistake #5: Creating Non-Idempotent Migrations

**User Request:** "Create migration to add api_scopes table"

**Wrong Response:**
```sql
CREATE TABLE api_scopes (
  scope TEXT PRIMARY KEY
);
```

**Correct Response:**
```sql
-- Idempotent version (can be run multiple times safely)
CREATE TABLE IF NOT EXISTS api_scopes (
  scope TEXT PRIMARY KEY
);

-- Add data idempotently
INSERT INTO api_scopes (scope, description) VALUES
  ('menu:read', 'View menu items'),
  ('orders:create', 'Create orders')
ON CONFLICT (scope) DO NOTHING;

-- Validation block
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.tables
    WHERE table_name = 'api_scopes'
  ) THEN
    RAISE EXCEPTION 'Migration failed: api_scopes table not created';
  END IF;
  RAISE NOTICE 'Migration successful: api_scopes table created';
END $$;
```

---

## Migration Workflow Checklist (For AI Agents)

When user asks you to create a database migration:

```
☐ 1. Generate 14-digit timestamp
   TIMESTAMP=$(date +"%Y%m%d%H%M%S")

☐ 2. Create migration file from template
   cp supabase/migrations/.template.sql supabase/migrations/${TIMESTAMP}_description.sql

☐ 3. Write idempotent SQL
   - CREATE TABLE IF NOT EXISTS
   - ALTER TABLE ... ADD COLUMN IF NOT EXISTS
   - INSERT ... ON CONFLICT DO NOTHING
   - Include validation block

☐ 4. Check for RPC function dependencies
   grep -r "FROM table_name" supabase/migrations/*.sql

☐ 5. If RPC functions found, update them in SAME migration or create dependent migration

☐ 6. Verify types match table schema
   psql "$DATABASE_URL" -c "\d table_name"

☐ 7. Show user the complete migration(s)

☐ 8. Explain deployment steps:
   - supabase db push --linked
   - ./scripts/post-migration-sync.sh
   - Verification commands

☐ 9. Warn about production impact if this is high-risk change

☐ 10. Suggest monitoring commands for post-deployment
```

---

## RPC Function Rules (Critical)

### Rule: RETURNS TABLE Must Exactly Match Table Schema

**The Type Matching Rules:**
1. VARCHAR ≠ TEXT (must be exact)
2. TIMESTAMPTZ ≠ TIMESTAMP (must be exact)
3. INTEGER ≠ BIGINT (must be exact)
4. NUMERIC(10,2) ≠ DECIMAL (precision matters)

**How to Verify:**
```bash
# Step 1: Get table schema
psql "$DATABASE_URL" -c "\d orders"

# Step 2: For EACH column in RETURNS TABLE:
#   - Column name matches? ✓
#   - Type EXACTLY matches (not just "compatible")? ✓
#   - NOT NULL matches? ✓

# Step 3: Count columns
# RETURNS TABLE should have SAME number of columns as table
# (or explicitly select subset)
```

### Rule: RPC Functions Are Part of Schema

When you see:
```sql
ALTER TABLE orders ADD COLUMN version INTEGER;
```

You must think:
```
Does any RPC function return orders table data?
If yes → RPC function must be updated too
```

**Restaurant OS RPC Functions to Always Check:**
- `create_order_with_audit` - Returns orders table rows
- `batch_update_tables` - Updates tables, returns updated rows
- Any function with `RETURNS TABLE (...)` referencing app tables

---

## Database Pattern Recognition

### Pattern: Remote-First Architecture

```
User says: "The Prisma schema doesn't match the database"

✅ CORRECT RESPONSE:
"That's expected in remote-first architecture. Let me sync the Prisma schema
from the remote database using 'npx prisma db pull'."

❌ WRONG RESPONSE:
"Let me edit the Prisma schema to match."
```

### Pattern: Migration Bifurcation

```
User shows: supabase migration list --linked output with blank Remote column

✅ CORRECT RESPONSE:
"These local migrations haven't been deployed to production yet.
This is dangerous - production code may reference schema that doesn't exist.
We should deploy these migrations ASAP via 'supabase db push --linked'."

❌ WRONG RESPONSE:
"That's fine, migrations are just documentation."
```

### Pattern: RPC Evolution

```
User says: "I added a column to orders table last week"

✅ CORRECT RESPONSE:
"Let me check if create_order_with_audit RPC function needs updating.
RPC functions don't auto-update when tables change."

[Checks RPC function, finds it's missing new column]

"The RPC needs updating. Here's a migration to add the column to RETURNS TABLE."

❌ WRONG RESPONSE:
"Great! The column should work now."
```

---

## Error Message Interpretation

### When You See Error 42703

```
ERROR: 42703: column "tax_rate" does not exist
```

**AI Agent Response Should Be:**
```
This is error 42703 - column does not exist. This typically means:

1. Migration file exists but wasn't deployed to production, OR
2. Code was deployed before migration, OR
3. Migration failed silently

Let me check:

[Runs: supabase migration list --linked | grep tax_rate]

[Interprets result and provides specific fix]
```

### When You See Error 42804

```
ERROR: 42804: Returned type text does not match expected type character varying
```

**AI Agent Response Should Be:**
```
This is error 42804 - type mismatch in RPC function. The RPC function's
RETURNS TABLE uses VARCHAR but the actual table uses TEXT.

This is a Restaurant OS known issue - all string columns use TEXT.

Let me check the RPC function signature:

[Runs: psql "$DATABASE_URL" -c "\df+ function_name"]

I'll create a migration to fix the type mismatch:

[Shows corrected RPC function with TEXT instead of VARCHAR]
```

---

## Migration Templates (Copy-Paste Ready)

### Template: Add Column to Table

```sql
-- Migration: Add [column_name] to [table_name]
-- Date: [YYYY-MM-DD]
-- Related: Issue #XXX

ALTER TABLE [table_name]
ADD COLUMN IF NOT EXISTS [column_name] [TYPE] [DEFAULT];

COMMENT ON COLUMN [table_name].[column_name] IS
'[Description of what this column stores]';

-- Backfill existing data (if needed)
UPDATE [table_name]
SET [column_name] = [value]
WHERE [column_name] IS NULL;

-- Validation
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = '[table_name]'
    AND column_name = '[column_name]'
  ) THEN
    RAISE EXCEPTION 'Migration failed: [column_name] not created';
  END IF;
  RAISE NOTICE 'Migration successful: [column_name] added to [table_name]';
END $$;
```

### Template: Update RPC Function Return Type

```sql
-- Migration: Update [function_name] to include [column_name]
-- Date: [YYYY-MM-DD]
-- Related: Previous migration that added [column_name] to [table_name]

DROP FUNCTION IF EXISTS [function_name]([param_types]);

CREATE FUNCTION [function_name]([params])
RETURNS TABLE (
  -- Existing columns...
  [new_column_name] [TYPE]  -- ← Added
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN QUERY
  SELECT
    -- Existing columns...
    o.[new_column_name]  -- ← Added
  FROM [table_name] o
  WHERE [conditions];
END;
$$;

GRANT EXECUTE ON FUNCTION [function_name] TO authenticated;
NOTIFY pgrst, 'reload schema';

-- Validation
DO $$
DECLARE
  v_function_result TEXT;
BEGIN
  SELECT pg_get_function_result(oid) INTO v_function_result
  FROM pg_proc
  WHERE proname = '[function_name]'
  ORDER BY oid DESC LIMIT 1;

  IF v_function_result NOT LIKE '%[column_name]%' THEN
    RAISE EXCEPTION 'Migration failed: [column_name] not in RETURNS TABLE';
  END IF;

  RAISE NOTICE 'Migration successful: [function_name] updated';
END $$;
```

---

## Safety Checks (Run These Before Committing)

```bash
# Check 1: Migration has 14-digit timestamp
ls supabase/migrations/ | tail -1
# Should match: [0-9]{14}_*.sql

# Check 2: Migration is idempotent
grep -q "IF NOT EXISTS" supabase/migrations/[file]
# Should find at least one IF NOT EXISTS

# Check 3: Migration has validation block
grep -q "Migration successful" supabase/migrations/[file]
# Should find validation NOTICE

# Check 4: No RPC functions broken
# If table modified, check for RPC functions:
grep -r "FROM [table_name]" supabase/migrations/*.sql

# Check 5: Migration sync status
supabase migration list --linked
# All local migrations should have remote timestamps
```

---

## Communication Templates

### When Creating Migration

```
I'll create a SQL migration to [description]. This will:

1. [First change]
2. [Second change]
3. [etc]

Important notes:
- This follows the remote-first pattern (ADR-010)
- Prisma schema will be regenerated after deployment
- [Any RPC functions that need updating]
- [Any breaking changes or risks]

Deployment steps:
1. Review the migration SQL below
2. Run: supabase db push --linked
3. Run: ./scripts/post-migration-sync.sh
4. Verify: [specific verification command]

Here's the migration:

[Migration SQL]
```

### When Detecting Schema Drift

```
⚠️ SCHEMA DRIFT DETECTED

I found that:
- Local migration exists: [file]
- Remote database missing: [column/table]

This is the same pattern that caused the Oct 21 incidents (3 hours downtime, $45K lost revenue).

Recommended action:
1. Deploy missing migration immediately: supabase db push --linked
2. Verify deployment: supabase migration list --linked
3. Update Prisma schema: ./scripts/post-migration-sync.sh
4. Monitor production for 15 minutes

This should be done BEFORE any new code deployments.
```

### When User Asks to Edit Prisma Schema

```
❌ I cannot edit the Prisma schema manually.

Here's why:
- Restaurant OS uses remote-first architecture (ADR-010)
- Prisma schema is GENERATED from remote database via `npx prisma db pull`
- Manual edits will be overwritten on next sync
- This pattern caused $100K+ in production incidents (July-Oct 2025)

The correct approach:
1. Create SQL migration file
2. Deploy to remote database via `supabase db push --linked`
3. Regenerate Prisma schema via `npx prisma db pull`

Would you like me to create a migration instead?
```

---

## Red Flags (Stop and Ask)

If you encounter any of these, STOP and ask the user:

1. **User asks to edit prisma/schema.prisma manually**
   → "Should I create a SQL migration instead? (remote-first pattern)"

2. **Migration file has 8-digit timestamp**
   → "This should be 14 digits (YYYYMMDDHHmmss). Should I rename?"

3. **RPC function uses VARCHAR for string types**
   → "Restaurant OS uses TEXT for strings. Should I change to TEXT?"

4. **Table has new column but RPC function doesn't**
   → "RPC function may need updating. Should I check create_order_with_audit?"

5. **User says 'test this in production'**
   → "Should we test locally first? Production incidents cost $100K+"

6. **Multiple migrations with same timestamp base**
   → "These will cause duplicate key errors. Should I rename with unique timestamps?"

---

## Success Metrics

**AI Agent performing well when:**
- ✅ Always creates SQL migrations (never edits Prisma schema)
- ✅ Always checks RPC functions after table changes
- ✅ Always uses 14-digit timestamps
- ✅ Always includes validation blocks in migrations
- ✅ Always runs post-migration-sync.sh after deployment
- ✅ Catches schema drift before code deployment
- ✅ Suggests idempotent SQL patterns

**AI Agent needs improvement when:**
- ❌ Edits Prisma schema instead of creating migration
- ❌ Forgets to check RPC functions
- ❌ Uses 8-digit timestamps
- ❌ Creates non-idempotent migrations
- ❌ Doesn't validate migration deployed
- ❌ Doesn't warn about production risks

---

## Related Documentation

- **README.md** - Overview, metrics, quick diagnosis
- **PATTERNS.md** - Deep dive on remote-first architecture
- **INCIDENTS.md** - Real incidents to learn from
- **PREVENTION.md** - Step-by-step prevention guide
- **QUICK-REFERENCE.md** - Emergency commands

---

## Learning Resources

**For AI Agents to Reference:**

1. **ADR-010 Remote-First Database**
   `/Users/mikeyoung/CODING/rebuild-6.0/docs/ADR/ADR-010-remote-first-database.md`
   → Core architecture decision

2. **Post-Mortem: Schema Drift**
   `/Users/mikeyoung/CODING/rebuild-6.0/docs/POST_MORTEM_SCHEMA_DRIFT_2025-10-21.md`
   → 3 cascading incidents, $67.5K impact

3. **Migration Reconciliation**
   `/Users/mikeyoung/CODING/rebuild-6.0/docs/MIGRATION_RECONCILIATION_2025-10-20.md`
   → 97-day bifurcation, 6-hour resolution

4. **Supabase Connection Guide**
   `/Users/mikeyoung/CODING/rebuild-6.0/docs/SUPABASE_CONNECTION_GUIDE.md`
   → Complete workflow documentation

---

**Maintained by:** Engineering Team
**Last Updated:** 2025-11-19
**For AI Assistance:** This document encodes lessons from 24+ production incidents

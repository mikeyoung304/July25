---
category: "database-supabase"
category_id: "02"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "INCIDENTS"
incident_count: 5
total_cost: 100000
severity_distribution:
  P0: 3
  P1: 2
tags: [schema-drift, rpc-functions, prisma, migrations, remote-first]
---
# Major Database Incidents - Detailed Reports

**Last Updated:** 2025-11-19
**Total Documented Incidents:** 6 major + 18 minor = 24 total

---

## Table of Contents
1. [Schema Drift Cascade (Oct 21-22, 2025)](#schema-drift-cascade)
2. [Migration Bifurcation (July 13 - Oct 20, 2025)](#migration-bifurcation)
3. [RPC Function Evolution Failures](#rpc-function-evolution)
4. [Timestamp Type Mismatches](#timestamp-type-mismatches)
5. [Migration Timestamp Collisions](#migration-timestamp-collisions)

---

<a id="schema-drift-cascade"></a>
## Schema Drift Cascade (Oct 21-22, 2025)

### Overview
- **Classification:** P0 - Complete production outage
- **Total Duration:** 4.5 hours (3 cascading incidents)
- **Business Impact:** ~$67,500 in lost revenue
- **Root Cause:** Migrations committed to git but never deployed to production
- **Pattern:** All 3 incidents = RPC/code expects schema that doesn't exist

---

### Incident #1: Missing tax_rate Column

**Timeline:**
```
Oct 21 19:00  User tests ServerView on production Vercel
Oct 21 19:05  All order submissions fail with 403/500 errors
Oct 21 19:30  Investigation discovers schema drift
Oct 21 20:00  Emergency migration deployment via psql
Oct 21 21:00  Import path errors fixed, code redeployed
Oct 21 22:00  Incident resolved, production functional
```

**Duration:** 3 hours
**Impact:** $45,000 estimated lost revenue (peak dinner service)

#### Error Messages
```
PostgreSQL Error:
ERROR: 42703: column "tax_rate" does not exist
LINE 42: SELECT tax_rate FROM restaurants WHERE id = $1
```

```
API Response:
{
  "error": "Internal server error",
  "message": "Database query failed",
  "code": 500
}
```

#### Root Cause Analysis

**What Happened:**
1. **Oct 19:** Developer created migration `20251019180000_add_tax_rate_to_restaurants.sql`
2. Developer committed migration to git
3. Developer pushed to GitHub
4. **MISSING STEP:** Never ran `supabase db push --linked` to deploy to production
5. **Oct 21:** Code deployed expecting `tax_rate` column
6. Production database didn't have column → 500 errors

**Why It Happened:**
- Conflicting documentation: Old guide said migrations "reference only"
- No deployment checklist enforcing migration deployment
- No CI/CD step to deploy migrations automatically
- Developer tested locally (where migration was applied) but not production

#### The Missing Migration

```sql
-- File: supabase/migrations/20251019180000_add_tax_rate_to_restaurants.sql
-- Status: Committed to git Oct 19, deployed to production Oct 21 (48 hour lag)

ALTER TABLE restaurants
ADD COLUMN IF NOT EXISTS tax_rate NUMERIC(4,4) DEFAULT 0.0825;

COMMENT ON COLUMN restaurants.tax_rate IS
'Sales tax rate for this restaurant (e.g. 0.0825 = 8.25%)';

-- Validation
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'restaurants' AND column_name = 'tax_rate'
  ) THEN
    RAISE EXCEPTION 'Migration failed: tax_rate column not created';
  END IF;
  RAISE NOTICE 'Migration successful: tax_rate column added';
END $$;
```

#### Code That Failed

```typescript
// server/src/services/orders.service.ts:84
const restaurant = await this.prisma.restaurants.findUnique({
  where: { id: restaurantId },
  select: { tax_rate: true }  // ← Column doesn't exist in production!
});

const taxRate = restaurant?.tax_rate ?? 0.08;  // Fallback never reached
```

**Why Fallback Didn't Help:**
- Query fails BEFORE reaching fallback logic
- PostgreSQL returns error 42703
- Express error handler catches, returns 500 to client

#### Resolution Steps

```bash
# Step 1: Deploy migration directly via psql
PGPASSWORD="$SUPABASE_DB_PASSWORD" psql \
  "postgresql://postgres@db.xiwfhcikfdoshxwbtjxt.supabase.co:5432/postgres" \
  -f supabase/migrations/20251019180000_add_tax_rate_to_restaurants.sql

# Output:
# ALTER TABLE
# COMMENT
# DO
# NOTICE: Migration successful: tax_rate column added

# Step 2: Verify schema updated
psql [...] -c "SELECT tax_rate FROM restaurants LIMIT 1;"
# Result: 0.0825 (default applied)

# Step 3: Fix code import paths (unrelated but discovered)
# Fixed: client/src/modules/supabase import
# Fixed: client/src/contexts/useRestaurant import

# Step 4: Deploy code fixes
git add -A && git commit -m "fix(p0): resolve schema drift..."
git push origin main

# Step 5: Verify production
curl -X POST https://api.rebuild6.com/api/v1/orders \
  -H "Content-Type: application/json" \
  -d '{"restaurant_id":"...","items":[...]}'
# Result: 200 OK, order created successfully
```

#### Lessons Learned

1. **Migration deployment is NOT automatic** - Committing to git ≠ deployed to production
2. **Test on production-like environment** - Local dev uses different database
3. **Deployment checklist needed** - Verify migrations deployed before code deploy
4. **CI/CD gap** - Should automate migration deployment

---

### Incident #2: Missing created_at in order_status_history

**Timeline:**
```
Oct 21 23:00  User reports voice orders failing in production
Oct 21 23:05  Check Render logs: 500 errors on POST /api/v1/orders
Oct 21 23:10  Error analysis: "column created_at does not exist"
Oct 21 23:19  Create + deploy hotfix migration
Oct 21 23:20  Production testing: voice orders functional
Oct 21 23:30  Incident resolved
```

**Duration:** 30 minutes (learned from Incident #1)
**Impact:** $15,000 estimated lost revenue

#### Error Messages

```
PostgreSQL Error:
ERROR: 42703: column "created_at" of relation "order_status_history" does not exist
LINE 8: INSERT INTO order_status_history (order_id, restaurant_id, from_status, to_status, notes, created_at)
                                                                                                   ^
```

```
Render Production Logs:
2025-10-21T23:02:15.847Z [ERROR] POST /api/v1/orders
  Error: Database error: column "created_at" does not exist
  Stack: at create_order_with_audit (RPC function)
  Code: 42703
```

#### Root Cause Analysis

**What Happened:**
1. **Oct 19:** RPC function `create_order_with_audit` created with INSERT statement:
   ```sql
   INSERT INTO order_status_history (
     order_id, restaurant_id, from_status, to_status, notes, created_at
   ) VALUES (
     v_order_id, p_restaurant_id, NULL, p_status, 'Order created', v_created_at
   );
   ```
2. RPC migration deployed successfully
3. **MISSING:** No migration to ADD `created_at` column to `order_status_history` table
4. Table structure:
   ```sql
   CREATE TABLE order_status_history (
     id UUID PRIMARY KEY,
     order_id UUID NOT NULL,
     restaurant_id UUID NOT NULL,
     from_status TEXT,
     to_status TEXT NOT NULL,
     notes TEXT
     -- created_at column MISSING!
   );
   ```
5. Voice orders call RPC → RPC tries to INSERT into non-existent column → 500 error

**Why It Happened:**
- RPC function migration didn't validate table schema
- Assumption: `created_at` was added in earlier migration (it wasn't)
- No automated check for RPC INSERT column dependencies

#### The Hotfix Migration

```sql
-- File: supabase/migrations/20251021231910_add_created_at_to_order_status_history.sql
-- Created: Oct 21, 23:19 (10 minutes after discovery)
-- Deployed: Oct 21, 23:19 (immediately via psql)

-- Add created_at column
ALTER TABLE order_status_history
ADD COLUMN IF NOT EXISTS created_at TIMESTAMPTZ DEFAULT now();

-- Add comment
COMMENT ON COLUMN order_status_history.created_at IS
'Timestamp when this status change was recorded.';

-- Backfill existing records
UPDATE order_status_history
SET created_at = now()
WHERE created_at IS NULL;

-- Notify PostgREST to reload schema
NOTIFY pgrst, 'reload schema';

-- Validation
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'order_status_history'
    AND column_name = 'created_at'
  ) THEN
    RAISE EXCEPTION 'Migration failed: created_at column not created';
  END IF;
  RAISE NOTICE 'Migration successful: created_at column added';
END $$;
```

#### Resolution

```bash
# Deployed same way as Incident #1 (psql direct)
PGPASSWORD="$SUPABASE_DB_PASSWORD" psql \
  "postgresql://postgres@db.xiwfhcikfdoshxwbtjxt.supabase.co:5432/postgres" \
  -f supabase/migrations/20251021231910_add_created_at_to_order_status_history.sql

# Verified RPC function now works
psql [...] -c "SELECT * FROM create_order_with_audit(...);"
# Result: Order created successfully with audit log

# Committed migration to git
git add supabase/migrations/20251021231910_add_created_at_to_order_status_history.sql
git commit -m "fix(schema): resolve order_status_history schema drift"
git push origin main
```

#### Lessons Learned (Enhanced from Incident #1)

1. **RPC validation needed** - Before deploying RPC, check ALL referenced columns exist
2. **Migration dependency order** - Table columns MUST be deployed BEFORE RPC functions using them
3. **Faster incident response** - 30 min vs 3 hours (learned the pattern)
4. **Same root cause** - Code/RPC expects schema that doesn't exist

---

### Incident #3: VARCHAR vs TEXT Type Mismatch

**Timeline:**
```
Oct 22 03:00  All order creation failing (online, voice, server)
Oct 22 03:05  Check logs: PostgreSQL type mismatch error
Oct 22 03:10  Identify RPC function uses VARCHAR, table uses TEXT
Oct 22 03:20  Create + deploy type fix migration
Oct 22 03:30  Incident resolved
```

**Duration:** 30 minutes
**Impact:** $7,500 estimated lost revenue

#### Error Messages

```
PostgreSQL Error:
ERROR: 42804: Returned type text does not match expected type character varying in column 3
DETAIL: Type text does not match character varying.
CONTEXT: PL/pgSQL function create_order_with_audit(...) line 28 at RETURN QUERY
```

**Error Code Breakdown:**
- `42804` = datatype mismatch
- Column 3 = `order_number` in RETURNS TABLE
- RPC declared: `order_number VARCHAR`
- Table has: `order_number TEXT`

#### Root Cause Analysis

**Why VARCHAR ≠ TEXT in this context:**

PostgreSQL treats VARCHAR and TEXT identically for storage, BUT:
- In `RETURNS TABLE`, return type must EXACTLY match table column type
- No automatic casting between VARCHAR and TEXT in this context
- Type mismatch = function execution failure

**How It Happened:**
1. Original RPC used VARCHAR for string columns (common PostgreSQL practice)
2. `orders` table created with TEXT columns (Supabase default)
3. No one noticed until RPC function executed
4. RETURN QUERY tried to return TEXT as VARCHAR → error

#### The Type Fix Migration

```sql
-- File: supabase/migrations/20251022033200_fix_rpc_type_mismatch.sql

DROP FUNCTION IF EXISTS create_order_with_audit(...);

CREATE FUNCTION create_order_with_audit(
  p_restaurant_id UUID,
  p_order_number TEXT,      -- ✅ Changed from VARCHAR
  p_type TEXT,               -- ✅ Changed from VARCHAR
  p_status TEXT DEFAULT 'pending',
  -- ... other params
)
RETURNS TABLE (
  id UUID,
  restaurant_id UUID,
  order_number TEXT,         -- ✅ Changed from VARCHAR
  type TEXT,                 -- ✅ Changed from VARCHAR
  status TEXT,               -- ✅ Changed from VARCHAR
  -- ... other columns
)
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  -- Function body unchanged
  RETURN QUERY SELECT ... FROM orders WHERE id = v_order_id;
END;
$$;

-- Validation checks for TEXT (not VARCHAR)
DO $$
DECLARE
  v_function_result TEXT;
BEGIN
  SELECT pg_get_function_result(oid) INTO v_function_result
  FROM pg_proc WHERE proname = 'create_order_with_audit';

  IF v_function_result LIKE '%character varying%' THEN
    RAISE EXCEPTION 'Migration failed: Function still uses VARCHAR';
  END IF;

  RAISE NOTICE 'Migration successful: RPC function uses TEXT types';
END $$;
```

#### All Columns Changed (VARCHAR → TEXT)

| Column | Old Type | New Type | Reason |
|--------|----------|----------|--------|
| order_number | VARCHAR | TEXT | Match orders.order_number |
| type | VARCHAR | TEXT | Match orders.type |
| status | VARCHAR | TEXT | Match orders.status |
| customer_name | VARCHAR | TEXT | Match orders.customer_name |
| table_number | VARCHAR | TEXT | Match orders.table_number |
| payment_status | VARCHAR | TEXT | Match orders.payment_status (added later) |
| payment_method | VARCHAR | TEXT | Match orders.payment_method (added later) |
| payment_id | VARCHAR | TEXT | Match orders.payment_id (added later) |

#### Resolution

```bash
# Same deployment pattern as previous incidents
PGPASSWORD="$SUPABASE_DB_PASSWORD" psql \
  "postgresql://postgres@db.xiwfhcikfdoshxwbtjxt.supabase.co:5432/postgres" \
  -f supabase/migrations/20251022033200_fix_rpc_type_mismatch.sql

# Test all order flows
curl -X POST .../orders -d '...'  # Online orders ✓
# Voice orders via WebRTC ✓
# Server orders via API ✓

# All flows functional
```

#### Lessons Learned

1. **Type exactness matters** - VARCHAR ≠ TEXT in RETURNS TABLE context
2. **Verify types before deployment** - Check `\d table_name` output
3. **Use TEXT consistently** - Restaurant OS standard: TEXT for all strings
4. **3rd incident same day** - Urgency of comprehensive prevention measures

---

<a id="migration-bifurcation"></a>
## Migration Bifurcation (July 13 - Oct 20, 2025)

### Overview
- **Classification:** P1 - Deployment blocking (no active outage)
- **Duration:** 97 days diverged state, 16 days blocked deployment, 6 hours to reconcile
- **Business Impact:** P0 audit fixes delayed 16 days
- **Root Cause:** Remote migrations never pulled locally, local migrations never deployed

---

### The Fork in the Road (July 13, 2025)

**Decision Point:**
```sql
-- File: supabase/migrations/20250713130722_remote_schema.sql
-- Content: Empty (placeholder migration)

-- This migration marks transition to "cloud-first" workflow
-- From this point: Schema changes via Supabase Dashboard UI
```

**What Should Have Happened:**
1. Make schema changes in Supabase Dashboard
2. Run `supabase db pull` to get migration SQL
3. Commit migrations to git
4. Deploy to other environments

**What Actually Happened:**
1. Made schema changes in Supabase Dashboard (11 migrations)
2. Never ran `supabase db pull`
3. Never committed to git
4. Meanwhile, created local migrations (10) never deployed

**Result: Parallel Timelines**

```
July 13: Reset Point (20250713130722_remote_schema.sql)
         │
         ├── TIMELINE A: Remote Database (Production)
         │   ├── 20250730094240 (Dashboard)
         │   ├── 20250730094405 (Dashboard)
         │   ├── 20250730121121 (Dashboard)
         │   ├── ... 8 more Dashboard migrations
         │   └── [Used by production for 97 days]
         │
         └── TIMELINE B: Local Git Repository
             ├── 20250130_auth_tables (never deployed)
             ├── 20250201_payment_audit_logs (never deployed)
             ├── 20251013_emergency_kiosk_demo_scopes (never deployed)
             ├── ... 7 more local migrations
             └── [Committed but never reached production]
```

---

### Discovery (Oct 20, 2025)

**Trigger:** Investigating ORDER_FAILURE_INCIDENT_REPORT.md

**Initial Symptom:**
```sql
SELECT tax_rate FROM restaurants WHERE id = '...';
-- ERROR: 42703: column "tax_rate" does not exist
```

**Initial Assumption (WRONG):**
> "The migration file must be buggy or have syntax errors."

**Investigation Led To:**

```bash
$ ls supabase/migrations/ | grep tax_rate
20251019_add_tax_rate_to_restaurants.sql  # ✓ File exists

$ supabase migration list --linked
   Local          | Remote         | Time (UTC)
  ----------------|----------------|---------------------
   20250713130722 | 20250713130722 | 2025-07-13 13:07:22
   20250130       |                |  ← LOCAL ONLY
   20250201       |                |  ← LOCAL ONLY
                  | 20250730094240 |  ← REMOTE ONLY
                  | 20250730094405 |  ← REMOTE ONLY
                  | ... (9 more remote-only)
   20251013       |                |  ← LOCAL ONLY
   20251014       |                |  ← LOCAL ONLY
   ... (6 more local-only October migrations)
```

**Realization:**
> "We have TWO migration histories that diverged 97 days ago."

---

### Reconciliation Strategy (16 Days to Execute)

#### Phase 1: Understand What Exists (Oct 20, Day 1)

```bash
# Remote migrations (in production, not in git):
20250730094240 - Unknown (Dashboard UI, no documentation)
20250730094405 - Unknown (Dashboard UI, no documentation)
... 9 more unknown remote migrations

# Local migrations (in git, not in production):
20250130_auth_tables.sql - Auth tables (user_pins, api_scopes, role_scopes)
20250201_payment_audit_logs.sql - Payment audit logging
... 8 more October P0 audit migrations
```

**Challenge:** How to merge without destroying either timeline?

#### Phase 2: Archive Conflicting Local Migrations (Oct 20, Day 1)

**Decision:** Remote migrations are superior (already battle-tested in production)

```bash
$ mkdir -p supabase/migrations/.archive

# Archive superseded auth migration
$ mv supabase/migrations/20250130_auth_tables.sql \
     supabase/migrations/.archive/

# Archive optional payment audit feature
$ mv supabase/migrations/20250201_payment_audit_logs.sql \
     supabase/migrations/.archive/

# Document why archived
$ cat supabase/migrations/.archive/README.md
```

**Archive Documentation:**
```markdown
## 20250130_auth_tables.sql
Status: SUPERSEDED by remote Sept 4 auth migrations
Remote equivalent: 20250904121523 through 20250904121834
Why archived: Remote has superior implementation with:
- Composite unique constraint (user_id, restaurant_id)
- is_member_of_restaurant() RLS function
- More mature auth system

## 20250201_payment_audit_logs.sql
Status: OPTIONAL FEATURE, not deployed
Why archived: Feature not used in production
Can restore: Yes, if payment audit logging needed
```

#### Phase 3: Mark Remote Migrations as "Handled" (Oct 20, Day 2-3)

**Problem:** Supabase requires all migrations in `schema_migrations` to exist as local files

**Solution:** Mark remote migrations as "reverted" (tells Supabase to ignore)

```bash
$ supabase migration repair --status reverted 20250730094240
$ supabase migration repair --status reverted 20250730094405
$ supabase migration repair --status reverted 20250730121121
... (repeat for all 11 remote migrations)

# Verify
$ supabase migration list --linked
# Remote-only migrations should now be gone from the list
```

#### Phase 4: Fix Schema Compatibility (Oct 20, Day 4-7)

**Problem:** Local migrations expect different schema than what's in production

**Example:**
```sql
-- Local migration expects:
INSERT INTO api_scopes (scope_name, description) VALUES (...)

-- Remote schema has:
api_scopes (
  scope TEXT PRIMARY KEY,  -- Not "scope_name"
  description TEXT
)
```

**Fix:** Update local migrations to match remote schema

```sql
-- File: 20251013_emergency_kiosk_demo_scopes.sql
-- BEFORE:
INSERT INTO api_scopes (scope_name, description) VALUES (...)

-- AFTER:
INSERT INTO api_scopes (scope, description) VALUES (...)
```

**Other Schema Differences Found:**
- `api_scopes.scope` (not `scope_name`)
- `user_pins` composite unique on `(user_id, restaurant_id)` (not just `user_id`)
- `role_scopes` table structure more complex than local expected

#### Phase 5: Timestamp Collision Resolution (Oct 20, Day 8-12)

**Problem:** 4 October migrations used same timestamp

```
20251019_add_tax_rate_to_restaurants.sql
20251019_add_create_order_with_audit_rpc.sql
20251019_add_version_to_orders.sql
20251019_add_batch_update_tables_rpc.sql
```

**Why This Fails:**
```sql
-- schema_migrations table:
CREATE TABLE schema_migrations (
  version TEXT PRIMARY KEY  -- Must be unique!
);

-- All 4 migrations try to insert '20251019' → duplicate key error
```

**Fix:** Rename with unique 14-digit timestamps

```bash
# Use git log to find actual creation times
$ git log --format="%H %aI" --name-only | grep 20251019

# Rename based on actual creation times
$ mv 20251019_add_tax_rate_to_restaurants.sql \
     20251019180000_add_tax_rate_to_restaurants.sql  # 6:00 PM

$ mv 20251019_add_create_order_with_audit_rpc.sql \
     20251019180800_add_create_order_with_audit_rpc.sql  # 6:08 PM

$ mv 20251019_add_version_to_orders.sql \
     20251019183600_add_version_to_orders.sql  # 6:36 PM

$ mv 20251019_add_batch_update_tables_rpc.sql \
     20251019202700_add_batch_update_tables_rpc.sql  # 8:27 PM
```

#### Phase 6: Deployment (Oct 20, Day 13-16)

```bash
# Pre-deployment check
$ supabase migration list --linked
   Local          | Remote         | Time (UTC)
  ----------------|----------------|---------------------
   20250713130722 | 20250713130722 | 2025-07-13 13:07:22
   20251013       |                | ← Ready to deploy
   20251014       |                | ← Ready to deploy
   20251015       |                | ← Ready to deploy
   20251018       |                | ← Ready to deploy
   20251019180000 |                | ← Ready to deploy
   20251019180800 |                | ← Ready to deploy
   20251019183600 |                | ← Ready to deploy
   20251019202700 |                | ← Ready to deploy

# Deploy all October migrations
$ echo "Y" | supabase db push --linked

Applying migration 20251013...
NOTICE: Migration successful

Applying migration 20251014...
NOTICE: Migration successful

... (all 8 October migrations deployed)

Finished supabase db push.

# Verify alignment
$ supabase migration list --linked
   Local          | Remote         | Time (UTC)
  ----------------|----------------|---------------------
   20250713130722 | 20250713130722 | 2025-07-13 13:07:22
   20251013       | 20251013       | 2025-10-13 00:00:00 ✓
   20251014       | 20251014       | 2025-10-14 00:00:00 ✓
   ... (all aligned)
```

---

### Lessons Learned from Bifurcation

1. **Remote database is reality** - Git is documentation, database is truth
2. **`supabase db pull` is mandatory** - After ANY Dashboard change
3. **Migration list check** - Should be in deployment checklist
4. **Document workflow transitions** - "Cloud-first" decision was never documented
5. **97 days is too long** - Should have detected within days, not months

---

<a id="rpc-function-evolution"></a>
## RPC Function Evolution Failures

### create_order_with_audit: 6 Fixes in 17 Days

#### Failure #1: Missing version Column (Oct 20)
**File:** 20251020221553_fix_create_order_with_audit_version.sql
**Error:** Orders returned without `version` field
**Impact:** Optimistic locking broken, concurrent updates not detected
**Fix:** Added `version INTEGER` to RETURNS TABLE and SELECT

#### Failure #2: Still VARCHAR Types (Oct 22)
**File:** 20251022033200_fix_rpc_type_mismatch.sql
**Error:** 42804 - VARCHAR vs TEXT mismatch
**Impact:** ALL order creation failing
**Fix:** Changed all VARCHAR → TEXT in RETURNS TABLE

#### Failure #3: Missing seat_number (Oct 29)
**File:** 20251029150000_add_seat_number_to_create_order_rpc.sql
**Error:** Dine-in orders failed validation (missing seat_number)
**Impact:** Server orders failing
**Fix:** Added seat_number parameter and return column

#### Failure #4: Missing payment_* Fields (Oct 30)
**File:** 20251030010000_add_payment_fields_to_create_order_rpc.sql
**Error:** Online checkout orders missing payment fields
**Impact:** Payment audit logs incomplete
**Fix:** Added payment_status, payment_method, payment_amount, etc.

#### Failure #5: Consolidated Type Fix Attempt (Oct 30)
**File:** 20251030020000_fix_rpc_type_mismatch.sql
**Error:** Still had TIMESTAMPTZ vs TIMESTAMP mismatch
**Impact:** Orders with closed checks failing
**Fix:** Consolidated all TEXT fixes (incomplete)

#### Failure #6: check_closed_at Type (Nov 5)
**File:** 20251105003000_fix_check_closed_at_type.sql
**Error:** 42804 - TIMESTAMPTZ vs TIMESTAMP in column 32
**Impact:** Closed check orders failing
**Fix:** Changed check_closed_at from TIMESTAMPTZ → TIMESTAMP

### Pattern Analysis

**Every failure followed this pattern:**
1. Table schema changed (new column added)
2. RPC function not updated
3. Production code calls RPC → 500 error
4. Emergency hotfix migration

**Prevention:** RPC functions should be co-located with table changes in SAME migration

---

<a id="timestamp-type-mismatches"></a>
## Timestamp Type Mismatches

### Incident: check_closed_at Type Error (Nov 5, 2025)

**Error:**
```
ERROR: 42804: Returned type timestamp without time zone does not match
expected type timestamp with time zone in column 32
```

**Root Cause:**
```sql
-- Table definition:
CREATE TABLE orders (
  check_closed_at TIMESTAMP  -- WITHOUT time zone
);

-- RPC function:
RETURNS TABLE (
  check_closed_at TIMESTAMPTZ  -- WITH time zone
)
```

**Why It Matters:**
- TIMESTAMP = local time (no timezone info)
- TIMESTAMPTZ = UTC time with timezone conversion
- PostgreSQL treats them as incompatible types in RETURNS TABLE

**Fix:**
```sql
RETURNS TABLE (
  check_closed_at TIMESTAMP  -- Match table type exactly
)
```

### Prevention Rule

**Before deploying RPC function:**
```bash
# Check EVERY timestamp column type
psql "$DATABASE_URL" -c "
SELECT
  column_name,
  data_type,
  datetime_precision
FROM information_schema.columns
WHERE table_name = 'orders'
AND data_type LIKE '%timestamp%';
"

# Verify RPC RETURNS TABLE matches exactly
```

---

<a id="migration-timestamp-collisions"></a>
## Migration Timestamp Collisions

### Incident: Duplicate Key Error (Oct 20, 2025)

**Error:**
```
ERROR: 23505: duplicate key value violates unique constraint "schema_migrations_pkey"
DETAIL: Key (version)=(20251019) already exists.
```

**Root Cause:**
4 migrations used same 8-digit date stamp:
- `20251019_add_tax_rate_to_restaurants.sql`
- `20251019_add_create_order_with_audit_rpc.sql`
- `20251019_add_version_to_orders.sql`
- `20251019_add_batch_update_tables_rpc.sql`

**Why This Fails:**
```sql
-- schema_migrations table structure:
CREATE TABLE schema_migrations (
  version TEXT PRIMARY KEY,  -- Must be unique!
  statements TEXT[],
  name TEXT
);

-- First migration:
INSERT INTO schema_migrations (version) VALUES ('20251019');  -- OK

-- Second migration:
INSERT INTO schema_migrations (version) VALUES ('20251019');  -- ERROR!
```

### The Fix Process

```bash
# Step 1: Find actual creation times from git
$ git log --format="%H %aI %s" --name-only | grep 20251019
302cb9a 2025-10-21T22:11:44-04:00 fix(p0): resolve schema drift...
  supabase/migrations/20251019_add_tax_rate_to_restaurants.sql
44d1f48 2025-10-21T20:00:00-04:00 ...
  supabase/migrations/20251019_add_create_order_with_audit_rpc.sql
... (other commits)

# Step 2: Rename with unique 14-digit timestamps
$ mv 20251019_add_tax_rate_to_restaurants.sql \
     20251019180000_add_tax_rate_to_restaurants.sql

$ mv 20251019_add_create_order_with_audit_rpc.sql \
     20251019180800_add_create_order_with_audit_rpc.sql

$ mv 20251019_add_version_to_orders.sql \
     20251019183600_add_version_to_orders.sql

$ mv 20251019_add_batch_update_tables_rpc.sql \
     20251019202700_add_batch_update_tables_rpc.sql

# Step 3: Mark old timestamp as reverted
$ supabase migration repair --status reverted 20251019

# Step 4: Deploy migrations with unique timestamps
$ supabase db push --linked
# All 4 migrations now deploy successfully
```

### Prevention

**Always use 14-digit timestamps:**
```bash
# WRONG (8 digits):
TIMESTAMP=$(date +"%Y%m%d")
echo $TIMESTAMP  # 20251119

# CORRECT (14 digits):
TIMESTAMP=$(date +"%Y%m%d%H%M%S")
echo $TIMESTAMP  # 20251119143022
```

**Add to pre-commit hook:**
```bash
# Check for 8-digit migration timestamps
if ls supabase/migrations/*[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]_*.sql 2>/dev/null; then
  echo "ERROR: Migration timestamp must be 14 digits (YYYYMMDDHHmmss)"
  exit 1
fi
```

---

## Summary of All Major Incidents

| Date | Incident | Duration | Impact | Error Code | Root Cause |
|------|----------|----------|--------|------------|------------|
| Oct 21 19:00 | Missing tax_rate | 3 hrs | $45K | 42703 | Migration not deployed |
| Oct 21 23:00 | Missing created_at | 30 min | $15K | 42703 | RPC INSERT missing column |
| Oct 22 03:00 | VARCHAR vs TEXT | 30 min | $7.5K | 42804 | RPC type mismatch |
| Oct 20 | Migration bifurcation | 16 days | Blocked P0 fixes | N/A | Remote/local divergence |
| Oct 20-Nov 5 | RPC evolution | 17 days | 6 hotfixes | 42804, 42703 | Table schema changes |
| Oct 20 | Timestamp collision | Blocked deploy | Delayed 4 hours | 23505 | Non-unique versions |

**Total Business Impact:** $100,000+ (lost revenue + engineering time + customer trust)

---

## Related Documentation

- **README.md** - Executive summary and quick diagnosis
- **PREVENTION.md** - How to prevent these incidents
- **PATTERNS.md** - Deep dive on technical patterns
- **QUICK-REFERENCE.md** - Emergency response commands

---

**Maintained by:** Engineering Team
**Last Updated:** 2025-11-19
**Review:** After each new incident (to add lessons learned)

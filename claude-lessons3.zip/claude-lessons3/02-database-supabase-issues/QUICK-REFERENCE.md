---
category: "database-supabase"
category_id: "02"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, schema-drift, rpc-functions, prisma, migrations, remote-first]
---
# Quick Reference - Emergency Database Commands

**Last Updated:** 2025-11-19
**Use When:** Production is down RIGHT NOW

---

## Emergency Triage (First 60 Seconds)

### Check Production Logs

```bash
# Render logs (backend)
https://dashboard.render.com/web/[service-id]/logs

# Vercel logs (frontend)
https://vercel.com/[project]/deployments/[deployment-id]

# Look for these error codes:
# 42703 - column does not exist → Missing migration
# 42804 - type mismatch → RPC function wrong types
# 42P01 - relation does not exist → Table migration not deployed
# 23505 - duplicate key → Data integrity or migration timestamp collision
```

### Quick Diagnosis Commands

```bash
# 1. Check migration sync status (30 seconds)
supabase migration list --linked

# Output interpretation:
# Local | Remote | Time → GOOD: Both columns filled
# 20251119 |        | → BAD: Migration not deployed
#          | 20251119 | → BAD: Unknown remote migration

# 2. Check recent migrations (30 seconds)
supabase migration list --linked | tail -5

# 3. Check database connection (10 seconds)
psql "$DATABASE_URL" -c "SELECT 1;"

# Expected:
#  ?column?
# ----------
#         1
```

---

## Error Code Playbooks

### 42703: Column Does Not Exist

**Example Error:**
```
ERROR: 42703: column "tax_rate" of relation "restaurants" does not exist
```

**Diagnosis:**
```bash
# Check if migration file exists
ls supabase/migrations/*tax_rate*.sql

# Check if deployed to remote
supabase migration list --linked | grep tax_rate
```

**Quick Fix (5 minutes):**
```bash
# Option A: Deploy existing migration
supabase db push --linked

# Option B: Deploy via psql directly (faster)
PGPASSWORD="$SUPABASE_DB_PASSWORD" psql \
  "postgresql://postgres@db.xiwfhcikfdoshxwbtjxt.supabase.co:5432/postgres" \
  -f supabase/migrations/[TIMESTAMP]_add_tax_rate.sql

# Verify
psql "$DATABASE_URL" -c "\d restaurants" | grep tax_rate
```

**Real Incident:** Oct 21, 19:00 - 3 hours (see INCIDENTS.md)

---

### 42804: Type Mismatch

**Example Error:**
```
ERROR: 42804: Returned type text does not match expected type character varying in column 3
```

**Diagnosis:**
```bash
# Get table schema
psql "$DATABASE_URL" -c "\d orders"

# Get RPC function signature
psql "$DATABASE_URL" -c "\df+ create_order_with_audit"

# Look for mismatches:
# - VARCHAR vs TEXT
# - TIMESTAMPTZ vs TIMESTAMP
# - INTEGER vs BIGINT
```

**Quick Fix (10 minutes):**
```sql
-- Create hotfix migration
cat > "supabase/migrations/$(date +%Y%m%d%H%M%S)_fix_rpc_types.sql" << 'EOF'
DROP FUNCTION IF EXISTS create_order_with_audit(...);

CREATE FUNCTION create_order_with_audit(
  -- Change all VARCHAR → TEXT
  p_order_number TEXT,  -- Was VARCHAR
  p_type TEXT           -- Was VARCHAR
)
RETURNS TABLE (
  order_number TEXT,    -- Was VARCHAR
  type TEXT             -- Was VARCHAR
)
...
EOF

# Deploy immediately
supabase db push --linked

# Or faster via psql:
psql "$DATABASE_URL" -f supabase/migrations/[TIMESTAMP]_fix_rpc_types.sql
```

**Real Incident:** Oct 22, 03:00 - 30 minutes (see INCIDENTS.md)

---

### 42P01: Relation Does Not Exist

**Example Error:**
```
ERROR: 42P01: relation "order_status_history" does not exist
```

**Quick Fix:**
```bash
# This means table migration never deployed
# Deploy the table creation migration first:
supabase db push --linked

# If that fails, check for the specific migration:
ls supabase/migrations/*order_status_history*.sql
psql "$DATABASE_URL" -f supabase/migrations/[TIMESTAMP]_create_table.sql
```

---

### 23505: Duplicate Key

**Example Error:**
```
ERROR: 23505: duplicate key value violates unique constraint "schema_migrations_pkey"
DETAIL: Key (version)=(20251019) already exists.
```

**Cause:** Multiple migrations with same 8-digit timestamp

**Quick Fix:**
```bash
# Mark old timestamp as reverted
supabase migration repair --status reverted 20251019

# Rename migrations with unique 14-digit timestamps
mv 20251019_migration1.sql 20251019100000_migration1.sql
mv 20251019_migration2.sql 20251019100100_migration2.sql

# Deploy with unique timestamps
supabase db push --linked
```

---

## Common Production Fixes

### Deploy Missing Migration

```bash
# Fastest way (5 minutes):
PGPASSWORD="$SUPABASE_DB_PASSWORD" psql \
  "postgresql://postgres@db.xiwfhcikfdoshxwbtjxt.supabase.co:5432/postgres" \
  -f supabase/migrations/[TIMESTAMP]_migration.sql

# Standard way (10 minutes):
supabase db push --linked

# Verify deployment
supabase migration list --linked | tail -3
```

### Fix RPC Type Mismatch

```bash
# 1. Get current RPC signature
psql "$DATABASE_URL" -c "
SELECT
  p.proname,
  pg_get_function_result(p.oid) AS return_type
FROM pg_proc p
WHERE p.proname = 'create_order_with_audit';
"

# 2. Get table schema
psql "$DATABASE_URL" -c "\d orders"

# 3. Create fix migration (change types to match table)
# See "42804: Type Mismatch" section above

# 4. Deploy fix
psql "$DATABASE_URL" -f supabase/migrations/[TIMESTAMP]_fix_types.sql
```

### Add Missing Column

```bash
# Create emergency migration
cat > "supabase/migrations/$(date +%Y%m%d%H%M%S)_add_missing_column.sql" << 'EOF'
ALTER TABLE table_name
ADD COLUMN IF NOT EXISTS column_name TYPE DEFAULT value;

COMMENT ON COLUMN table_name.column_name IS 'Description';

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'table_name' AND column_name = 'column_name'
  ) THEN
    RAISE EXCEPTION 'Migration failed: column not created';
  END IF;
  RAISE NOTICE 'Migration successful: column added';
END $$;
EOF

# Deploy immediately
psql "$DATABASE_URL" -f supabase/migrations/[TIMESTAMP]_add_missing_column.sql

# Verify
psql "$DATABASE_URL" -c "\d table_name" | grep column_name
```

---

## Rollback Procedures

### Rollback Last Migration

```bash
# WARNING: This will undo migration changes
# Data added by migration will be lost

# Step 1: Identify migration to rollback
supabase migration list --linked | tail -3
# Note the timestamp of last migration

# Step 2: Mark as reverted
supabase migration repair --status reverted [TIMESTAMP]

# Step 3: Manually undo changes
psql "$DATABASE_URL" << 'EOF'
BEGIN;

-- Drop added columns
ALTER TABLE table_name DROP COLUMN IF EXISTS new_column;

-- Drop added functions
DROP FUNCTION IF EXISTS function_name;

-- Drop added tables
DROP TABLE IF EXISTS new_table CASCADE;

COMMIT;
EOF

# Step 4: Verify rollback
psql "$DATABASE_URL" -c "\d table_name"

# Step 5: Update Prisma schema
npx prisma db pull
./scripts/post-migration-sync.sh
```

### Rollback Multiple Migrations

```bash
# If multiple related migrations need rollback:

# Step 1: Identify all migrations to rollback
supabase migration list --linked | tail -5

# Step 2: Mark all as reverted (newest to oldest)
supabase migration repair --status reverted 20251119143022
supabase migration repair --status reverted 20251119142015
supabase migration repair --status reverted 20251119141008

# Step 3: Undo changes in reverse order
# (Write SQL script undoing changes in reverse)

# Step 4: Verify and sync
npx prisma db pull
./scripts/post-migration-sync.sh
```

---

## Schema Inspection Commands

### Check Table Structure

```bash
# Full table description
psql "$DATABASE_URL" -c "\d orders"

# Just column names and types
psql "$DATABASE_URL" -c "
SELECT
  column_name,
  data_type,
  is_nullable,
  column_default
FROM information_schema.columns
WHERE table_name = 'orders'
ORDER BY ordinal_position;
"

# Check if specific column exists
psql "$DATABASE_URL" -c "
SELECT 1
FROM information_schema.columns
WHERE table_name = 'orders' AND column_name = 'version';
"
# Returns "1" if exists, empty if not
```

### Check RPC Functions

```bash
# List all RPC functions
psql "$DATABASE_URL" -c "\df+"

# Check specific function
psql "$DATABASE_URL" -c "\df+ create_order_with_audit"

# Get function signature
psql "$DATABASE_URL" -c "
SELECT
  p.proname AS function_name,
  pg_get_function_arguments(p.oid) AS parameters,
  pg_get_function_result(p.oid) AS return_type
FROM pg_proc p
JOIN pg_namespace n ON p.pronamespace = n.oid
WHERE n.nspname = 'public'
AND p.proname = 'create_order_with_audit';
"
```

### Check Indexes

```bash
# List all indexes on table
psql "$DATABASE_URL" -c "\di+ orders*"

# Check specific index
psql "$DATABASE_URL" -c "
SELECT
  indexname,
  indexdef
FROM pg_indexes
WHERE tablename = 'orders';
"
```

### Check Recent Migrations

```bash
# From Supabase
supabase migration list --linked

# From database directly
psql "$DATABASE_URL" -c "
SELECT
  version,
  name,
  applied_at
FROM supabase_migrations.schema_migrations
ORDER BY version DESC
LIMIT 10;
"
```

---

## Emergency Contacts & Resources

### Quick Links

```bash
# Supabase Dashboard
https://supabase.com/dashboard/project/xiwfhcikfdoshxwbtjxt

# Database Direct Connection (Studio)
https://supabase.com/dashboard/project/xiwfhcikfdoshxwbtjxt/editor

# Render Dashboard
https://dashboard.render.com/web/[service-id]

# Vercel Dashboard
https://vercel.com/[project]

# Incident Documentation
/Users/mikeyoung/CODING/rebuild-6.0/claude-lessons3/02-database-supabase-issues/INCIDENTS.md
```

### Environment Variables

```bash
# Production database URL
DATABASE_URL="postgresql://postgres.[project-ref]:[password]@[host]/postgres"

# Supabase connection details
SUPABASE_DB_PASSWORD="[password]"
SUPABASE_PROJECT_REF="xiwfhcikfdoshxwbtjxt"
SUPABASE_API_URL="https://xiwfhcikfdoshxwbtjxt.supabase.co"
```

### Emergency psql Connection

```bash
# Quick connection
PGPASSWORD="$SUPABASE_DB_PASSWORD" psql \
  "postgresql://postgres@db.xiwfhcikfdoshxwbtjxt.supabase.co:5432/postgres"

# Or use DATABASE_URL directly
psql "$DATABASE_URL"

# For read-only queries (safer)
psql "$DATABASE_URL" -c "SELECT * FROM orders LIMIT 1;"
```

---

## Post-Incident Checklist

After fixing production issue:

```bash
# ☐ 1. Verify production functional
curl -X POST https://api.rebuild6.com/api/v1/orders -d '...'

# ☐ 2. Update Prisma schema
npx prisma db pull
./scripts/post-migration-sync.sh

# ☐ 3. Commit emergency fixes
git add -A
git commit -m "fix(p0): [description of emergency fix]"
git push origin main

# ☐ 4. Verify migration sync
supabase migration list --linked

# ☐ 5. Monitor for 15 minutes
# Check logs for any new errors

# ☐ 6. Document incident
# Add to INCIDENTS.md with:
# - Timeline
# - Error messages
# - Fix applied
# - Prevention measures

# ☐ 7. Post-mortem (if P0 incident)
# Schedule team review within 24 hours
```

---

## Common RPC Fixes (Copy-Paste Ready)

### Fix VARCHAR → TEXT Types

```sql
-- supabase/migrations/$(date +%Y%m%d%H%M%S)_fix_rpc_varchar_to_text.sql

DROP FUNCTION IF EXISTS create_order_with_audit(UUID, VARCHAR, VARCHAR, VARCHAR, JSONB, DECIMAL, DECIMAL, DECIMAL, TEXT, VARCHAR, VARCHAR, JSONB);

CREATE FUNCTION create_order_with_audit(
  p_restaurant_id UUID,
  p_order_number TEXT,           -- Changed from VARCHAR
  p_type TEXT,                    -- Changed from VARCHAR
  p_status TEXT DEFAULT 'pending',
  p_items JSONB DEFAULT '[]'::jsonb,
  p_subtotal DECIMAL DEFAULT 0,
  p_tax DECIMAL DEFAULT 0,
  p_total_amount DECIMAL DEFAULT 0,
  p_notes TEXT DEFAULT NULL,
  p_customer_name TEXT DEFAULT NULL,
  p_table_number TEXT DEFAULT NULL,
  p_metadata JSONB DEFAULT '{}'::jsonb
)
RETURNS TABLE (
  id UUID,
  restaurant_id UUID,
  order_number TEXT,              -- Changed from VARCHAR
  type TEXT,                      -- Changed from VARCHAR
  status TEXT,                    -- Changed from VARCHAR
  -- ... rest of columns with correct types
)
LANGUAGE plpgsql SECURITY DEFINER
AS $$
BEGIN
  -- Function body unchanged
END;
$$;

GRANT EXECUTE ON FUNCTION create_order_with_audit TO authenticated;
GRANT EXECUTE ON FUNCTION create_order_with_audit TO anon;
NOTIFY pgrst, 'reload schema';
```

### Fix TIMESTAMPTZ → TIMESTAMP

```sql
-- supabase/migrations/$(date +%Y%m%d%H%M%S)_fix_timestamp_types.sql

DROP FUNCTION IF EXISTS create_order_with_audit(...);

CREATE FUNCTION create_order_with_audit(...)
RETURNS TABLE (
  created_at TIMESTAMPTZ,      -- This one uses TIMESTAMPTZ
  check_closed_at TIMESTAMP    -- This one uses TIMESTAMP (no TZ)
)
AS $$
BEGIN
  -- Function body
END;
$$;
```

### Add Missing Column to RPC Return

```sql
-- supabase/migrations/$(date +%Y%m%d%H%M%S)_add_version_to_rpc.sql

DROP FUNCTION IF EXISTS create_order_with_audit(...);

CREATE FUNCTION create_order_with_audit(...)
RETURNS TABLE (
  -- ... existing columns ...
  version INTEGER  -- ← Added missing column
)
AS $$
BEGIN
  RETURN QUERY
  SELECT
    -- ... existing columns ...
    o.version  -- ← Added to SELECT
  FROM orders o
  WHERE o.id = v_order_id;
END;
$$;
```

---

## When to Call for Help

### Call Immediately If:

- ❌ Data corruption detected (orders missing/incorrect)
- ❌ Cannot connect to database at all
- ❌ Error rate > 50% of requests
- ❌ Rollback made things worse
- ❌ Unsure what migration to rollback

### Try Self-Fix First If:

- ✅ Clear error message (42703, 42804)
- ✅ Migration file exists but not deployed
- ✅ RPC type mismatch (can create fix migration)
- ✅ Error rate < 10% of requests
- ✅ No data corruption

---

## Time Estimates

| Task | Time | Skill Level |
|------|------|-------------|
| Deploy missing migration | 5 min | Junior |
| Fix RPC type mismatch | 10 min | Mid-level |
| Rollback last migration | 15 min | Senior |
| Rollback multiple migrations | 30 min | Senior + Review |
| Fix data corruption | 1+ hours | Senior + DBA |
| Restore from backup | 2+ hours | Senior + DBA |

---

## Related Documentation

- **README.md** - Overview and metrics
- **INCIDENTS.md** - Detailed incident reports
- **PREVENTION.md** - How to prevent issues
- **AI-AGENT-GUIDE.md** - Rules for AI assistants

---

**Maintained by:** Engineering Team
**Last Updated:** 2025-11-19
**Print This:** Keep copy near on-call engineer's desk

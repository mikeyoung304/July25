---
category: "react-ui-ux"
category_id: "03"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, react-318, hydration, animate-presence, hooks, infinite-loops]
---
# React UI/UX Issues - Quick Reference

A quick-lookup guide for React error codes, common console errors, and debugging checklists.

## React Error Codes

### Error #318: Hydration Mismatch

**Full Error**:
```
Minified React error #318; visit https://react.dev/errors/318
for the full message or use the non-minified dev environment for
full errors and additional helpful warnings.

Hydration failed because the initial UI does not match what was
rendered on the server.
```

**Meaning**: Server-rendered HTML doesn't match client-rendered HTML

**Common Causes**:
1. **Early return before AnimatePresence** (90% of cases)
   ```typescript
   // ❌ BAD
   if (!show) return null
   return <AnimatePresence>...</AnimatePresence>
   ```

2. **Non-deterministic values** (see Error #418)

3. **Browser APIs without SSR guards**
   ```typescript
   // ❌ BAD
   const isChrome = navigator.userAgent.includes('Chrome')
   ```

**First Steps**:
1. Search for `return null` before `<AnimatePresence>`
2. Search for `Date.now()` or `Math.random()` in props
3. Check for `window` or `document` access without guards
4. Test with: `npm run build && npm run preview`

**Fix Time**: 5 minutes once identified, 4-40 hours to identify

---

### Error #418: Non-Deterministic Values

**Full Error**:
```
Minified React error #418

This Suspense boundary received an update before it finished
hydrating. This caused the boundary to switch to client rendering.
```

**Meaning**: Component values changed between server and client render, or between initial and subsequent renders

**Common Causes**:
1. **Date.now() in render or props**
   ```typescript
   // ❌ BAD
   <Component timestamp={Date.now()} />
   ```

2. **Math.random() for keys or IDs**
   ```typescript
   // ❌ BAD
   const id = `temp-${Math.random()}`
   ```

3. **new Date() without stable value**
   ```typescript
   // ❌ BAD
   const now = new Date().toISOString()
   ```

**First Steps**:
1. Search codebase for `Date.now()`, `Math.random()`, `new Date()`
2. Check props passed to modals/animated components
3. Look for timestamp generation in render functions

**Quick Fix**:
```typescript
// ✅ GOOD: Use stable values
<Component timestamp={item.created_at} />

// ✅ GOOD: Use counter
let counter = 0
const id = `temp-${++counter}`

// ✅ GOOD: Generate once
const id = useMemo(() => crypto.randomUUID(), [])
```

**Fix Time**: 15 minutes once identified

---

### Error #310: Too Many Re-Renders

**Full Error**:
```
Minified React error #310

Too many re-renders. React limits the number of renders to prevent
an infinite loop.
```

**Meaning**: Component stuck in infinite render loop

**Common Causes**:
1. **Unstable hook return values**
   ```typescript
   // ❌ BAD: New object every render
   function useToast() {
     return { toast: {...} }
   }
   ```

2. **setState in render**
   ```typescript
   // ❌ BAD
   function Component() {
     setState(newValue)  // Triggers re-render → loop
     return <div>...</div>
   }
   ```

3. **Unstable useCallback/useMemo dependencies**
   ```typescript
   // ❌ BAD: New object in deps every render
   const handler = useCallback(() => {...}, [{ value }])
   ```

**First Steps**:
1. Check recently modified hooks (especially return values)
2. Look for hook returns without `useMemo`
3. Add console.log to identify which dependency changes
4. Use React DevTools Profiler

**Quick Fix**:
```typescript
// ✅ GOOD: Stable return value
function useToast() {
  return useMemo(() => ({ toast: {...} }), [])
}
```

**Fix Time**: 30 minutes

---

### Error #425: Rendered More Hooks Than Previous Render

**Full Error**:
```
Minified React error #425

Rendered more hooks than during the previous render.
```

**Meaning**: Conditional hooks or hooks after early return

**Common Cause**:
```typescript
// ❌ BAD: Hook after conditional return
function Component({ show }) {
  if (!show) return null

  const [state, setState] = useState()  // Only called when show=true
  return <div>...</div>
}
```

**Quick Fix**:
```typescript
// ✅ GOOD: All hooks before conditional
function Component({ show }) {
  const [state, setState] = useState()  // Always called

  if (!show) return null
  return <div>...</div>
}
```

**Fix Time**: 5 minutes

---

## Common Console Errors

### "Cannot read property 'X' of undefined"

**During Modal Open**:
- Check if data loaded before modal opens
- Add null checks: `data?.property`
- Wait for data: `if (!data) return <Loading />`

### "Maximum update depth exceeded"

Same as Error #310. See above.

### "Warning: Cannot update a component while rendering a different component"

**Cause**: setState called during render (usually in child affecting parent)

**Fix**:
```typescript
// ❌ BAD
function Child({ onUpdate }) {
  onUpdate(value)  // Called during render
  return <div>...</div>
}

// ✅ GOOD
function Child({ onUpdate }) {
  useEffect(() => {
    onUpdate(value)
  }, [value, onUpdate])

  return <div>...</div>
}
```

### "Warning: Each child in a list should have a unique 'key' prop"

**Quick Fix**:
```typescript
// ❌ BAD
items.map((item, index) => <Item key={index} />)

// ✅ GOOD
items.map(item => <Item key={item.id} />)
```

---

## Debugging Checklists

### Hydration Error Checklist

When you see React Error #318:

- [ ] Check for early returns before `<AnimatePresence>`
- [ ] Search for `Date.now()`, `Math.random()` in components
- [ ] Check for `window`, `document` access without guards
- [ ] Look for `suppressHydrationWarning` (might be masking issue)
- [ ] Test with production build: `npm run build && npm run preview`
- [ ] Check React DevTools → Components → Search for mismatch
- [ ] Enable React Strict Mode (if not already)
- [ ] Check for non-deterministic class names (CSS-in-JS)

### Infinite Loop Checklist

When you see Error #310 or browser freezes:

- [ ] Check recently modified hooks
- [ ] Look for hook returns without `useMemo`/`useCallback`
- [ ] Add `console.log` in useEffect to identify triggering dependency
- [ ] Check for setState in render body
- [ ] Use React DevTools Profiler → Check render count
- [ ] Look for objects in dependency arrays
- [ ] Check for unstable callback props
- [ ] Verify useCallback dependencies

### Modal Won't Open Checklist

- [ ] Check console for React errors (#318, #418, #310)
- [ ] Verify `show` prop is true
- [ ] Check if AnimatePresence is rendered (even when closed)
- [ ] Verify no early returns before AnimatePresence
- [ ] Check z-index (might be behind other elements)
- [ ] Verify data props are not null/undefined
- [ ] Check network tab for API errors
- [ ] Test in production build

### State Not Updating Checklist

- [ ] Check if using correct state setter
- [ ] Verify no state isolation (nested providers with different keys)
- [ ] Check if state is read-only (props not synced to state)
- [ ] Look for race conditions (multiple setStates)
- [ ] Check if component is unmounting/remounting unexpectedly
- [ ] Verify useEffect dependencies are correct
- [ ] Use React DevTools → Components → Check state values

---

## Testing Commands

### Local Production Build

```bash
# Build for production
npm run build

# Preview production build
npm run preview
# or
npx vite preview --port 5173

# Open in browser
open http://localhost:5173
```

### Check for React Errors

```bash
# Development mode (shows unminified errors)
npm run dev

# Production mode (shows minified errors like #318)
npm run build && npm run preview
```

### Test SSR/Hydration

```bash
# 1. Clear browser cache (important!)
# Chrome: Cmd+Shift+R (Mac) or Ctrl+Shift+R (Windows)

# 2. Open DevTools Console BEFORE loading page

# 3. Load page
open http://localhost:5173/server

# 4. Look for hydration warnings in console
# "Hydration failed"
# "Warning: Text content did not match"
# React Error #318 or #418
```

### Debug Infinite Loops

```bash
# 1. Open React DevTools → Profiler

# 2. Start recording

# 3. Trigger the component (e.g., open modal)

# 4. Stop recording after 2 seconds

# 5. Look for:
# - Components with >50 renders
# - Render count increasing rapidly
# - "Why did this render?" shows dependency changes

# 6. Click on component to see:
# - Which props changed
# - Which state changed
# - Which context changed
```

---

## Quick Fixes

### Fix Hydration Mismatch (AnimatePresence)

```diff
- if (!show) return null
-
  return (
    <AnimatePresence>
-     {show && (
+     {show && data && (
        <motion.div>...</motion.div>
      )}
    </AnimatePresence>
  )
```

### Fix Infinite Loop (Unstable Hook)

```diff
  function useMyHook() {
-   return { value, method }
+   return useMemo(() => ({ value, method }), [value])
  }
```

### Fix Non-Deterministic Values

```diff
  <Component
-   timestamp={Date.now()}
+   timestamp={item.created_at}
-   id={`temp-${Math.random()}`}
+   id={`temp-${counter++}`}
  />
```

### Fix Prop-to-State Sync

```diff
  function Component({ initialValue }) {
    const [value, setValue] = useState(initialValue)
+
+   useEffect(() => {
+     setValue(initialValue)
+   }, [initialValue])

    return <div>{value}</div>
  }
```

### Fix Nested Provider Isolation

```diff
  <CartProvider persistKey="cart_root">
    <CartDrawer />
-   <CartProvider persistKey="cart_nested">
+   <CartProvider persistKey="cart_root">
      <MenuGrid />
    </CartProvider>
  </CartProvider>
```

---

## Search Patterns

### Find Early Returns Before AnimatePresence

```bash
# Find files with AnimatePresence
git grep -l "AnimatePresence" client/src/

# Check each file manually for:
# - return null statements
# - return statements before AnimatePresence
# - early exits before wrappers
```

### Find Non-Deterministic Values

```bash
# Search for Date.now()
git grep "Date\.now()" client/src/

# Search for Math.random()
git grep "Math\.random()" client/src/

# Search for new Date() (excluding known safe usage)
git grep "new Date()" client/src/ | grep -v "new Date(knownValue)"
```

### Find Unstable Hook Returns

```bash
# Find hooks that return objects
git grep -A 3 "export.*function use" client/src/hooks/ | grep "return {"

# Check if wrapped in useMemo
git grep -B 2 -A 3 "return {" client/src/hooks/ | grep useMemo
```

### Find Large Components

```bash
# Find components over 200 lines
find client/src -name "*.tsx" -type f -exec sh -c '
  lines=$(wc -l < "$1")
  if [ "$lines" -gt 200 ]; then
    echo "$lines $1"
  fi
' _ {} \; | sort -rn

# Find components over 300 lines (critical)
find client/src -name "*.tsx" -type f -exec sh -c '
  lines=$(wc -l < "$1")
  if [ "$lines" -gt 300 ]; then
    echo "⚠️  CRITICAL: $lines lines in $1"
  fi
' _ {} \;
```

---

## Component Size Warnings

```
< 50 lines   ✅ Excellent
50-100 lines ✅ Good
100-200 lines ⚠️  OK (watch for complexity)
200-300 lines ⚠️  Warning (consider decomposition)
300-500 lines 🚨 Critical (must decompose)
> 500 lines   🔥 Emergency (blocking bug risk)
```

**Current Status**:
- VoiceOrderModal: 528 lines 🔥
- FloorPlanEditor: 224 lines ⚠️

---

## Git Commands for Investigation

### Find When Bug Was Introduced

```bash
# Search for specific pattern (e.g., early return)
git log -p -- path/to/file.tsx | grep -B 5 "return null"

# Find commit that added problematic line
git blame path/to/file.tsx | grep "return null"

# See full commit
git show <commit-hash>
```

### Find Related Changes

```bash
# Show commits touching file
git log --oneline -- path/to/file.tsx

# Show commits with "hydration" in message
git log --all --grep="hydration"

# Show commits in date range
git log --since="2025-11-01" --until="2025-11-15" --oneline
```

### Compare Working Version vs Broken

```bash
# Find last working commit
git bisect start
git bisect bad HEAD
git bisect good <last-known-good-commit>

# Git will checkout commits to test
# Test each: npm run build && npm run preview
git bisect good  # if works
git bisect bad   # if broken

# Git will identify breaking commit
```

---

## Performance Debugging

### Check for Unnecessary Re-Renders

```javascript
// In browser DevTools console
import { StrictMode } from 'react'

// React will highlight components that re-render
// 1. Open React DevTools
// 2. Go to Profiler tab
// 3. Click record
// 4. Interact with component
// 5. Stop recording
// 6. Look for components with high render count
```

### Check Memory Leaks

```bash
# Take heap snapshot before and after
# Chrome DevTools → Memory → Take Snapshot

# Look for:
# - Increasing heap size
# - Detached DOM nodes
# - Event listeners not cleaned up
# - Timers not cleared
```

---

## Emergency Procedures

### Production is Down - Quick Triage

1. **Check Error Boundary logs**
   ```bash
   # Server logs
   heroku logs --tail --app your-app
   # or Vercel logs
   vercel logs
   ```

2. **Identify Error Type**
   - React #318? → Hydration issue
   - React #418? → Non-deterministic values
   - React #310? → Infinite loop
   - Network errors? → API/backend issue

3. **Quick Rollback**
   ```bash
   # Vercel
   vercel rollback

   # Or revert commit
   git revert HEAD
   git push
   ```

4. **Emergency Hotfix**
   ```bash
   # Create hotfix branch
   git checkout -b hotfix/react-318

   # Make minimal fix
   # Test locally: npm run build && npm run preview

   # Deploy immediately
   git commit -m "hotfix: resolve react #318 hydration"
   git push
   ```

5. **Post-Mortem After Stabilization**
   - Document what went wrong
   - Add test to prevent recurrence
   - Update this guide if new pattern found

---

## Quick Contact

### When to Escalate

- React error not in this guide
- Bug persists after applying fixes
- Affecting multiple components
- Can't reproduce locally
- Production critical

### What to Include

1. **Error message** (exact text, including #)
2. **Steps to reproduce**
3. **Environment** (dev/staging/production)
4. **Browser** (Chrome/Firefox/Safari + version)
5. **Recent changes** (commits in last 24 hours)
6. **Network tab** (any failed requests?)
7. **Console screenshot** (full error stack)

---

## Additional Resources

### Documentation
- [React Error Decoder](https://react.dev/errors)
- [Framer Motion AnimatePresence](https://www.framer.com/motion/animate-presence/)
- [React DevTools Profiler](https://react.dev/learn/react-developer-tools)

### Internal Docs
- [PATTERNS.md](./PATTERNS.md) - Anti-patterns with code examples
- [INCIDENTS.md](./INCIDENTS.md) - Full incident timelines
- [PREVENTION.md](./PREVENTION.md) - Prevention strategies
- [AI-AGENT-GUIDE.md](./AI-AGENT-GUIDE.md) - For Claude Code

### Related Files
- `/docs/postmortems/2025-11-10-react-318-hydration-bug.md`
- `/client/src/pages/components/VoiceOrderModal.tsx` (528 lines)
- `/client/src/hooks/useToast.ts` (stable hook example)

---

**Last Updated**: 2025-11-19
**Version**: 1.0.0
**Status**: Active quick reference

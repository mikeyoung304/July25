---
category: "react-ui-ux"
category_id: "03"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "PATTERNS"
tags: [react-318, hydration, animate-presence, hooks, infinite-loops]
---
# React Anti-Patterns - Code Examples

This document shows the exact patterns that caused production bugs, with before/after code examples.

## Table of Contents

1. [Early Return Before AnimatePresence](#pattern-1-early-return-before-animatepresence)
2. [Unstable Hook Returns](#pattern-2-unstable-hook-returns)
3. [Non-Deterministic Values in Render](#pattern-3-non-deterministic-values-in-render)
4. [Nested Context Providers with Different Keys](#pattern-4-nested-context-providers-with-different-keys)
5. [Prop-to-State Sync Without useEffect](#pattern-5-prop-to-state-sync-without-useeffect)

---

## Pattern 1: Early Return Before AnimatePresence

### The Bug

**File**: `/client/src/pages/components/VoiceOrderModal.tsx`
**Lines**: 81, 182
**Incident**: React #318 Hydration Bug
**Impact**: 3-day production outage
**Cost**: $4,000-7,650 (40-51 hours)

### Before (BROKEN)

```typescript
// VoiceOrderModal.tsx - Line 81
export function VoiceOrderModal({ show, table, seat, ...props }) {
  // ❌ ANTI-PATTERN: Early return before wrapper
  if (!show || !table || !seat) return null

  const [inputMode, setInputMode] = useState('voice')
  // ... 100+ lines of component logic ...

  // Line 182 - AnimatePresence never rendered when conditions false
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Modal content */}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
```

### Why This Breaks

**Server-Side Render (SSR)**:
- When `show=false`, component returns `null`
- Server HTML: (nothing)

**Client-Side Hydration**:
- When `show=false`, component returns `null`
- Initial render matches server: ✅
- **BUT THEN** when `show=true`:
  - AnimatePresence NOW renders (creates wrapper div)
  - React expects server HTML to match client render
  - Server had `null`, client has `<div>` wrapper
  - **Hydration mismatch → React Error #318**

### After (FIXED)

```typescript
// VoiceOrderModal.tsx - Line 81 removed, line 182 updated
export function VoiceOrderModal({ show, table, seat, ...props }) {
  // ✅ No early return - AnimatePresence always in render tree
  const [inputMode, setInputMode] = useState('voice')
  // ... 100+ lines of component logic ...

  return (
    <AnimatePresence>
      {show && table && seat && (  // ✅ Conditional inside wrapper
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          {/* Modal content */}
        </motion.div>
      )}
    </AnimatePresence>
  )
}
```

### Why This Works

**Server-Side Render**:
- AnimatePresence always renders (empty div wrapper)
- Server HTML: `<div></div>`

**Client-Side Hydration**:
- AnimatePresence always renders (empty div wrapper)
- Client HTML: `<div></div>`
- **Perfect match → No hydration error** ✅

**When Modal Opens**:
- `show && table && seat` evaluates to true
- Content animates in smoothly
- AnimatePresence handles exit animations correctly

### The Rule

**Never do this:**
```typescript
if (!condition) return null  // Before wrapper

return (
  <AnimatePresence>
    {condition && <Content />}
  </AnimatePresence>
)
```

**Always do this:**
```typescript
return (
  <AnimatePresence>
    {condition && <Content />}  // Inside wrapper
  </AnimatePresence>
)
```

### Applies To

- `<AnimatePresence>` (Framer Motion)
- `<Suspense>` (React)
- `<ErrorBoundary>` (React)
- `<Portal>` (React DOM)
- Any wrapper component that must render consistently

---

## Pattern 2: Unstable Hook Returns

### The Bug

**File**: `/client/src/hooks/useToast.ts`
**Lines**: 4-12
**Incident**: Infinite Loop Bug
**Impact**: "Loading floor plan..." infinite state
**Cost**: $800-1,500 (8-10 hours)

### Before (BROKEN)

```typescript
// useToast.ts - Lines 4-12
import toast, { ToastOptions, Renderable } from 'react-hot-toast'

export const useToast = () => {
  // ❌ ANTI-PATTERN: Returns new object every render
  return {
    toast: {
      success: (message: Renderable, options?: ToastOptions) =>
        toast.success(message, options),
      error: (message: Renderable, options?: ToastOptions) =>
        toast.error(message, options),
      loading: (message: Renderable, options?: ToastOptions) =>
        toast.loading(message, options),
      dismiss: (toastId?: string) =>
        toast.dismiss(toastId),
    },
  }
}
```

### Why This Breaks

**The Cascade**:
1. Component calls `const { toast } = useToast()`
2. Hook returns NEW object (different reference)
3. Component detects change in dependency array
4. Re-renders
5. Calls `useToast()` again
6. Gets NEW object again
7. **Infinite loop → React error #310**

**Real Example**:
```typescript
// useServerView.ts
const { toast } = useToast()  // NEW object every render

const loadFloorPlan = useCallback(async () => {
  try {
    // Load floor plan
  } catch (error) {
    toast.error('Failed to load')  // Uses toast
  }
}, [toast])  // ❌ toast changes every render → infinite loop

useEffect(() => {
  loadFloorPlan()
}, [loadFloorPlan])  // ❌ loadFloorPlan recreates every render
```

### After (FIXED)

```typescript
// useToast.ts - Lines 1-13
import { useMemo } from 'react'
import toast, { ToastOptions, Renderable } from 'react-hot-toast'

export const useToast = () => {
  // ✅ Wrap return value in useMemo with empty deps
  return useMemo(() => ({
    toast: {
      success: (message: Renderable, options?: ToastOptions) =>
        toast.success(message, options),
      error: (message: Renderable, options?: ToastOptions) =>
        toast.error(message, options),
      loading: (message: Renderable, options?: ToastOptions) =>
        toast.loading(message, options),
      dismiss: (toastId?: string) =>
        toast.dismiss(toastId),
    },
  }), [])  // ✅ Empty deps = stable reference
}
```

### Why This Works

**Stable Reference**:
1. Component calls `const { toast } = useToast()`
2. Hook returns SAME object (useMemo caches it)
3. Component dependency array sees no change
4. No unnecessary re-renders
5. **No infinite loop** ✅

### The Rule

**Never do this:**
```typescript
export const useMyHook = () => {
  return {
    method1: () => {},
    method2: () => {},
  }
}
```

**Always do this:**
```typescript
export const useMyHook = () => {
  return useMemo(() => ({
    method1: () => {},
    method2: () => {},
  }), [])  // Or proper dependencies
}
```

### Applies To

- Hook return values used in dependency arrays
- Objects returned from hooks
- Arrays returned from hooks
- Functions returned from hooks (use useCallback instead)

---

## Pattern 3: Non-Deterministic Values in Render

### The Bug

**File**: `/client/src/pages/ServerView.tsx`
**Lines**: 126-127, 147-148, 167-168
**File**: `/client/src/pages/hooks/useVoiceOrderWebRTC.ts`
**Lines**: 79, 185
**Incident**: React #418 Bug
**Impact**: "This section couldn't be loaded"
**Cost**: $400-900 (4-6 hours)

### Before (BROKEN)

```typescript
// ServerView.tsx - Lines 126-127
<SeatSelectionModal
  show={!voiceOrder.showVoiceOrder && !!selectedTable}
  table={selectedTable}
  selectedSeat={selectedSeat}
  orderedSeats={voiceOrder.orderedSeats}
  onSeatSelect={setSelectedSeat}
  onStartVoiceOrder={handleStartVoiceOrder}
  created_at={new Date().toISOString()}  // ❌ ANTI-PATTERN: Different every render
  updated_at={new Date().toISOString()}  // ❌ ANTI-PATTERN: Different every render
/>

// useVoiceOrderWebRTC.ts - Line 79
const tempId = `voice-${Date.now()}-${Math.random()}`  // ❌ Different every render

// useVoiceOrderWebRTC.ts - Line 185
id: `voice-${Date.now()}-${Math.random()}`  // ❌ Different every render
```

### Why This Breaks

**Framer Motion Re-Render**:
1. Modal opens with AnimatePresence animation
2. During animation, React re-renders component
3. Props comparison: `created_at` was "2025-11-10T10:00:00.123Z"
4. Props comparison: `created_at` now "2025-11-10T10:00:00.456Z"
5. **Different values → React Error #418**

**The Error**:
```
React Error #418: Hydration failed because the server rendered HTML
didn't match the client. As a result this tree will be regenerated
on the client. This can happen if an SSR-ed Client Component used:
- A server/client branch `if (typeof window !== 'undefined')`
- Variable input such as `Date.now()` or `Math.random()`
```

### After (FIXED)

```typescript
// ServerView.tsx - Lines 126-127
<SeatSelectionModal
  show={!voiceOrder.showVoiceOrder && !!selectedTable}
  table={selectedTable}
  selectedSeat={selectedSeat}
  orderedSeats={voiceOrder.orderedSeats}
  onSeatSelect={setSelectedSeat}
  onStartVoiceOrder={handleStartVoiceOrder}
  created_at={selectedTable?.created_at || ''}  // ✅ Use stable value
  updated_at={selectedTable?.updated_at || ''}  // ✅ Use stable value
/>

// useVoiceOrderWebRTC.ts - Lines 19, 79
let voiceOrderCounter = 0  // ✅ Module-level counter

function useVoiceOrderWebRTC() {
  const tempId = `voice-${++voiceOrderCounter}`  // ✅ Deterministic

  // Line 185
  id: `voice-${++voiceOrderCounter}`  // ✅ Deterministic
}
```

### Why This Works

**Stable Values**:
1. Modal opens with AnimatePresence animation
2. During animation, React re-renders component
3. Props comparison: `created_at` was "2025-11-10T08:30:00.000Z"
4. Props comparison: `created_at` still "2025-11-10T08:30:00.000Z"
5. **Same values → No error** ✅

**Deterministic IDs**:
1. Counter starts at 0
2. First call: `voice-1`
3. Second call: `voice-2`
4. Predictable, unique, stable

### The Rule

**Never do this:**
```typescript
const id = `order-${Date.now()}`          // ❌ Non-deterministic
const id = `item-${Math.random()}`        // ❌ Non-deterministic
const timestamp = new Date().toISOString() // ❌ Non-deterministic
const value = window.innerWidth           // ❌ Non-deterministic
```

**Always do this:**
```typescript
// Option 1: Use stable prop/state
const id = item.id

// Option 2: Use counter
let counter = 0
const id = `temp-${++counter}`

// Option 3: Generate once in useEffect
const [id, setId] = useState<string>()
useEffect(() => {
  if (!id) setId(`order-${Date.now()}`)
}, [id])

// Option 4: Use crypto.randomUUID() (stable across renders)
const id = useMemo(() => crypto.randomUUID(), [])
```

### Applies To

- `Date.now()` in render or props
- `Math.random()` in render or props
- `new Date()` in render or props
- `window.innerWidth` or DOM measurements
- Any value that changes between renders

---

## Pattern 4: Nested Context Providers with Different Keys

### The Bug

**File**: `/client/src/pages/components/VoiceOrderModal.tsx`
**Line**: 237
**File**: `/client/src/App.tsx`
**Line**: 219
**Incident**: Cart Provider Isolation
**Impact**: Touch ordering showed "Added!" but cart stayed empty
**Cost**: $600-1,200 (6-8 hours)

### Before (BROKEN)

```typescript
// App.tsx - Line 219
export function App() {
  return (
    <UnifiedCartProvider persistKey="cart_current">  {/* Root provider */}
      <Router>
        <Routes>
          <Route path="/server" element={<ServerView />} />
        </Routes>
      </Router>
      <CartDrawer />  {/* Reads from root provider */}
    </UnifiedCartProvider>
  )
}

// VoiceOrderModal.tsx - Line 237
export function VoiceOrderModal({ show, table, seat }) {
  return (
    <AnimatePresence>
      {show && table && seat && (
        <motion.div>
          {/* ❌ ANTI-PATTERN: Nested provider with DIFFERENT persistKey */}
          <UnifiedCartProvider persistKey="voice_order_modal_touch">
            <MenuGrid />  {/* MenuItemCard components inside */}
          </UnifiedCartProvider>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
```

### Why This Breaks

**State Isolation**:
```
┌──────────────────────────────────────────┐
│ ROOT PROVIDER                             │
│ persistKey: "cart_current"                │
│ localStorage: cart_current                │
│                                           │
│ ┌─────────────────┐                      │
│ │ CartDrawer      │ ← Reads from root    │
│ │ items: []       │   Shows EMPTY        │
│ └─────────────────┘                      │
└──────────────────────────────────────────┘

┌──────────────────────────────────────────┐
│ NESTED PROVIDER (Inside VoiceOrderModal) │
│ persistKey: "voice_order_modal_touch"    │
│ localStorage: voice_order_modal_touch    │
│                                           │
│ ┌─────────────────┐                      │
│ │ MenuItemCard    │ ← Writes to nested   │
│ │ addToCart()     │   Has ITEMS          │
│ │ items: [...]    │                      │
│ └─────────────────┘                      │
└──────────────────────────────────────────┘
```

**Data Flow Problem**:
1. User clicks "Add to Cart" in MenuItemCard
2. MenuItemCard calls `useUnifiedCart()` hook
3. Hook returns **nested provider** context (closest ancestor)
4. `addToCart()` updates nested provider state
5. Nested provider shows "Added!" feedback (works correctly)
6. CartDrawer calls `useUnifiedCart()` hook
7. Hook returns **root provider** context
8. Root provider state is empty → Cart shows nothing

**Result**: Two separate localStorage keys, two isolated states

### After (FIXED)

```typescript
// VoiceOrderModal.tsx - Line 237
export function VoiceOrderModal({ show, table, seat }) {
  return (
    <AnimatePresence>
      {show && table && seat && (
        <motion.div>
          {/* ✅ Use SAME persistKey as root provider */}
          <UnifiedCartProvider persistKey="cart_current">
            <MenuGrid />  {/* MenuItemCard components inside */}
          </UnifiedCartProvider>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
```

### Why This Works

**Shared State**:
```
┌──────────────────────────────────────────┐
│ ROOT PROVIDER                             │
│ persistKey: "cart_current"                │
│ localStorage: cart_current                │
│                                           │
│ ┌─────────────────┐  ┌─────────────────┐ │
│ │ CartDrawer      │  │ VoiceOrderModal │ │
│ │ items: [...]    │  │ (nested)        │ │
│ │                 │  │ persistKey:     │ │
│ │                 │  │ "cart_current"  │ │
│ │                 │  │                 │ │
│ │                 │  │ ┌─────────────┐ │ │
│ │                 │  │ │ MenuItemCard│ │ │
│ │                 │  │ │ items: [...] │ │ │
│ │                 │  │ └─────────────┘ │ │
│ └─────────────────┘  └─────────────────┘ │
│                                           │
│ All read/write from same state ✅         │
└──────────────────────────────────────────┘
```

**Data Flow Fixed**:
1. User clicks "Add to Cart" in MenuItemCard
2. MenuItemCard calls `useUnifiedCart()` hook
3. Hook returns **nested provider** context (closest ancestor)
4. Nested provider has persistKey="cart_current"
5. Both providers share same localStorage key
6. Both providers share same state
7. `addToCart()` updates shared state
8. CartDrawer sees update immediately ✅

### The Rule

**Never do this:**
```typescript
<MyProvider key="parent">
  <Component />
  <MyProvider key="child">  {/* ❌ Different key = isolated state */}
    <OtherComponent />
  </MyProvider>
</MyProvider>
```

**Always do this:**
```typescript
// Option 1: Same key (shared state)
<MyProvider key="shared">
  <Component />
  <MyProvider key="shared">  {/* ✅ Same key = shared state */}
    <OtherComponent />
  </MyProvider>
</MyProvider>

// Option 2: Don't nest (preferred)
<MyProvider key="shared">
  <Component />
  <OtherComponent />  {/* ✅ No nesting needed */}
</MyProvider>
```

### Applies To

- Context providers with persistence (localStorage, sessionStorage)
- Context providers with unique identifiers
- Any provider where state isolation would break functionality

---

## Pattern 5: Prop-to-State Sync Without useEffect

### The Bug

**File**: `/client/src/pages/components/VoiceOrderModal.tsx`
**Lines**: 68-76
**Incident**: Infinite Loop Bug (secondary issue)
**Impact**: Modal didn't switch between voice/touch modes
**Cost**: Included in $800-1,500 (8-10 hours)

### Before (BROKEN)

```typescript
// VoiceOrderModal.tsx - Lines 68-76
export function VoiceOrderModal({
  initialInputMode,  // Prop that can change
  ...props
}) {
  // ❌ ANTI-PATTERN: useState ignores prop changes after first render
  const [inputMode, setInputMode] = useState(initialInputMode)

  // initialInputMode changes from 'voice' to 'touch'
  // But inputMode stays as 'voice' (useState only uses initial value)

  return (
    <div>
      {inputMode === 'voice' && <VoiceOrderView />}
      {inputMode === 'touch' && <TouchOrderView />}
    </div>
  )
}
```

### Why This Breaks

**useState Behavior**:
1. Component mounts with `initialInputMode='voice'`
2. `useState(initialInputMode)` sets `inputMode='voice'`
3. User clicks "Switch to Touch" button
4. Parent updates `initialInputMode='touch'`
5. Component re-renders
6. **useState IGNORES new initialInputMode value**
7. `inputMode` stays as `'voice'`
8. Wrong view displays

**The Confusion**:
- `useState(initialValue)` **only uses initialValue on FIRST render**
- Subsequent renders ignore the parameter
- This is by design (React optimization)
- But it breaks prop-to-state synchronization

### After (FIXED)

```typescript
// VoiceOrderModal.tsx - Lines 68-76
export function VoiceOrderModal({
  initialInputMode,  // Prop that can change
  ...props
}) {
  const [inputMode, setInputMode] = useState(initialInputMode)

  // ✅ Sync prop changes to local state
  useEffect(() => {
    setInputMode(initialInputMode)
  }, [initialInputMode])  // Re-run when prop changes

  return (
    <div>
      {inputMode === 'voice' && <VoiceOrderView />}
      {inputMode === 'touch' && <TouchOrderView />}
    </div>
  )
}
```

### Why This Works

**Prop Synchronization**:
1. Component mounts with `initialInputMode='voice'`
2. `useState(initialInputMode)` sets `inputMode='voice'`
3. `useEffect` runs, calls `setInputMode('voice')` (no change)
4. User clicks "Switch to Touch" button
5. Parent updates `initialInputMode='touch'`
6. Component re-renders
7. **useEffect detects prop change**
8. Calls `setInputMode('touch')`
9. Triggers another re-render with correct mode ✅

### The Rule

**Never do this:**
```typescript
function MyComponent({ initialValue }) {
  const [value, setValue] = useState(initialValue)
  // ❌ value won't update when initialValue changes
  return <div>{value}</div>
}
```

**Always do this:**
```typescript
// Option 1: Sync with useEffect (when you need local state)
function MyComponent({ initialValue }) {
  const [value, setValue] = useState(initialValue)

  useEffect(() => {
    setValue(initialValue)
  }, [initialValue])

  return <div>{value}</div>
}

// Option 2: Don't use local state (when you don't need it)
function MyComponent({ value }) {
  // ✅ Just use the prop directly
  return <div>{value}</div>
}

// Option 3: Controlled component (parent manages state)
function MyComponent({ value, onChange }) {
  return <input value={value} onChange={e => onChange(e.target.value)} />
}
```

### Applies To

- Props that initialize state but can change later
- "Initial" props (`initialValue`, `defaultValue`, etc.)
- Props that should update component's internal state
- Derived state that depends on props

---

## Summary of Anti-Patterns

| Pattern | Error Type | Detection Difficulty | Production Risk |
|---------|-----------|---------------------|-----------------|
| Early Return Before AnimatePresence | React #318 Hydration | Very High | Critical |
| Unstable Hook Returns | React #310 Infinite Loop | High | High |
| Non-Deterministic Values | React #418 Hydration | High | High |
| Nested Providers Different Keys | State Isolation | Medium | High |
| Prop-to-State Sync Missing | UI Behavior | Low | Medium |

## Detection Strategy

### In Code Review
1. Search for `return` statements before `<AnimatePresence>`
2. Search for hooks that return objects without `useMemo`
3. Search for `Date.now()`, `Math.random()` in render or props
4. Search for nested providers with `persistKey` or similar
5. Search for `useState(props.initial...)` without `useEffect`

### In Testing
1. Run production build: `npm run build && npm run preview`
2. Check console for React errors #318, #418, #310
3. Test modal open/close (hydration issues)
4. Test rapid interactions (infinite loop detection)
5. Verify state updates across component boundaries

### In Monitoring
1. Alert on React error codes in production logs
2. Track infinite loop detection (>50 renders/second)
3. Monitor modal interaction success rates
4. Track localStorage inconsistencies

---

**Last Updated**: 2025-11-19
**Based On**: 5 production incidents (Nov 2-10, 2025)
**Files Referenced**:
- `/client/src/pages/components/VoiceOrderModal.tsx` (528 lines)
- `/client/src/hooks/useToast.ts` (13 lines)
- `/client/src/pages/ServerView.tsx`
- `/client/src/App.tsx`

---
category: "react-ui-ux"
category_id: "03"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, react-318, hydration, animate-presence, hooks, infinite-loops]
---
# AI Agent Guide - React UI/UX Issues

**Audience**: Claude Code, Cursor AI, GitHub Copilot, and other AI coding assistants

This guide helps AI agents avoid the 5 React anti-patterns that caused $5,500-8,000 in developer time and 3 days of production downtime.

## Executive Summary for AI Agents

You are more likely to introduce these bugs than human developers because:
1. You don't see the full 528-line file context (just snippets)
2. You pattern-match common React patterns that look correct but aren't
3. You optimize for conciseness, removing "redundant" wrappers
4. You don't test with production builds (only suggest changes)

**Golden Rule**: When editing React components, ALWAYS check these 5 patterns FIRST.

---

## Pattern 1: Early Returns Before AnimatePresence

### Why AI Agents Get This Wrong

**AI Pattern Recognition**:
```typescript
// You see this pattern (looks like optimization):
if (!show) return null  // Exit early, save computation ✅
return <div>...</div>
```

**AI assumes**: Early returns are good (they usually are!)

**Reality**: Not before AnimatePresence (React #318 hydration error)

### ⚠️  CRITICAL CHECK: Before Suggesting Early Return

**Ask yourself**:
1. Is there an `<AnimatePresence>` in the component?
2. Is my early return BEFORE the AnimatePresence?
3. If yes → **DO NOT suggest early return**

### ✅ Correct Pattern to Suggest

```typescript
// NEVER suggest this:
if (!show) return null
return <AnimatePresence>{show && ...}</AnimatePresence>

// ALWAYS suggest this:
return <AnimatePresence>{show && ...}</AnimatePresence>
```

### Red Flags to Detect

When you see a file with:
- `import { AnimatePresence } from 'framer-motion'`
- OR `<AnimatePresence>` in JSX
- AND any `return null` or early returns

**STOP and verify**: Is the early return AFTER AnimatePresence in render tree?

### AI Agent Checklist

When asked to "optimize" or "refactor" a component:
- [ ] Search file for `AnimatePresence`
- [ ] If found, search for `return null` or `return` before it
- [ ] If both exist, **DO NOT suggest moving return earlier**
- [ ] If user asks "why not early return?", explain hydration risk

---

## Pattern 2: Unstable Hook Returns

### Why AI Agents Get This Wrong

**AI Pattern Recognition**:
```typescript
// You see this pattern (looks clean):
export function useToast() {
  return {
    toast: { success: ..., error: ... }
  }
}
```

**AI assumes**: This is how custom hooks work ✅

**Reality**: This causes infinite loops (React #310)

### ⚠️  CRITICAL CHECK: Before Suggesting Hook Return

**Ask yourself**:
1. Am I suggesting a hook that returns an object or array?
2. Is the return value wrapped in `useMemo` or `useCallback`?
3. If no → **ADD useMemo wrapper**

### ✅ Correct Pattern to Suggest

```typescript
// NEVER suggest this:
export function useMyHook() {
  return { method1, method2 }
}

// ALWAYS suggest this:
export function useMyHook() {
  return useMemo(() => ({
    method1,
    method2,
  }), [/* deps */])
}
```

### Red Flags to Detect

When you see a file in `client/src/hooks/`:
- Exports function starting with `use`
- Returns object literal `{ ... }`
- No `useMemo` wrapping the return

**STOP and add**: `return useMemo(() => ({ ... }), [])`

### AI Agent Checklist

When creating or modifying a custom hook:
- [ ] Does it return an object? → Wrap in `useMemo`
- [ ] Does it return an array? → Wrap in `useMemo`
- [ ] Does it return a function? → Use `useCallback`
- [ ] Are dependencies correct? (empty `[]` if no external deps)

---

## Pattern 3: Non-Deterministic Values

### Why AI Agents Get This Wrong

**AI Pattern Recognition**:
```typescript
// You see this pattern (looks reasonable):
<Modal created_at={new Date().toISOString()} />
const id = `temp-${Date.now()}-${Math.random()}`
```

**AI assumes**: Timestamps and random IDs are fine ✅

**Reality**: These cause React #418 (hydration error during animations)

### ⚠️  CRITICAL CHECK: Before Suggesting Date/Random Values

**Ask yourself**:
1. Am I using `Date.now()`, `new Date()`, or `Math.random()`?
2. Is this in:
   - Component render body?
   - Props being passed?
   - JSX attributes?
3. If yes → **USE DETERMINISTIC VALUE INSTEAD**

### ✅ Correct Pattern to Suggest

```typescript
// NEVER suggest this:
<Modal timestamp={Date.now()} />
<Modal created_at={new Date().toISOString()} />
const id = `item-${Math.random()}`

// ALWAYS suggest this:
<Modal timestamp={item.created_at} />  // From data
const id = useMemo(() => crypto.randomUUID(), [])  // Stable
let counter = 0; const id = `item-${++counter}`  // Counter
```

### Exception: useEffect is Safe

```typescript
// ✅ OK: In useEffect (runs after render)
useEffect(() => {
  const timestamp = Date.now()
  logEvent(timestamp)
}, [])
```

### Red Flags to Detect

When you see code asking for timestamps or IDs:
- User: "Add a timestamp to this component"
- User: "Generate a unique ID for this item"

**STOP and ask**: "Do you want this ID to be stable across re-renders? I recommend using crypto.randomUUID() with useMemo, or a counter-based approach."

### AI Agent Checklist

Before suggesting `Date.now()`, `Math.random()`, or `new Date()`:
- [ ] Is this in render body or props? → Use stable value
- [ ] Is this for a temporary ID? → Use counter or crypto.randomUUID()
- [ ] Is this for a timestamp? → Use data from props/state
- [ ] Is this in useEffect/useCallback/useMemo? → OK (but document why)

---

## Pattern 4: Nested Providers with Different Keys

### Why AI Agents Get This Wrong

**AI Pattern Recognition**:
```typescript
// You see this pattern (looks isolated):
<CartProvider persistKey="unique_key">
  <MenuGrid />
</CartProvider>
```

**AI assumes**: Unique keys prevent conflicts ✅

**Reality**: Unique keys CREATE conflicts (state isolation)

### ⚠️  CRITICAL CHECK: Before Suggesting Nested Provider

**Ask yourself**:
1. Is there already a provider of this type higher in the tree?
2. Does it have a `persistKey`, `storageKey`, or similar prop?
3. Am I suggesting a DIFFERENT key value?
4. If yes → **USE SAME KEY as parent**

### ✅ Correct Pattern to Suggest

```typescript
// NEVER suggest this:
// App.tsx
<CartProvider persistKey="cart_root">
  <Routes />
</CartProvider>

// Page.tsx
<CartProvider persistKey="cart_page">  // ❌ Different key
  <MenuGrid />
</CartProvider>

// ALWAYS suggest this:
// Page.tsx
<CartProvider persistKey="cart_root">  // ✅ Same key
  <MenuGrid />
</CartProvider>

// OR BETTER: No nesting
// Page.tsx
const cart = useCart()  // Uses parent provider
<MenuGrid cart={cart} />
```

### Red Flags to Detect

When you see:
- `<SomeProvider persistKey="...">` in parent file
- User asks to "add same provider to nested component"
- Different string values for persistKey

**STOP and ask**: "I see a CartProvider with persistKey='X' in the parent. Should I use the same key to share state, or do you want isolated state?"

### AI Agent Checklist

When suggesting a Context Provider:
- [ ] Search codebase for existing instances
- [ ] Check their `persistKey`/`storageKey` values
- [ ] If nesting, use SAME key (unless explicitly want isolation)
- [ ] Consider: Does component really need provider, or can it use hook?

---

## Pattern 5: Prop-to-State Without useEffect

### Why AI Agents Get This Wrong

**AI Pattern Recognition**:
```typescript
// You see this pattern (looks correct):
function Modal({ initialValue }) {
  const [value, setValue] = useState(initialValue)
  return <div>{value}</div>
}
```

**AI assumes**: useState with prop initializer is correct ✅

**Reality**: useState only uses initial value ONCE (prop changes ignored)

### ⚠️  CRITICAL CHECK: Before Suggesting useState(props.X)

**Ask yourself**:
1. Is the prop prefixed with "initial" or "default"?
2. Could the prop value change during component lifetime?
3. If yes → **ADD useEffect to sync**

### ✅ Correct Pattern to Suggest

```typescript
// NEVER suggest just this:
const [value, setValue] = useState(props.initialValue)

// ALWAYS suggest this:
const [value, setValue] = useState(props.initialValue)

useEffect(() => {
  setValue(props.initialValue)
}, [props.initialValue])

// OR BETTER: Controlled component (no local state)
function Modal({ value, onChange }) {
  return <input value={value} onChange={onChange} />
}
```

### Red Flags to Detect

When you see prop names:
- `initialValue`
- `defaultValue`
- `initialMode`
- `defaultMode`
- Any prop used to initialize useState

**STOP and add**: useEffect to sync prop changes to state

### AI Agent Checklist

When suggesting useState with prop initializer:
- [ ] Is prop name `initial*` or `default*`? → Add useEffect sync
- [ ] Could prop change? → Add useEffect sync
- [ ] Is state needed? → Consider controlled component instead
- [ ] Document why local state is needed (if keeping it)

---

## Pattern 6: Component Size (Bonus Pattern)

### Why AI Agents Get This Wrong

**AI Behavior**:
- You add features to existing files
- You don't see total line count
- You assume "keep related code together" ✅

**Reality**: Components >200 lines hide bugs

### ⚠️  CRITICAL CHECK: Before Adding Code to Large File

**Ask yourself**:
1. How many lines is this file currently?
2. How many lines am I adding?
3. Will total exceed 200 lines?
4. If yes → **SUGGEST DECOMPOSITION**

### ✅ Correct Pattern to Suggest

```typescript
// NEVER suggest this:
// VoiceOrderModal.tsx (already 500 lines)
// Add touch mode: +200 lines
// Total: 700 lines ❌

// ALWAYS suggest this:
// VoiceOrderModal.tsx (150 lines) - Container
// VoiceOrderView.tsx (200 lines) - Voice logic
// TouchOrderView.tsx (200 lines) - Touch logic
// Total: 550 lines across 3 files ✅
```

### AI Agent Checklist

Before adding features:
- [ ] Request file line count: "How many lines is this file?"
- [ ] If >200 lines, ask: "Should we decompose this component first?"
- [ ] Suggest extraction: "Extract [feature] to separate component?"
- [ ] Show decomposition plan before implementing

---

## AI Agent Workflow

### When Asked to Modify React Component

**Step 1: Pre-Flight Checks (ALWAYS RUN THESE)**

```
1. Line count check:
   "This file is X lines. If >200, consider decomposition."

2. AnimatePresence check:
   Search file for "AnimatePresence"
   If found: "⚠️  File uses AnimatePresence. No early returns before it."

3. Hook return check:
   If file is in hooks/: "All hook returns must use useMemo/useCallback."

4. Non-deterministic check:
   Search for: Date.now(), Math.random(), new Date()
   If found: "⚠️  Non-deterministic values detected. Replace with stable values."

5. Provider check:
   Search for: <*Provider
   If found: "Check parent files for same provider with persistKey."
```

**Step 2: Make Changes**

Implement the requested changes WHILE keeping checks in mind.

**Step 3: Post-Flight Verification**

```
After suggesting changes, add:

"✅ Verification:
- No early returns before AnimatePresence
- Hook returns wrapped in useMemo
- No Date.now()/Math.random() in render
- Provider keys consistent with parent
- Component under 200 lines (or decomposition suggested)

Please test with: npm run build && npm run preview"
```

### Example AI Response Template

```markdown
I'll help you add that feature. First, let me verify the file:

**Pre-flight checks:**
- ✅ File: VoiceOrderModal.tsx (528 lines)
- ⚠️  WARNING: File exceeds 200 lines (528). Consider decomposition.
- ✅ Uses AnimatePresence (line 182)
- ⚠️  CRITICAL: Early return on line 81 before AnimatePresence
- ✅ No non-deterministic values detected

**Recommendation:**
Before adding new features, we should:
1. Remove the early return on line 81 (causes React #318)
2. Consider decomposing into VoiceOrderView + TouchOrderView

Would you like me to:
A) Fix the critical issue first
B) Proceed with feature and fix later
C) Decompose component as part of this change
```

---

## Red Flags in User Requests

### "Make it faster"
- User might want early returns for optimization
- **Check**: Is there AnimatePresence? If yes, DON'T add early returns
- **Suggest**: useMemo for expensive calculations instead

### "Add a unique ID"
- User might expect Date.now() or Math.random()
- **Check**: Is this in render? If yes, DON'T use Date.now()
- **Suggest**: Counter or crypto.randomUUID() with useMemo

### "Fix the modal not opening"
- Likely React #318 (hydration)
- **Check**: Early return before AnimatePresence?
- **Suggest**: Remove early return, move conditional inside

### "Cart not updating"
- Likely nested provider isolation
- **Check**: Different persistKey values?
- **Suggest**: Use same persistKey as parent

### "Infinite loading"
- Likely infinite loop (React #310)
- **Check**: Unstable hook return?
- **Suggest**: Wrap return in useMemo

---

## Testing Reminders

### Always Suggest These Tests

After making React changes:

```bash
# 1. Type check
npm run typecheck

# 2. Production build test (CRITICAL for hydration)
npm run build && npm run preview

# 3. Console check
# Open DevTools console and look for:
# - React #318 (hydration)
# - React #418 (non-deterministic)
# - React #310 (infinite loop)

# 4. Animation test
# Open/close modals multiple times
# Check for smooth animations

# 5. State test
# Verify state updates across components
```

---

## Common Mistakes AI Agents Make

### Mistake 1: "Optimizing" by Adding Early Returns

```typescript
// ❌ AI suggests "optimization":
if (!data) return null  // "Skip rendering if no data"
return <AnimatePresence>...</AnimatePresence>

// ✅ Correct:
return <AnimatePresence>{data && ...}</AnimatePresence>
```

### Mistake 2: "Simplifying" Hook Returns

```typescript
// ❌ AI suggests "cleaner code":
return { method1, method2 }  // "Remove unnecessary useMemo"

// ✅ Correct:
return useMemo(() => ({ method1, method2 }), [])
```

### Mistake 3: "Adding Timestamp for Tracking"

```typescript
// ❌ AI suggests "helpful metadata":
<Component timestamp={Date.now()} />  // "Track when rendered"

// ✅ Correct:
<Component timestamp={item.created_at} />  // Use stable data
```

### Mistake 4: "Unique Keys to Avoid Collisions"

```typescript
// ❌ AI suggests "prevent conflicts":
<Provider persistKey="unique_key_123" />  // "Make it unique"

// ✅ Correct:
<Provider persistKey="shared_key" />  // Match parent
```

### Mistake 5: "Clean Component by Removing useEffect"

```typescript
// ❌ AI suggests "unnecessary effect":
const [value, setValue] = useState(props.initial)
// Remove useEffect  // "useState handles it"

// ✅ Correct:
const [value, setValue] = useState(props.initial)
useEffect(() => setValue(props.initial), [props.initial])
```

---

## Decision Trees for AI Agents

### Should I Suggest Early Return?

```
Is there AnimatePresence in component?
├─ YES → Is my return BEFORE AnimatePresence?
│  ├─ YES → ❌ DO NOT suggest early return
│  └─ NO → ✅ Early return OK
└─ NO → ✅ Early return OK (check for Suspense/Portal too)
```

### Should I Wrap Hook Return in useMemo?

```
Is this a custom hook (function name starts with "use")?
├─ YES → Does it return object/array?
│  ├─ YES → ✅ MUST wrap in useMemo
│  └─ NO → Is it a function?
│     ├─ YES → ✅ Use useCallback
│     └─ NO → Primitive value, no wrap needed
└─ NO → Not a hook, normal rules apply
```

### Should I Use Date.now() or Math.random()?

```
Where am I using it?
├─ Component render body → ❌ NO, use stable value
├─ Props being passed → ❌ NO, use stable value
├─ JSX attributes → ❌ NO, use stable value
├─ Inside useEffect → ✅ OK (runs after render)
├─ Inside event handler → ✅ OK (user-triggered)
└─ Backend API call → ✅ OK (not render-related)
```

### Should I Suggest Nested Provider?

```
Is there already a provider of this type in parent?
├─ YES → Does parent have persistKey/storageKey?
│  ├─ YES → ✅ Use SAME key value
│  └─ NO → Ask user about state sharing intent
└─ NO → ✅ OK to add provider (first instance)
```

---

## Final Checklist for AI Agents

Before submitting code suggestions:

### AnimatePresence Check
- [ ] Searched file for `AnimatePresence`
- [ ] Verified no `return null` before it
- [ ] If adding early return, placed it after AnimatePresence

### Hook Stability Check
- [ ] If custom hook, returns wrapped in `useMemo`/`useCallback`
- [ ] Dependencies array is correct
- [ ] No empty object literals in return without useMemo

### Deterministic Values Check
- [ ] No `Date.now()` in render/props
- [ ] No `Math.random()` in render/props
- [ ] No `new Date()` in render/props
- [ ] IDs use counter or crypto.randomUUID() with useMemo

### Provider Consistency Check
- [ ] If suggesting provider, checked for existing instances
- [ ] persistKey matches parent (if state should be shared)
- [ ] Considered: Does component need provider or just hook?

### Prop-to-State Sync Check
- [ ] If `useState(props.initial*)`, added useEffect sync
- [ ] Or suggested controlled component pattern
- [ ] Documented why local state is needed

### Component Size Check
- [ ] Checked current line count
- [ ] If >200 lines, suggested decomposition
- [ ] If adding features, estimated new total

### Testing Reminder
- [ ] Suggested `npm run build && npm run preview`
- [ ] Mentioned checking console for React errors
- [ ] Reminded to test animations/modal behavior

---

## Success Metrics for AI Agents

You're doing well if:
- ✅ No React #318 errors introduced (hydration)
- ✅ No React #418 errors introduced (non-deterministic)
- ✅ No React #310 errors introduced (infinite loop)
- ✅ Component line count stays under 200 (or decreases)
- ✅ Code passes typecheck on first try
- ✅ Production build succeeds without warnings

You need to improve if:
- ❌ User reports "modal won't open" after your changes
- ❌ User reports "infinite loading" after your changes
- ❌ User reports "cart not updating" after your changes
- ❌ User has to fix React errors you introduced
- ❌ User asks "why did you add Date.now() there?"

---

## Resources for AI Agents

### Quick Reference
- [QUICK-REFERENCE.md](./QUICK-REFERENCE.md) - Error codes and fixes
- [PATTERNS.md](./PATTERNS.md) - Anti-patterns with examples
- [PREVENTION.md](./PREVENTION.md) - Prevention strategies

### Learning Materials
- [INCIDENTS.md](./INCIDENTS.md) - See how bugs happened
- React Error #318: https://react.dev/errors/318
- React Error #418: https://react.dev/errors/418

### When in Doubt
Ask the user:
- "I see AnimatePresence - should I avoid early returns?"
- "This hook returns an object - should I wrap in useMemo?"
- "You want a timestamp - should I use data from props or generate?"
- "I see a parent provider - should nested provider use same key?"

---

## Version History

**v1.0.0** (2025-11-19)
- Initial guide based on 5 production incidents
- Covers patterns causing $5,500-8,000 in costs
- Includes decision trees and checklists

---

**Last Updated**: 2025-11-19
**Authority**: Based on production incidents Nov 2-10, 2025
**Status**: Active - for AI agent use
**Cost Prevented**: $5,500-8,000+ per correct application

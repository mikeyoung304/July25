---
category: "testing-quality"
category_id: "06"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "PATTERNS"
tags: [quarantine, test-health, flaky-tests, coverage]
---
# Testing Patterns and Anti-Patterns

**Last Updated:** 2025-11-19

## Overview

This document captures testing patterns learned from the Restaurant OS rebuild-6.0 test crisis (Oct-Nov 2025), where pass rate dropped from 73% to 65%, 24 tests broke, and development was blocked for days.

---

## Anti-Pattern: Whack-a-Mole Test Skipping

### What We Did Wrong

**Timeline:** October 28 - November 2, 2025 (3 days, 52 commits)

```bash
# The pattern we fell into:
$ npm test
❌ FAIL auth-context-timeout.test.tsx

# Quick fix (commit 1):
test.skip('auth context timeout', () => { ... })

# Next run:
❌ FAIL voice-integration.test.tsx

# Another quick fix (commit 2):
test.skip('voice integration', () => { ... })

# Next run:
❌ FAIL order-payload-schema.test.ts

# And so on... (52 commits)
```

### Why It Failed

1. **No Visibility:** Can't answer "what's broken?" or "how broken are we?"
2. **No Prioritization:** Don't know which tests are critical vs nice-to-have
3. **No Recovery Plan:** No roadmap to fix tests, just accumulating debt
4. **Scattered Changes:** 52 commits across different files, no central tracking
5. **Cascading Failures:** Each skip reveals another failing test
6. **Lost Context:** Why did we skip this? What needs to be fixed?

### Evidence from Commit History

```bash
# 52 test-related commits during crisis period:
bd0dfc8d test: skip auth context timeout and voice integration test
4864d373 test: skip two more pre-existing test failures
3971da97 test: skip two more pre-existing test failures
a2722c2b test: skip failing order payload schema validation
0e326ca0 test: rename failing auth test files to .skip
d425316a test: skip failing order payload schema validation
349068fb test: rename hold to record button test file to skip
beb60fba test: quarantine recording indicator test (missing component file)
# ... 44 more similar commits
```

### The Breaking Point

**November 2, 2025:** PR #132 (documentation update) blocked by test failures. Realized we had:
- 24 tests quarantined
- 65% pass rate (down from 73%)
- No tracking system
- No recovery plan
- 3 days of blocked PRs

---

## Pattern: Systematic Test Quarantine

### What We Did Right

**Implementation Date:** November 2, 2025 (Commit 31217345)

### Infrastructure

**1. Central Registry** (`test-quarantine/test-health.json`):
```json
{
  "version": "1.0.4",
  "summary": {
    "total_tests": 377,
    "passing": 329,
    "quarantined": 24,
    "pass_rate": 87.3,
    "health_score": "DEGRADED"
  },
  "quarantined_tests": [
    {
      "id": "auth-005",
      "file": "server/tests/routes/orders.auth.test.ts",
      "reason": "403 Forbidden instead of 201 Created",
      "failure_type": "ASSERTION_FAILURE",
      "last_working_commit": "2025-10-30",
      "priority": 1,
      "status": "SKIPPED",
      "fix_strategy": "Review RBAC changes from Oct 30-31"
    }
  ],
  "modules": {
    "auth": { "total_tests": 120, "passing": 111, "quarantined": 9 },
    "voice": { "total_tests": 95, "passing": 71, "quarantined": 24 },
    "orders": { "total_tests": 87, "passing": 81, "quarantined": 6 }
  }
}
```

**2. Management Script** (`scripts/test-quarantine.js`):
```javascript
// Three modes:
node scripts/test-quarantine.js --dashboard  // Generate TEST_HEALTH.md
node scripts/test-quarantine.js --status     // Show current health
node scripts/test-quarantine.js --run-healthy // Run only passing tests
```

**3. Auto-Generated Dashboard** (`TEST_HEALTH.md`):
- Visual health indicators (✅ ⚠️ ❌)
- Module-level pass rates
- Priority-grouped quarantine list
- Remediation plan with target dates
- Last updated timestamp

**4. Consistent Naming** (`.skip` extension):
```
auth-context-timeout.test.tsx → auth-context-timeout.test.tsx.skip
WebRTCVoiceClient.test.ts → WebRTCVoiceClient.test.ts.skip
```

### Benefits

| Benefit | Before | After |
|---------|--------|-------|
| **Visibility** | "How many tests are broken?" → Unknown | 24 tests, 9 in test-health.json |
| **Prioritization** | All failures equal | Priority 1 (CRITICAL), 2 (HIGH), 3 (MEDIUM) |
| **Recovery Plan** | None | 3-phase plan with target dates |
| **CI/CD** | Blocked by failures | `npm run test:healthy` excludes quarantined |
| **Context** | Lost in commit messages | Documented reason, strategy, last working commit |
| **Tracking** | 52 scattered commits | Single source of truth (test-health.json) |

### New Commands

```bash
# Run only healthy tests (CI-safe):
npm run test:healthy

# Check current health status:
npm run test:quarantine:status

# 🏥 TEST HEALTH STATUS
# Health Score: DEGRADED
# Pass Rate: 87.3%
# Passing: 329/377
# Quarantined: 24

# Regenerate dashboard:
npm run test:quarantine:dashboard

# System-wide health check:
npm run health
```

### Remediation Plan

```
Phase 1: Critical Auth Fixes (Nov 3)
├── Priority 1 tests (1 test)
├── Target: 90% pass rate
└── Status: COMPLETED ✅

Phase 2: Order Flow Restoration (Nov 5)
├── Priority 2 tests (7 tests)
├── Target: 95% pass rate
└── Status: COMPLETED ✅

Phase 3: Voice Integration (Nov 7)
├── Priority 3 tests (4 tests)
├── Target: 97%+ pass rate
└── Status: IN PROGRESS ⏳ (2 tests remaining)
```

---

## Pattern: Flaky Test Root Causes

### 1. Race Conditions

**Example:** `RecordingIndicator.test.tsx`
```typescript
// ❌ FLAKY: Component state change not waited for
it('shows recording state', () => {
  render(<RecordingIndicator isRecording={true} />);
  expect(screen.getByText('RECORDING...')).toBeInTheDocument();
  // Test sometimes fails because state update is async
});

// ✅ FIXED: Wait for async state updates
it('shows recording state', async () => {
  render(<RecordingIndicator isRecording={true} />);
  await waitFor(() => {
    expect(screen.getByText('RECORDING...')).toBeInTheDocument();
  });
});
```

**Failure Type:** `CI_ENVIRONMENT`
**Reason:** CI-specific failure not caught locally due to timing differences

### 2. Mock Staleness

**Example:** `WebRTCVoiceClient.test.ts`
```typescript
// ❌ STALE: Tests written against API that was never implemented
it('configures session with custom settings', () => {
  const client = new WebRTCVoiceClient();
  client.configureSession({ turnServers: [...] }); // Method doesn't exist!
});

// ✅ FIXED: Use actual API
it('configures session with custom settings', () => {
  const client = new WebRTCVoiceClient();
  client.sessionConfig = { turnServers: [...] }; // Property exists
});
```

**Failure Type:** `MISSING_API`
**Reason:** Tests written against planned API that was never implemented
**Fix Strategy:** Either implement `configureSession()` or rewrite tests to use `sessionConfig` property

### 3. Missing Test Providers

**Example:** `orderIntegration.integration.test.tsx`
```typescript
// ❌ MISSING PROVIDER: useAuth hook requires AuthProvider
it('processes voice order', () => {
  render(<VoiceOrderButton />); // useAuth() called, no provider!
  // Error: useAuth must be used within an AuthProvider
});

// ✅ FIXED: Wrap in required providers
it('processes voice order', () => {
  render(
    <AuthProvider>
      <VoiceOrderButton />
    </AuthProvider>
  );
});
```

**Failure Type:** `MISSING_PROVIDER`
**Reason:** Integration test missing required context providers
**Fix Strategy:** Add AuthProvider wrapper to `renderWithRouter` test utility

### 4. Component Structure Changes

**Example:** `checkout-simple.test.tsx`
```typescript
// ❌ STALE SELECTOR: Component structure changed
it('displays checkout button', () => {
  render(<CheckoutPage />);
  expect(screen.getByText(/checkout/i)).toBeInTheDocument();
  // Error: Unable to find element with text /checkout/i
});

// ✅ FIXED: Use data-testid for stability
it('displays checkout button', () => {
  render(<CheckoutPage />);
  expect(screen.getByTestId('checkout-button')).toBeInTheDocument();
});
```

**Failure Type:** `COMPONENT_CHANGE`
**Reason:** CheckoutPage structure changed since test written
**Fix Strategy:** Update selectors to match current structure, use `data-testid` attributes

### 5. Schema Validation Mismatches

**Example:** `order.contract.test.ts`
```typescript
// ❌ SCHEMA MISMATCH: Not following ADR-001 snake_case convention
it('validates order payload', () => {
  const payload = { customerName: "John", totalAmount: 29.99 }; // camelCase!
  expect(OrderPayload.safeParse(payload)).toMatchObject({ success: true });
  // Error: Schema expects customer_name, total_amount
});

// ✅ FIXED: Follow ADR-001 snake_case
it('validates order payload', () => {
  const payload = { customer_name: "John", total_amount: 29.99 };
  expect(OrderPayload.safeParse(payload)).toMatchObject({ success: true });
});
```

**Failure Type:** `SCHEMA_MISMATCH`
**Reason:** OrderPayload schema doesn't accept snake_case per ADR-001
**Fix Strategy:** Align OrderPayload Zod schema with ADR-001 snake_case convention

### 6. Event Handler Spies

**Example:** `WorkspaceDashboard.test.tsx`
```typescript
// ❌ SPY NOT CALLED: Event handler not triggered
it('tiles can be focused and activated with keyboard', () => {
  const handleAccess = vi.fn();
  render(<WorkspaceTile onAccess={handleAccess} />);

  const tile = screen.getByRole('button');
  fireEvent.keyDown(tile, { key: 'Enter' });

  expect(handleAccess).toHaveBeenCalled(); // FAILS: spy not called
});

// ✅ FIXED: Correct keyboard event handling
it('tiles can be focused and activated with keyboard', () => {
  const handleAccess = vi.fn();
  render(<WorkspaceTile onAccess={handleAccess} />);

  const tile = screen.getByRole('button');
  tile.focus();
  fireEvent.keyDown(tile, { key: 'Enter', code: 'Enter' });

  expect(handleAccess).toHaveBeenCalled();
});
```

**Failure Type:** `EVENT_HANDLER`
**Reason:** Keyboard event not properly simulated or handler not attached
**Fix Strategy:** Fix keyboard event handling in WorkspaceTile component

---

## Pattern: CI vs Local Environment Differences

### The Problem

Tests pass locally but fail in CI (or vice versa). This caused significant debugging time during the crisis.

### Common Differences

| Factor | Local | CI (GitHub Actions) |
|--------|-------|---------------------|
| **Performance** | Dedicated CPU | Shared runner, variable performance |
| **Timing** | Consistent | High variance, CPU contention |
| **Memory** | 16GB+ typical | 2-4GB per runner |
| **File System** | SSD, fast I/O | Network-attached, slower I/O |
| **Environment Vars** | `.env` file | GitHub Secrets or none |
| **Node Version** | Developer's choice | Pinned in workflow |
| **OS** | macOS/Windows/Linux | Ubuntu Linux |

### Example: Timing Test Flakiness

**File:** `server/tests/security/webhook.proof.test.ts`

**Test Purpose:** Verify HMAC signature comparison uses constant-time algorithm (prevents timing attacks)

**Failure in CI:**
```
FAIL  tests/security/webhook.proof.test.ts > Timing Attack Prevention
  → expected 6654900.666666667 to be less than 3390273.6666666665
```

**Root Cause:** Test measures response time variance across invalid signatures. CI runners have high performance variance due to:
- Shared CPU resources
- Disk I/O delays
- Network latency
- Other jobs running concurrently

**Solution:** Environment-based tolerance
```typescript
// BEFORE: Same tolerance everywhere
const maxVariance = avgTime * 0.5; // 50% tolerance (2x)

// AFTER: Higher tolerance in CI
const varianceTolerance = process.env.CI ? 3.0 : 2.0; // 3x for CI, 2x for local
const maxVariance = avgTime * varianceTolerance;
```

**Note:** The actual security code uses `crypto.timingSafeEqual()` which is constant-time. The test validates the variance is reasonable, not that it's zero.

### Example: Environment Variable Validation

**File:** `client/vite.config.ts`

**Build Context Differences:**
1. **Local Dev:** Reads from `.env` file → ✅ Works
2. **Vercel Deployment:** Reads from Vercel project settings → ✅ Works
3. **GitHub Actions CI:** No env vars configured → ❌ FAILS

**Original Code (Oct 5):**
```typescript
if (mode === 'production') {
  const requiredEnvVars = ['VITE_API_BASE_URL', 'VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'];
  const missingVars = requiredEnvVars.filter(varName => !env[varName]);
  if (missingVars.length > 0) {
    throw new Error('Cannot build without required environment variables');
  }
}
```

**Impact:** All PRs failed smoke-test in GitHub Actions for 16 days (Oct 5-21)

**Solution (Oct 21):** Conditional validation
```typescript
if (mode === 'production' && !process.env.CI) {
  // Strict validation only for actual deployments (Vercel)
  const requiredEnvVars = [...];
  const missingVars = requiredEnvVars.filter(varName => !env[varName]);
  if (missingVars.length > 0) {
    throw new Error('Cannot build without required environment variables');
  }
} else if (mode === 'production' && process.env.CI) {
  console.warn('⚠️  CI environment detected - skipping strict env validation');
  console.warn('   Production builds on Vercel will still enforce strict validation');
}
```

### Best Practices for Environment Differences

1. **Use `process.env.CI` to detect CI environments:**
   ```typescript
   const timeout = process.env.CI ? 10000 : 5000; // 10s in CI, 5s local
   const retries = process.env.CI ? 3 : 1; // More retries in CI
   const threshold = process.env.CI ? relaxed : strict; // Looser thresholds in CI
   ```

2. **Document environment requirements:**
   ```typescript
   // This test requires:
   // - Local: .env file with VITE_API_BASE_URL
   // - CI: GitHub Secret VITE_API_BASE_URL
   // - Vercel: Environment variable in project settings
   ```

3. **Use `waitFor` with generous timeouts:**
   ```typescript
   // ❌ Flaky in CI
   await screen.findByText('Success');

   // ✅ Robust in CI
   await waitFor(() => screen.getByText('Success'), { timeout: 5000 });
   ```

4. **Avoid hardcoded paths:**
   ```typescript
   // ❌ Breaks across environments
   const configPath = '/Users/mike/project/.env';

   // ✅ Portable across environments
   const configPath = path.join(process.cwd(), '.env');
   ```

---

## Pattern: Test Infrastructure Memory Management

### The Problem

**Discovery Date:** November 10, 2025
**Impact:** 1-20 MB/day memory leak, test infrastructure instability

### Root Causes

**1. VoiceWebSocketServer Cleanup Intervals**

```typescript
// ❌ MEMORY LEAK: Cleanup interval not tracked
export class VoiceWebSocketServer {
  constructor() {
    setInterval(() => this.cleanupStaleConnections(), 60000); // Leaks on restart!
  }
}

// ✅ FIXED: Track and clear interval
export class VoiceWebSocketServer {
  private cleanupInterval?: NodeJS.Timeout;

  constructor() {
    this.cleanupInterval = setInterval(
      () => this.cleanupStaleConnections(),
      60000
    );
  }

  shutdown() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = undefined;
    }
  }
}
```

**2. AuthRateLimiter Cleanup Intervals**

```typescript
// ❌ MEMORY LEAK: Hourly cleanup leaks on server restart
export class AuthRateLimiter {
  constructor() {
    setInterval(() => this.pruneExpiredAttempts(), 3600000); // Hourly, never cleared
  }
}

// ✅ FIXED: Track and clear interval
export class AuthRateLimiter {
  private cleanupInterval?: NodeJS.Timeout;

  constructor() {
    this.cleanupInterval = setInterval(
      () => this.pruneExpiredAttempts(),
      3600000
    );
  }

  shutdown() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = undefined;
    }
  }
}
```

**3. Test Isolation**

```typescript
// ❌ MEMORY LEAK: Server instance not cleaned up between tests
describe('Voice WebSocket', () => {
  let server: VoiceWebSocketServer;

  beforeEach(() => {
    server = new VoiceWebSocketServer();
  });

  // No afterEach cleanup! Server and intervals leak
});

// ✅ FIXED: Proper cleanup
describe('Voice WebSocket', () => {
  let server: VoiceWebSocketServer;

  beforeEach(() => {
    server = new VoiceWebSocketServer();
  });

  afterEach(async () => {
    await server.shutdown();
  });
});
```

### Memory Leak Prevention Tests

**Added:** 16 comprehensive tests in `server/tests/memory-leak-prevention.test.ts`

```typescript
describe('Memory Leak Prevention', () => {
  it('VoiceWebSocketServer clears cleanup interval on shutdown', async () => {
    const server = new VoiceWebSocketServer();
    await server.shutdown();

    // Verify interval cleared
    expect(server['cleanupInterval']).toBeUndefined();
  });

  it('AuthRateLimiter clears cleanup interval on shutdown', async () => {
    const limiter = new AuthRateLimiter();
    await limiter.shutdown();

    // Verify interval cleared
    expect(limiter['cleanupInterval']).toBeUndefined();
  });

  it('graceful shutdown calls all cleanup methods', async () => {
    const shutdownSpy = vi.fn();
    // ... verify all cleanup methods called
  });
});
```

### Results

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Memory Leak Rate** | 1-20 MB/day | <1 MB/day | 95% reduction |
| **Test Pass Rate** | 97.6% | 99.8% | +2.2% |
| **CI Stability** | Occasional OOM | Stable | No OOM |
| **Leak Prevention Tests** | 0 | 16 | 100% coverage |

---

## Pattern: Test Update Requirements

### The Refactoring That Broke 24 Tests

**Date:** October 30-31, 2025
**Impact:** 24 tests broken, pass rate dropped from 73% to 65%

**What Changed:**
1. RBAC (Role-Based Access Control) updates
2. Authentication middleware refactoring
3. Order flow API changes
4. Component structure updates

**What Didn't Change:** Tests

### Why Tests Weren't Updated

1. **Tests Not Part of Refactoring PR:** Code changes reviewed, tests not included
2. **Pre-commit Hooks Didn't Catch:** Hooks don't run full test suite (too slow)
3. **CI Feedback Too Late:** PR merged before CI caught test failures
4. **No Test Review Checklist:** No reminder to update tests

### Prevention Strategy

**1. Test Update Checklist for Refactoring PRs:**
```markdown
## Refactoring Checklist

- [ ] Identified all tests affected by changes
- [ ] Updated test mocks to match new interfaces
- [ ] Updated test assertions to match new behavior
- [ ] Verified tests pass locally with `npm test`
- [ ] Verified tests pass in CI before merge
- [ ] Updated test documentation if patterns changed
```

**2. Pre-Commit Hook for Test-Affecting Changes:**
```bash
# .git/hooks/pre-commit
if git diff --cached --name-only | grep -E "(types|interfaces|contracts)"; then
  echo "⚠️  Type/interface changes detected. Have you updated tests?"
  echo "   Run: npm run test:affected"
fi
```

**3. CI Gate for Test Pass Rate:**
```yaml
# .github/workflows/test-health.yml
- name: Check test pass rate
  run: |
    PASS_RATE=$(node scripts/test-quarantine.js --status | grep "Pass Rate" | awk '{print $3}' | tr -d '%')
    if (( $(echo "$PASS_RATE < 85" | bc -l) )); then
      echo "❌ Test pass rate below 85%: $PASS_RATE%"
      exit 1
    fi
```

**4. Test Review as Part of Code Review:**
```markdown
## Code Review Checklist

- [ ] Code changes reviewed
- [ ] Tests updated to match changes
- [ ] New tests added for new behavior
- [ ] Test coverage maintained or improved
- [ ] Tests pass locally and in CI
```

---

## Summary: Patterns vs Anti-Patterns

| Anti-Pattern | Pattern | Improvement |
|--------------|---------|-------------|
| Whack-a-mole test skipping | Systematic quarantine | Visibility, prioritization, recovery plan |
| Scattered `.skip` comments | Central `test-health.json` | Single source of truth |
| No test health tracking | Auto-generated dashboard | Real-time health metrics |
| Same test config everywhere | Environment-based config | CI/local compatibility |
| Ignore memory leaks | Track and test cleanup | 95% memory leak reduction |
| Refactor without tests | Test update checklist | Zero test breakage |
| Ad-hoc test fixes | Prioritized remediation | Systematic recovery |

---

**Key Takeaway:** Systematic approaches scale, ad-hoc approaches don't. The 3 days and 52 commits of whack-a-mole skipping taught us that visibility, prioritization, and tracking are essential for test health management.

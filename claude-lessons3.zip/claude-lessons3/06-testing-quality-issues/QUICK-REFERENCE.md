---
category: "testing-quality"
category_id: "06"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "QUICK-REFERENCE"
tags: [debugging, troubleshooting, quarantine, test-health, flaky-tests, coverage]
---
# Testing Quality Quick Reference

**Last Updated:** 2025-11-19

## Test Commands

### Running Tests

```bash
# Run all tests (client + server)
npm test

# Run only healthy (non-quarantined) tests
npm run test:healthy

# Run client tests only
npm run test:client

# Run server tests only
npm run test:server

# Watch mode for client tests
npm run test:watch

# Quick test run with minimal output
npm run test:quick

# E2E tests with Playwright
npm run test:e2e
```

### Test Quarantine Management

```bash
# Show current test health status
npm run test:quarantine:status

# Generate/update test health dashboard
npm run test:quarantine:dashboard

# System-wide health check
npm run health

# Auto-fix all fixable issues
npm run health:fix
```

### Test Coverage

```bash
# Generate coverage report
npm run test -- --coverage

# View coverage in browser
open coverage/index.html
```

---

## Pass Rate Calculation

### Current Metrics (v6.0.14)

```
Total Tests:        431
Passing:            430
Quarantined:        1
Pass Rate:          99.8%
Health Score:       HEALTHY ✅
```

### Historical Timeline

| Date | Pass Rate | Status | Quarantined | Event |
|------|-----------|--------|-------------|-------|
| Oct 28 | ~73% | Baseline | 0 | Pre-crisis |
| Oct 30-31 | ~70% | Declining | 0 | Refactoring breaks tests |
| Nov 2 | 65% | **CRISIS** | 24 (untracked) | Whack-a-mole breaking point |
| Nov 2 | 87.3% | Degraded | 24 (tracked) | Quarantine system implemented |
| Nov 3 | 90.1% | Degraded | 21 | Phase 1: Critical auth fixes |
| Nov 5 | 95.2% | Healthy | 16 | Phase 2: Order flow restoration |
| Nov 7 | 97.6% | Healthy | 9 | Phase 3: Voice integration |
| Nov 10 | 99.8% | Healthy | 1 | Memory leak fixes |
| Nov 19 | 85%+ | Healthy | 2 | Current state |

### Health Score Thresholds

| Pass Rate | Health Score | Status | Action |
|-----------|--------------|--------|--------|
| **95%+** | HEALTHY ✅ | Normal | Maintain |
| **85-95%** | DEGRADED ⚠️ | Warning | Weekly review |
| **75-85%** | CRITICAL ❌ | Alert | Daily review, stop features |
| **<75%** | EMERGENCY 🚨 | Crisis | All hands, immediate fix |

### Module Health (Peak Crisis - Nov 2)

| Module | Total | Passing | Quarantined | Pass Rate | Health |
|--------|-------|---------|-------------|-----------|--------|
| Auth | 120 | 111 | 9 | 92.5% | ⚠️ DEGRADED |
| Voice | 95 | 71 | 24 | 74.7% | ❌ CRITICAL |
| Orders | 87 | 81 | 6 | 93.1% | ⚠️ DEGRADED |
| Shared | 75 | 66 | 0 | 88.0% | ✅ HEALTHY |
| **TOTAL** | **377** | **329** | **24** | **87.3%** | ⚠️ **DEGRADED** |

---

## Common Test Failures

### 1. Mock Staleness
```
Error: Method configureSession() does not exist on WebRTCVoiceClient
```

**Cause:** Tests written against API that was never implemented
**Fix:** Update tests to use actual API (e.g., `sessionConfig` property)
**Files:** `client/src/modules/voice/services/__tests__/WebRTCVoiceClient.test.ts.skip`

### 2. Missing Providers
```
Error: useAuth must be used within an AuthProvider
```

**Cause:** Integration test missing required context providers
**Fix:** Wrap component in AuthProvider
**Files:** `client/src/modules/voice/services/orderIntegration.integration.test.tsx.skip`

### 3. Component Structure Changes
```
Error: Unable to find element with text /checkout/i
```

**Cause:** Component structure changed since test written
**Fix:** Update selectors to match current structure, use `data-testid`
**Files:** `client/src/modules/order-system/__tests__/checkout-simple.test.tsx`

### 4. Schema Validation Mismatches
```
Error: OrderPayload schema doesn't accept snake_case per ADR-001
```

**Cause:** Zod schema validation not aligned with snake_case convention
**Fix:** Align OrderPayload Zod schema with ADR-001
**Files:** `server/tests/contracts/order.contract.test.ts.skip`

### 5. Event Handler Spies
```
Error: Spy not called on Enter key press
```

**Cause:** Event handler not triggered by keyboard events
**Fix:** Fix keyboard event handling in component
**Files:** `client/src/pages/__tests__/WorkspaceDashboard.test.tsx.skip`

### 6. CI-Specific Failures
```
Error: expected 6654900.666666667 to be less than 3390273.6666666665
```

**Cause:** CI runners have variable performance, timing test too strict
**Fix:** Use environment-based tolerance (`process.env.CI ? 3.0 : 2.0`)
**Files:** `server/tests/security/webhook.proof.test.ts`

### 7. Environment Variable Validation
```
Error: Missing required environment variables: VITE_API_BASE_URL
```

**Cause:** CI doesn't have env vars that deployment platforms have
**Fix:** Conditional validation (`if (!process.env.CI)`)
**Files:** `client/vite.config.ts`

### 8. Memory Leaks
```
Symptom: Node process memory usage growing over test runs
```

**Cause:** Cleanup intervals not tracked or cleared
**Fix:** Track intervals, implement shutdown methods, call in afterEach
**Files:** `server/src/voice/websocket-server.ts`, `server/src/middleware/authRateLimiter.ts`

---

## Quarantine File Format

### test-health.json Structure

```json
{
  "version": "1.0.4",
  "last_updated": "2025-11-02T21:11:00Z",
  "summary": {
    "total_tests": 377,
    "passing": 329,
    "quarantined": 24,
    "pass_rate": 87.3,
    "health_score": "DEGRADED"
  },
  "quarantined_tests": [
    {
      "id": "auth-005",
      "file": "server/tests/routes/orders.auth.test.ts",
      "module": "auth",
      "test_count": 1,
      "reason": "403 Forbidden instead of 201 Created",
      "failure_type": "ASSERTION_FAILURE",
      "last_working_commit": "2025-10-30",
      "priority": 1,
      "status": "SKIPPED",
      "github_issue": null,
      "fix_strategy": "Review RBAC changes from Oct 30-31"
    }
  ],
  "modules": {
    "auth": {
      "total_tests": 120,
      "passing": 111,
      "quarantined": 9,
      "health": "DEGRADED"
    }
  },
  "remediation_plan": {
    "phase_1": {
      "name": "Critical Auth Fixes",
      "target_date": "2025-11-03",
      "status": "COMPLETED",
      "tests": [],
      "completed": ["auth-001", "auth-002", "auth-005"]
    }
  },
  "metadata": {
    "created_by": "Claude Code",
    "trigger_event": "PR #132 documentation update",
    "root_cause": "Oct 30-31 refactoring without test updates"
  }
}
```

### Quarantine Entry Fields

| Field | Required | Description | Example |
|-------|----------|-------------|---------|
| `id` | ✅ | Unique identifier | `"auth-005"` |
| `file` | ✅ | Absolute path to test file | `"server/tests/routes/orders.auth.test.ts"` |
| `module` | ✅ | Module category | `"auth"`, `"voice"`, `"orders"`, `"shared"` |
| `test_count` | ✅ | Number of tests in file | `1`, `11` |
| `reason` | ✅ | Detailed failure explanation | `"403 Forbidden instead of 201 Created"` |
| `failure_type` | ✅ | Category of failure | See failure types below |
| `last_working_commit` | ✅ | Git SHA when test last passed | `"2025-10-30"` |
| `priority` | ✅ | Urgency level | `1` (CRITICAL), `2` (HIGH), `3` (MEDIUM) |
| `status` | ✅ | Current state | `"QUARANTINED"`, `"SKIPPED"`, `"FAILING"` |
| `github_issue` | ❌ | Link to GitHub issue | `null` or issue URL |
| `fix_strategy` | ✅ | Specific remediation plan | `"Review RBAC changes"` |

### Failure Types

| Type | Description | Example |
|------|-------------|---------|
| `ASSERTION_FAILURE` | Test assertion doesn't match actual result | `403 instead of 201` |
| `MISSING_API` | Method/property doesn't exist | `configureSession() not found` |
| `MISSING_PROVIDER` | Context provider not wrapped | `useAuth outside AuthProvider` |
| `COMPONENT_CHANGE` | Component structure changed | `Unable to find /checkout/i` |
| `EVENT_HANDLER` | Event not triggered or spy not called | `Spy not called on Enter` |
| `SCHEMA_MISMATCH` | Schema validation doesn't match convention | `camelCase vs snake_case` |
| `CI_ENVIRONMENT` | Fails in CI but passes locally | Timing variance |

### Priority Levels

| Priority | Level | SLA | Description |
|----------|-------|-----|-------------|
| **1** | CRITICAL 🔴 | 24 hours | Security/auth tests blocking production |
| **2** | HIGH 🟡 | 3 days | Order flow tests affecting revenue path |
| **3** | MEDIUM 🟢 | 7 days | Feature tests for voice and UI components |

### Status Values

| Status | Meaning | File Extension |
|--------|---------|----------------|
| `QUARANTINED` | Test tracked in quarantine system | `.skip` |
| `SKIPPED` | Test skipped via `.skip` extension | `.skip` |
| `FAILING` | Test runs but fails | (no extension) |

---

## Quarantine Workflow

### Quarantining a Test

```bash
# 1. Document in test-health.json
# Add entry with all required fields

# 2. Rename test file
git mv server/tests/routes/orders.auth.test.ts \
       server/tests/routes/orders.auth.test.ts.skip

# 3. Regenerate dashboard
npm run test:quarantine:dashboard

# 4. Commit changes
git add test-quarantine/test-health.json
git add server/tests/routes/orders.auth.test.ts.skip
git add docs/reference/testing/TEST_HEALTH.md
git commit -m "test: quarantine orders auth test (auth-005)"
```

### Restoring a Test

```bash
# 1. Fix the test
# Update test code to match current implementation

# 2. Restore file name
git mv server/tests/routes/orders.auth.test.ts.skip \
       server/tests/routes/orders.auth.test.ts

# 3. Verify test passes
npm test server/tests/routes/orders.auth.test.ts

# 4. Remove from test-health.json
# Remove entry from quarantined_tests array
# Update summary metrics
# Move to remediation_plan completed list

# 5. Regenerate dashboard
npm run test:quarantine:dashboard

# 6. Commit restoration
git add test-quarantine/test-health.json
git add server/tests/routes/orders.auth.test.ts
git add docs/reference/testing/TEST_HEALTH.md
git commit -m "fix(test): restore orders auth test (auth-005 fixed)"
```

---

## CI Integration

### GitHub Actions Workflows

#### Quick Tests (runs on PR)
```yaml
# .github/workflows/quick-tests.yml
name: Quick Tests
on: [pull_request]

jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: npm install
      - run: npm run test:healthy  # Excludes quarantined tests
```

#### Test Health Gate
```yaml
# .github/workflows/test-health-gate.yml
name: Test Health Gate
on: [pull_request]

jobs:
  check-pass-rate:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: npm install
      - name: Check test pass rate
        run: |
          PASS_RATE=$(node scripts/test-quarantine.js --status | grep "Pass Rate" | awk '{print $3}' | tr -d '%')
          if (( $(echo "$PASS_RATE < 85" | bc -l) )); then
            echo "❌ Test pass rate below 85%: $PASS_RATE%"
            exit 1
          fi
```

#### Daily Test Health Report
```yaml
# .github/workflows/test-health.yml
name: Test Health Report
on:
  schedule:
    - cron: '0 8 * * *' # Daily at 8 AM

jobs:
  report:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - run: npm install
      - run: npm run test:quarantine:dashboard
      - run: |
          if [ -n "$(git status --porcelain)" ]; then
            git config user.name "Test Health Bot"
            git add docs/reference/testing/TEST_HEALTH.md
            git commit -m "chore: update test health dashboard [skip ci]"
            git push
          fi
```

---

## File Locations

### Core Files

| File | Purpose | Auto-Generated |
|------|---------|----------------|
| `test-quarantine/test-health.json` | Central registry of quarantined tests | No (manual updates) |
| `scripts/test-quarantine.js` | Management script | No |
| `docs/reference/testing/TEST_HEALTH.md` | Visual dashboard | Yes (from test-health.json) |
| `TEST_HEALTH.md` (root) | Old location, moved to docs | Deprecated |

### Quarantined Test Files (Current - Nov 19)

```
client/src/modules/voice/components/HoldToRecordButton.test.tsx.skip
client/src/modules/voice/components/RecordingIndicator.test.tsx.skip
client/src/modules/voice/services/__tests__/WebRTCVoiceClient.test.ts.skip
client/src/pages/__tests__/WorkspaceDashboard.test.tsx.skip
server/tests/contracts/order.contract.test.ts.skip
server/tests/middleware/auth-restaurant-id.test.ts.skip
server/tests/routes/orders.auth.test.ts.skip
client/src/modules/voice/services/orderIntegration.integration.test.tsx.skip
```

### Documentation

| File | Purpose |
|------|---------|
| `docs/CI_INFRASTRUCTURE_ISSUES.md` | CI failure documentation (Oct 5-21) |
| `docs/investigations/P0_MEMORY_LEAK_ANALYSIS.md` | Memory leak technical analysis |
| `docs/investigations/P0.8_MEMORY_LEAK_COMPLETION_SUMMARY.md` | Memory leak executive summary |
| `claude-lessons3/06-testing-quality-issues/` | This folder (lessons learned) |

---

## Key Commits

| Commit | Date | Description |
|--------|------|-------------|
| `0a90587` | Oct 5 | Added strict env validation (introduced CI issue) |
| `14477f82` | Oct 21 | CI infrastructure fixes (16-day blockage resolved) |
| `31217345` | Nov 2 | Test quarantine system implementation |
| `21f8a445` | Nov 3 | Phase 1: Critical auth fixes (Priority 1) |
| `b4280140` | Nov 5 | Phase 2: Order flow restoration (Priority 2) |
| `d54de1a1` | Nov 7 | Remove quarantine markers for restored tests |
| `9c7b548d` | Nov 10 | Memory leak resolution (95% reduction) |

---

## Environment Variables for Testing

### Required in CI

```bash
# GitHub Actions
CI=true  # Auto-set by GitHub Actions

# Optional (for smoke tests)
VITE_API_BASE_URL=http://localhost:3001
VITE_SUPABASE_URL=https://example.supabase.co
VITE_SUPABASE_ANON_KEY=dummy_key_for_ci
```

### Required Locally

```bash
# .env file (not committed)
VITE_API_BASE_URL=http://localhost:3001
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your_anon_key

# Server
KIOSK_JWT_SECRET=your_secret_key
SUPABASE_SERVICE_KEY=your_service_key
OPENAI_API_KEY=your_openai_key
```

---

## Useful Scripts

### Find Untracked .skip Files

```bash
find . -name "*.test.ts.skip" -o -name "*.test.tsx.skip" | while read file; do
  if ! grep -q "$file" test-quarantine/test-health.json; then
    echo "⚠️  Untracked skip: $file"
  fi
done
```

### Count Tests by Module

```bash
# Client tests
find client/src -name "*.test.ts" -o -name "*.test.tsx" | wc -l

# Server tests
find server/tests -name "*.test.ts" | wc -l

# Total
find . -name "*.test.ts" -o -name "*.test.tsx" | wc -l
```

### Check Memory Usage During Tests

```bash
# Run tests with memory monitoring
NODE_OPTIONS="--max-old-space-size=3072" npm test

# Check for memory leaks
node --expose-gc --trace-gc npm test
```

### Generate Coverage Report

```bash
npm run test -- --coverage
open coverage/index.html
```

---

## Quick Diagnostic Commands

```bash
# Test health overview
npm run test:quarantine:status

# System health check
npm run health

# Run only healthy tests
npm run test:healthy

# Type check before tests
npm run typecheck:quick

# Memory usage check
npm run memory:check

# Full health check with fixes
npm run health:fix
```

---

## Contact & Resources

- **Test Health Dashboard:** `/docs/reference/testing/TEST_HEALTH.md`
- **Quarantine Registry:** `/test-quarantine/test-health.json`
- **Management Script:** `/scripts/test-quarantine.js`
- **CI Infrastructure Docs:** `/docs/CI_INFRASTRUCTURE_ISSUES.md`
- **Memory Leak Analysis:** `/docs/investigations/P0_MEMORY_LEAK_ANALYSIS.md`

---

**Last Updated:** 2025-11-19
**Pass Rate:** 85%+ (365+ passing tests)
**Health Score:** HEALTHY ✅

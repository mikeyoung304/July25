---
category: "testing-quality"
category_id: "06"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "AI-AGENT-GUIDE"
target_audience: [claude-code, github-copilot, gpt-4, ai-assistants]
tags: [ai-guide, anti-patterns, quarantine, test-health, flaky-tests, coverage]
---
# AI Agent Guide: Testing Quality

**Last Updated:** 2025-11-19
**Audience:** AI agents working on the Restaurant OS rebuild-6.0 project

## Overview

This guide provides specific instructions for AI agents to prevent the testing quality issues that caused 19+ days of blocked development in October-November 2025. Follow these rules systematically to maintain test health.

---

## Rule #1: Never Use .skip Without Tracking

### The Problem We Had

**Timeline:** October 30 - November 2, 2025 (3 days, 52 commits)

AI agents and developers used `.skip` to quickly bypass failing tests without documenting why or planning fixes. This created:
- 65% pass rate (crisis level)
- 24 untracked failing tests
- No visibility into test health
- No recovery plan
- 3 days of blocked PRs

**Example of What NOT to Do:**
```typescript
// ❌ NEVER DO THIS
describe('Voice WebSocket', () => {
  it.skip('handles connections', () => {
    // Test fails, just skip it and move on
  });
});
```

### The Right Way: Systematic Quarantine

When a test fails, follow this workflow:

#### Step 1: Determine if the Failure is Legitimate

```bash
# Run the test in isolation
npm test -- path/to/failing.test.ts

# Ask yourself:
# - Is the test outdated? (component/API changed)
# - Is the mock stale? (API signature changed)
# - Is it a CI-only failure? (environment difference)
# - Is it a real bug? (code is broken)
```

#### Step 2: Document in test-health.json

**BEFORE you skip the test, add an entry:**

```json
{
  "quarantined_tests": [
    {
      "id": "voice-005",
      "file": "client/src/modules/voice/services/__tests__/WebRTCVoiceClient.test.ts",
      "module": "voice",
      "test_count": 11,
      "reason": "Method configureSession() does not exist on WebRTCVoiceClient class. Tests written against API that was never implemented.",
      "failure_type": "MISSING_API",
      "last_working_commit": "2025-10-30",
      "priority": 2,
      "status": "QUARANTINED",
      "github_issue": null,
      "fix_strategy": "Either implement configureSession() method or rewrite tests to use sessionConfig property directly"
    }
  ]
}
```

**Required Fields:**
- `id`: Unique identifier (module-NNN format)
- `file`: Absolute path to test file
- `module`: auth, voice, orders, or shared
- `test_count`: Number of failing tests in file
- `reason`: Detailed explanation of why it fails
- `failure_type`: Category (see failure types below)
- `last_working_commit`: Git SHA when test last passed (use `git log` to find)
- `priority`: 1 (CRITICAL), 2 (HIGH), 3 (MEDIUM)
- `status`: QUARANTINED
- `fix_strategy`: Specific plan to fix the test

#### Step 3: Rename the Test File

```bash
git mv client/src/modules/voice/services/__tests__/WebRTCVoiceClient.test.ts \
       client/src/modules/voice/services/__tests__/WebRTCVoiceClient.test.ts.skip
```

#### Step 4: Regenerate the Dashboard

```bash
npm run test:quarantine:dashboard
```

This updates `docs/reference/testing/TEST_HEALTH.md` with the new quarantine entry.

#### Step 5: Commit All Changes Together

```bash
git add test-quarantine/test-health.json
git add client/src/modules/voice/services/__tests__/WebRTCVoiceClient.test.ts.skip
git add docs/reference/testing/TEST_HEALTH.md
git commit -m "test: quarantine voice WebRTC client tests (voice-005)

Reason: configureSession() method not implemented
Priority: 2 (HIGH)
Fix strategy: Implement method or update tests to use sessionConfig property"
```

### Failure Types Reference

| Type | When to Use | Example |
|------|-------------|---------|
| `ASSERTION_FAILURE` | Test assertion doesn't match actual result | `expect(201).toBe(403)` |
| `MISSING_API` | Method/property doesn't exist | `configureSession() not found` |
| `MISSING_PROVIDER` | Context provider not wrapped | `useAuth outside AuthProvider` |
| `COMPONENT_CHANGE` | Component structure changed | `Cannot find /checkout/i` |
| `EVENT_HANDLER` | Event not triggered | `Spy not called on Enter` |
| `SCHEMA_MISMATCH` | Schema doesn't match convention | `camelCase vs snake_case` |
| `CI_ENVIRONMENT` | Only fails in CI | Timing variance |

### Priority Assignment Guide

| Priority | When to Use | SLA |
|----------|-------------|-----|
| **1 (CRITICAL)** | Auth/security tests blocking production, revenue-impacting bugs | 24 hours |
| **2 (HIGH)** | Order flow tests, payment tests, core feature tests | 3 days |
| **3 (MEDIUM)** | UI component tests, voice integration, non-critical features | 7 days |

### What if the Test is Already Skipped?

If you encounter a `.skip` test without quarantine tracking:

```bash
# 1. Check if it's in test-health.json
grep "filename.test.ts.skip" test-quarantine/test-health.json

# 2. If not found, investigate and document
git log -- path/to/filename.test.ts.skip  # Find when it was skipped
git show <commit>                          # See why it was skipped

# 3. Add to test-health.json following Step 2 above
```

---

## Rule #2: Check Test Health Before Changes

### The Problem We Had

**Timeline:** October 30-31, 2025

Refactoring broke 24 tests because changes were made without:
- Checking baseline test health
- Running tests before/after changes
- Updating tests alongside code changes
- Verifying pass rate maintained

### The Right Way: Test-First Refactoring

#### Before Starting Any Refactoring or Major Changes

```bash
# 1. Check current test health
npm run test:quarantine:status

# Output shows:
# Pass Rate: 85%+
# Passing: 365/377
# Quarantined: 2

# 2. Run full test suite to establish baseline
npm test

# 3. Note any existing failures (don't introduce new ones)
```

#### During Refactoring

```bash
# 1. Run affected tests frequently
npm test -- <pattern>

# Example: If changing order flow
npm test -- order

# 2. Fix tests immediately when they break
# Don't accumulate broken tests
```

#### After Refactoring

```bash
# 1. Run full test suite
npm test

# 2. Verify pass rate maintained or improved
npm run test:quarantine:status

# 3. If pass rate dropped, identify and fix broken tests
# (or quarantine them systematically per Rule #1)
```

### Pre-Refactoring Checklist

**Use this checklist for EVERY refactoring PR:**

- [ ] Run `npm run test:quarantine:status` - note baseline pass rate
- [ ] Run `npm test` - verify all tests pass
- [ ] Identify tests that will be affected by changes
- [ ] Plan to update tests in same PR as code changes
- [ ] Update tests incrementally as code changes
- [ ] Verify tests pass after each logical change
- [ ] Run full suite before committing
- [ ] Verify pass rate maintained

### What to Do When Tests Break

**If you break tests during refactoring:**

1. **Immediate Fix (Preferred):**
   ```typescript
   // Update test to match new behavior
   it('creates order with proper authentication', async () => {
     const response = await request(app)
       .post('/api/orders')
       .set('Authorization', `Bearer ${adminToken}`) // Updated token
       .send(orderPayload);

     expect(response.status).toBe(201); // Now passes
   });
   ```

2. **Systematic Quarantine (If Fix is Complex):**
   - Follow Rule #1 to quarantine the test
   - Document why it broke and how to fix it
   - Assign appropriate priority
   - Include fix in same PR or create follow-up issue

3. **NEVER Do This:**
   ```typescript
   // ❌ NEVER skip without documenting
   it.skip('creates order', () => { ... });
   ```

---

## Rule #3: Mock Update Requirements

### The Problem We Had

**Example:** WebRTCVoiceClient.test.ts - 11 tests broken

Tests were written against `configureSession()` method that was never implemented. When code used `sessionConfig` property instead, tests failed.

### The Right Way: Keep Mocks in Sync

#### When API Signatures Change

**If you change an interface, update ALL usages:**

```typescript
// ❌ OLD: Method-based API
interface WebRTCVoiceClient {
  configureSession(config: SessionConfig): void;
}

// ✅ NEW: Property-based API
interface WebRTCVoiceClient {
  sessionConfig: SessionConfig;
}
```

**Update checklist:**
1. ✅ Implementation (`WebRTCVoiceClient.ts`)
2. ✅ Type definitions (`types/voice.ts`)
3. ✅ Tests (`__tests__/WebRTCVoiceClient.test.ts`)
4. ✅ Mocks (`__mocks__/WebRTCVoiceClient.ts`)
5. ✅ Integration tests (`orderIntegration.integration.test.tsx`)
6. ✅ Documentation (`docs/voice-ordering.md`)

#### Finding All Test Files That Use a Mock

```bash
# Find all tests importing a module
grep -r "from.*WebRTCVoiceClient" client/src --include="*.test.ts" --include="*.test.tsx"

# Find all tests mocking a method
grep -r "vi.fn()" client/src --include="*.test.ts" --include="*.test.tsx" | grep "configureSession"
```

#### Mock Maintenance Checklist

**When you change an API:**

- [ ] Find all test files that import the module
- [ ] Update mock implementations to match new signature
- [ ] Update test assertions to match new behavior
- [ ] Run tests to verify updates work
- [ ] Check for duplicate mocks (consolidate if possible)

#### Prefer Real Implementations Over Mocks

```typescript
// ❌ FRAGILE: Over-mocked test
describe('OrderService', () => {
  it('creates order', async () => {
    const mockRepo = {
      create: vi.fn().mockResolvedValue({ id: '123' }),
      findById: vi.fn().mockResolvedValue({ id: '123' }),
      update: vi.fn(),
      delete: vi.fn(),
      // ... 10 more mocked methods
    };
    const service = new OrderService(mockRepo);
    const result = await service.createOrder(payload);
    expect(result.id).toBe('123');
  });
});

// ✅ ROBUST: Minimal mocking with real implementation
describe('OrderService', () => {
  let service: OrderService;
  let repo: OrderRepository;

  beforeEach(() => {
    // Use in-memory database or real repository
    repo = new OrderRepository(inMemoryDB);
    service = new OrderService(repo);
  });

  it('creates order', async () => {
    const result = await service.createOrder(payload);
    expect(result.id).toBeDefined();

    // Verify order actually persisted (tests real behavior)
    const saved = await repo.findById(result.id);
    expect(saved).toEqual(expect.objectContaining(payload));
  });
});
```

**Benefits:**
- Tests catch API changes automatically
- No manual mock updates needed
- Tests validate actual behavior

---

## Rule #4: Environment-Aware Testing

### The Problem We Had

**Timeline:** October 5-21, 2025 (16 days CI blocked)

Three issues caused by not considering environment differences:
1. **Env validation:** Expected vars in CI that weren't there
2. **Timing tests:** Too strict for shared CI runners
3. **Dead workflows:** Referenced deleted config files

### The Right Way: Conditional Configuration

#### Issue 1: Environment Variable Validation

**Problem:** Vite build expected env vars that CI doesn't have

```typescript
// ❌ WRONG: Same validation everywhere
if (mode === 'production') {
  const requiredEnvVars = ['VITE_API_BASE_URL', ...];
  const missingVars = requiredEnvVars.filter(varName => !env[varName]);
  if (missingVars.length > 0) {
    throw new Error('Missing required environment variables');
  }
}
```

**Solution:** Conditional validation based on environment

```typescript
// ✅ RIGHT: Environment-aware validation
if (mode === 'production' && !process.env.CI) {
  // Strict validation only for actual deployments (Vercel)
  const requiredEnvVars = ['VITE_API_BASE_URL', 'VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'];
  const missingVars = requiredEnvVars.filter(varName => !env[varName]);
  if (missingVars.length > 0) {
    throw new Error(`Cannot build without required environment variables: ${missingVars.join(', ')}`);
  }
} else if (mode === 'production' && process.env.CI) {
  console.warn('⚠️  CI environment detected - skipping strict env validation');
  console.warn('   Production builds on Vercel will still enforce strict validation');
}
```

#### Issue 2: Timing Test Flakiness

**Problem:** Timing test too strict for variable CI performance

```typescript
// ❌ WRONG: Same threshold everywhere
const maxVariance = avgTime * 0.5; // 50% tolerance
```

**Solution:** Environment-based tolerance

```typescript
// ✅ RIGHT: Higher tolerance in CI
const varianceTolerance = process.env.CI ? 3.0 : 2.0; // 3x for CI, 2x for local
const maxVariance = avgTime * varianceTolerance;
```

#### Environment Detection

```typescript
// Detect CI environment
const isCI = process.env.CI === 'true' ||
             process.env.CI === '1' ||
             !!process.env.CI;

// Use for configuration
const config = {
  timeout: isCI ? 10000 : 5000,      // Longer timeouts in CI
  retries: isCI ? 3 : 1,             // More retries in CI
  workers: isCI ? 2 : 4,             // Fewer workers in CI
  threshold: isCI ? relaxed : strict, // Looser thresholds in CI
};
```

#### Environment-Aware Test Checklist

**When writing tests that might be environment-sensitive:**

- [ ] Does test measure timing? → Use environment-based thresholds
- [ ] Does test require env vars? → Document requirements for each environment
- [ ] Does test use file paths? → Use `path.join(process.cwd(), ...)` not hardcoded paths
- [ ] Does test have network calls? → Increase timeout in CI
- [ ] Does test have race conditions? → Use `waitFor` with generous timeouts

#### When to Use `waitFor` vs `findBy`

```typescript
// ❌ FLAKY: Immediate assertion (no waiting)
it('shows success message', () => {
  render(<Component />);
  expect(screen.getByText('Success')).toBeInTheDocument();
});

// ✅ BETTER: findBy with default timeout (1s)
it('shows success message', async () => {
  render(<Component />);
  await screen.findByText('Success');
});

// ✅ BEST: waitFor with generous timeout (CI-safe)
it('shows success message', async () => {
  render(<Component />);
  await waitFor(() => {
    expect(screen.getByText('Success')).toBeInTheDocument();
  }, { timeout: 5000 }); // 5s timeout for CI
});
```

---

## Rule #5: Memory Leak Prevention

### The Problem We Had

**Discovery:** November 10, 2025

Memory leaks in test infrastructure:
- VoiceWebSocketServer: Cleanup intervals not tracked
- AuthRateLimiter: Hourly cleanup intervals leaking
- Test isolation: Server instances not cleaned up
- Impact: 1-20 MB/day leak, CI OOM errors

### The Right Way: Cleanup Tracking

#### Pattern 1: Track All Intervals

```typescript
// ❌ MEMORY LEAK: Interval not tracked
export class VoiceWebSocketServer {
  constructor() {
    setInterval(() => {
      this.cleanupStaleConnections();
    }, 60000); // Leaks on restart!
  }
}

// ✅ FIXED: Track and clear interval
export class VoiceWebSocketServer {
  private cleanupInterval?: NodeJS.Timeout;

  constructor() {
    this.cleanupInterval = setInterval(() => {
      this.cleanupStaleConnections();
    }, 60000);
  }

  shutdown() {
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = undefined;
    }
  }
}
```

#### Pattern 2: Implement Shutdown Methods

**Every long-lived service MUST have a shutdown method:**

```typescript
interface Shutdownable {
  shutdown(): Promise<void> | void;
}

export class MyService implements Shutdownable {
  private intervals: NodeJS.Timeout[] = [];
  private timeouts: NodeJS.Timeout[] = [];

  startPeriodicTask() {
    const interval = setInterval(() => {
      // Task logic
    }, 60000);
    this.intervals.push(interval);
  }

  async shutdown() {
    // Clear all intervals
    this.intervals.forEach(interval => clearInterval(interval));
    this.intervals = [];

    // Clear all timeouts
    this.timeouts.forEach(timeout => clearTimeout(timeout));
    this.timeouts = [];

    // Close connections, etc.
  }
}
```

#### Pattern 3: Test Cleanup

```typescript
// ❌ MEMORY LEAK: No cleanup
describe('Voice WebSocket', () => {
  let server: VoiceWebSocketServer;

  beforeEach(() => {
    server = new VoiceWebSocketServer(httpServer, config);
  });

  it('handles connections', async () => {
    // Test logic...
  });
  // Server and intervals leak!
});

// ✅ FIXED: Proper cleanup
describe('Voice WebSocket', () => {
  let server: VoiceWebSocketServer;
  let httpServer: Server;

  beforeEach(() => {
    httpServer = createServer();
    server = new VoiceWebSocketServer(httpServer, config);
  });

  afterEach(async () => {
    await server.shutdown();
    await new Promise<void>(resolve => {
      httpServer.close(() => resolve());
    });
  });

  it('handles connections', async () => {
    // Test logic...
  });
});
```

#### Memory Leak Prevention Checklist

**When creating a long-lived service:**

- [ ] Track all `setInterval` calls in class properties
- [ ] Track all `setTimeout` calls in class properties
- [ ] Implement `shutdown()` method
- [ ] Clear all intervals in shutdown
- [ ] Clear all timeouts in shutdown
- [ ] Close all connections in shutdown
- [ ] Call shutdown in tests' `afterEach`
- [ ] Add memory leak prevention tests

**Example memory leak prevention test:**

```typescript
describe('Memory Leak Prevention', () => {
  it('clears cleanup interval on shutdown', async () => {
    const service = new VoiceWebSocketServer(httpServer, config);

    // Verify interval is tracked
    expect(service['cleanupInterval']).toBeDefined();

    await service.shutdown();

    // Verify interval is cleared
    expect(service['cleanupInterval']).toBeUndefined();
  });
});
```

---

## Rule #6: Test Updates in Same PR as Code Changes

### The Problem We Had

**Timeline:** October 30-31, 2025

Refactoring PR changed:
- RBAC permissions
- Auth middleware
- Order flow API
- Component structures

But didn't update tests. Result: 24 broken tests, 3 days blocked.

### The Right Way: Tests in Same PR

#### Refactoring PR Checklist

**Include in EVERY refactoring PR:**

1. **Code Changes Section:**
   - [ ] Implementation updates
   - [ ] Type definition updates
   - [ ] API signature changes
   - [ ] Component structure changes

2. **Test Changes Section:**
   - [ ] Updated test assertions
   - [ ] Updated mock implementations
   - [ ] New tests for new behavior
   - [ ] Removed tests for removed features

3. **Verification:**
   - [ ] All tests pass locally
   - [ ] Pass rate maintained or improved
   - [ ] No new `.skip` files without quarantine tracking

#### Example PR Structure

```markdown
## Refactor: Update RBAC Permissions

### Code Changes
- Updated `authMiddleware.ts` to restrict order creation to admin role
- Updated RBAC policy in `permissions.ts`
- Updated API documentation

### Test Changes
- Updated `orders.auth.test.ts` to use admin token for order creation
- Updated `authMiddleware.test.ts` expectations
- Added test for customer role rejection (403 Forbidden)

### Verification
- ✅ All tests pass locally (377/377)
- ✅ Pass rate: 100% (maintained)
- ✅ No quarantined tests added
```

#### When Tests Can't Be Fixed in Same PR

**If test fix is too complex for same PR:**

1. Quarantine the test systematically (Rule #1)
2. Document in PR description:
   ```markdown
   ### Known Issues
   - Quarantined `voice-005`: 11 tests for WebRTCVoiceClient
   - Reason: configureSession() method not implemented
   - Priority: 2 (HIGH)
   - Follow-up: Issue #123 created
   ```

3. Create follow-up issue with:
   - Link to PR that broke tests
   - Detailed explanation of what needs fixing
   - Specific fix strategy
   - Appropriate priority and assignee

---

## Rule #7: Monitor Test Health Metrics

### The Right Way: Regular Health Checks

#### Before Every Development Session

```bash
# Check current test health
npm run test:quarantine:status

# Output shows:
# Health Score: HEALTHY
# Pass Rate: 85%+
# Passing: 365/377
# Quarantined: 2
```

#### After Every PR Merge

```bash
# Verify pass rate maintained
npm run test:quarantine:status

# If pass rate dropped, investigate immediately
```

#### Weekly Test Health Review

**Review these metrics:**

1. **Pass Rate Trend:**
   - Is it improving, stable, or declining?
   - Target: 95%+

2. **Quarantined Tests:**
   - How many quarantined tests?
   - Are they being fixed or accumulating?
   - Target: <5 quarantined

3. **Module Health:**
   - Which modules have most failures?
   - Are failures concentrated or scattered?

4. **Priority Distribution:**
   - How many Priority 1 (CRITICAL) tests?
   - Are SLAs being met?

### Health Score Thresholds

| Pass Rate | Health Score | Your Action |
|-----------|--------------|-------------|
| **95%+** | HEALTHY ✅ | Continue normal development |
| **85-95%** | DEGRADED ⚠️ | Review quarantined tests, plan fixes |
| **75-85%** | CRITICAL ❌ | Stop new features, fix tests daily |
| **<75%** | EMERGENCY 🚨 | All hands on deck, immediate fix |

---

## Quick Decision Tree

### "A test is failing. What should I do?"

```
Test is failing
├─ Can I fix it immediately? (<30 min)
│  └─ YES → Fix it now, update test in same PR
│
├─ Is it a CI-only failure?
│  ├─ YES → Add environment-based config (Rule #4)
│  │       Update test to handle CI differences
│  │
│  └─ NO → Continue below
│
├─ Is the test outdated? (API/component changed)
│  ├─ YES → Update test to match current implementation
│  │       Include in same PR as code changes (Rule #6)
│  │
│  └─ NO → Continue below
│
├─ Is the mock stale?
│  ├─ YES → Update mock to match current API (Rule #3)
│  │       Find all tests using this mock
│  │       Update all in same PR
│  │
│  └─ NO → Continue below
│
└─ Test fix is complex (>30 min)
   └─ Quarantine systematically (Rule #1)
      1. Document in test-health.json
      2. Rename to .skip
      3. Regenerate dashboard
      4. Commit with detailed message
      5. Create follow-up issue if not in same PR
```

### "I'm refactoring code. How do I handle tests?"

```
Before Refactoring:
├─ 1. Check baseline: npm run test:quarantine:status
├─ 2. Run full suite: npm test
├─ 3. Note any existing failures
└─ 4. Identify tests that will be affected

During Refactoring:
├─ 1. Update tests incrementally with code
├─ 2. Run affected tests frequently
├─ 3. Fix tests immediately when they break
└─ 4. Don't accumulate broken tests

After Refactoring:
├─ 1. Run full suite: npm test
├─ 2. Verify pass rate maintained
├─ 3. Update test documentation if patterns changed
└─ 4. Include test changes in same PR
```

### "I found a .skip file without quarantine tracking. What do I do?"

```
Untracked .skip file found
├─ 1. Investigate when it was skipped
│  └─ git log -- path/to/file.test.ts.skip
│
├─ 2. Find out why it was skipped
│  └─ git show <commit>
│
├─ 3. Try to restore it
│  ├─ Remove .skip extension
│  ├─ Run test
│  └─ Does it pass?
│     ├─ YES → Keep it restored, commit
│     └─ NO → Continue below
│
└─ 4. Quarantine systematically (Rule #1)
   ├─ Document in test-health.json
   ├─ Assign appropriate priority
   ├─ Regenerate dashboard
   └─ Commit with explanation
```

---

## Common Mistakes to Avoid

### ❌ Mistake #1: Skip First, Document Later
```typescript
// Wrong order - never do this
it.skip('handles connections', () => { ... }); // Skip now
// TODO: Document in test-health.json later (never happens)
```

**Instead:** Document FIRST, then skip (Rule #1)

### ❌ Mistake #2: "I'll Fix It Later"
```bash
# Test is failing, PR is urgent, just skip it...
git mv test.ts test.ts.skip
git commit -m "skip failing test"  # No documentation!
# (Never gets fixed)
```

**Instead:** If you can't fix it now, quarantine systematically (Rule #1)

### ❌ Mistake #3: Mocking Everything
```typescript
// Over-mocking makes tests fragile
const mockRepo = {
  create: vi.fn(),
  read: vi.fn(),
  update: vi.fn(),
  delete: vi.fn(),
  // ... 20 more methods
};
```

**Instead:** Use real implementations where possible (Rule #3)

### ❌ Mistake #4: Same Config Everywhere
```typescript
// Fails in CI due to shared resources
const timeout = 1000; // Too short for CI
```

**Instead:** Environment-aware configuration (Rule #4)

### ❌ Mistake #5: No Test Cleanup
```typescript
describe('Server', () => {
  beforeEach(() => {
    server = new Server(); // Creates intervals
  });
  // No afterEach cleanup - memory leak!
});
```

**Instead:** Always clean up in afterEach (Rule #5)

### ❌ Mistake #6: Tests in Separate PR
```markdown
PR #1: Refactor RBAC (breaks 5 tests)
PR #2: Fix tests (maybe never created)
```

**Instead:** Tests in same PR as code changes (Rule #6)

---

## Success Metrics

### You're Doing It Right When:

- ✅ Pass rate is 95%+ and stable
- ✅ Quarantined tests are tracked in test-health.json
- ✅ No `.skip` files without quarantine tracking
- ✅ Tests updated in same PR as code changes
- ✅ Mocks stay in sync with implementations
- ✅ Tests pass in both CI and local environments
- ✅ No memory leaks in test infrastructure
- ✅ Test health dashboard updated regularly

### Red Flags to Watch For:

- 🚩 Pass rate declining over time
- 🚩 Multiple `.skip` files added in short period
- 🚩 Tests skipped without documentation
- 🚩 CI failures that don't reproduce locally
- 🚩 Memory usage growing during test runs
- 🚩 Refactoring PRs without test updates
- 🚩 More than 5 quarantined tests at a time

---

## Commands Reference

```bash
# Check test health before starting work
npm run test:quarantine:status

# Run only healthy tests (CI-safe)
npm run test:healthy

# Run full test suite
npm test

# Run specific test pattern
npm test -- <pattern>

# Generate/update test health dashboard
npm run test:quarantine:dashboard

# System-wide health check
npm run health

# Find untracked .skip files
find . -name "*.test.ts.skip" -o -name "*.test.tsx.skip" | while read file; do
  if ! grep -q "$file" test-quarantine/test-health.json; then
    echo "⚠️  Untracked skip: $file"
  fi
done
```

---

## Summary: Seven Rules for AI Agents

1. **Never use .skip without tracking** - Document in test-health.json first
2. **Check test health before changes** - Run quarantine:status and test suite
3. **Mock update requirements** - Keep mocks in sync with API changes
4. **Environment-aware testing** - Use conditional config for CI vs local
5. **Memory leak prevention** - Track intervals, implement shutdown, clean up in tests
6. **Test updates in same PR** - Don't break tests and leave them for later
7. **Monitor test health metrics** - Regular health checks and dashboard reviews

**Recovery Timeline Reminder:**
- CI blockage: 16 days (Oct 5-21)
- Test crisis: 3 days (Oct 30 - Nov 2)
- Whack-a-mole: 52 commits
- Pass rate drop: 73% → 65% → 85%+

**Never again.** Follow these rules systematically to maintain test health.

---

**Last Updated:** 2025-11-19
**Project:** Restaurant OS rebuild-6.0
**Pass Rate:** 85%+ (365+ passing tests)
**Health Score:** HEALTHY ✅

---
category: "testing-quality"
category_id: "06"
version: "3.0.0"
last_updated: "2025-11-19"
document_type: "INCIDENTS"
incident_count: 2
total_cost: 10000
severity_distribution:
  P1: 2
tags: [quarantine, test-health, flaky-tests, coverage]
---
# Major Testing Incidents

**Last Updated:** 2025-11-19

## Overview

This document provides detailed incident reports for three major testing crises that affected the Restaurant OS rebuild-6.0 project between October and November 2025.

---

## Incident #1: CI Infrastructure Failures

**Status:** ✅ RESOLVED
**Duration:** 16 days (October 5-21, 2025)
**Severity:** P0 (Critical - All PRs Blocked)

### Timeline

| Date | Event |
|------|-------|
| **Oct 5, 2025** | Strict env validation added to `client/vite.config.ts` (commit 0a90587) |
| **Oct 5-21** | All PRs fail smoke-test in GitHub Actions (16 days) |
| **Oct 21** | Root cause identified: env vars expected but not provided in CI |
| **Oct 21** | Three infrastructure fixes implemented (commit 14477f82) |
| **Oct 21** | CI unblocked, PRs can merge again |

### Symptoms

**1. Smoke Test Env Var Validation Failure:**
```
smoke-test  Build production bundle  ❌ Missing required environment variables
   - VITE_API_BASE_URL
   - VITE_SUPABASE_URL
   - VITE_SUPABASE_ANON_KEY
```

**2. Dead Smoke Test Workflow:**
```
Error: /home/runner/work/July25/July25/client/playwright-smoke.config.ts does not exist
```

**3. Webhook Timing Test Flakiness:**
```
FAIL  tests/security/webhook.proof.test.ts > Timing Attack Prevention
  → expected 6654900.666666667 to be less than 3390273.6666666665
```

### Root Cause Analysis

#### Issue 1A: Environment Variable Validation Mismatch

**The Code:**
```typescript
// client/vite.config.ts (commit 0a90587, Oct 5)
if (mode === 'production') {
  const requiredEnvVars = ['VITE_API_BASE_URL', 'VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'];
  const missingVars = requiredEnvVars.filter(varName => !env[varName]);
  if (missingVars.length > 0) {
    throw new Error('Cannot build without required environment variables');
  }
}
```

**Three Build Contexts:**
1. **Local Dev:** Reads from `.env` file (not committed) → ✅ Works
2. **Vercel Deployment:** Reads from Vercel project settings → ✅ Works
3. **GitHub Actions CI:** No env vars configured → ❌ FAILS

**Why This is a Repeating Problem:**
- Variables exist in Vercel (have been there for months)
- Actual deployments work fine
- But smoke-test in `.github/workflows/playwright-smoke.yml` runs `npm run build` in GitHub Actions
- GitHub Actions doesn't have access to Vercel's environment variables
- Needs separate GitHub Secrets configuration OR conditional validation

**Design Flaw:** Validation added for deployment safety (Vercel) but also runs in CI testing (GitHub Actions) without considering environment differences.

#### Issue 1B: Dead Smoke Test Workflow

**The History:**
- **Commit 53dfbf4:** Playwright smoke tests added with `client/playwright-smoke.config.ts`
- **Commit ea89695:** Smoke tests moved to `tests/e2e/`, config file deleted
- **Oct 21, 2025:** Workflow still references deleted files

**Orphaned Workflow:** `.github/workflows/playwright-smoke.yml` references:
- `client/playwright-smoke.config.ts` (deleted)
- `client/smoke-tests/` directory (moved)

Tests were refactored but the workflow was never updated or removed.

#### Issue 1C: Webhook Timing Test Flakiness

**Test Purpose:** Verify HMAC signature comparison uses constant-time algorithm to prevent timing attacks.

**Test Implementation:**
```typescript
// server/tests/security/webhook.proof.test.ts (before fix)
const avgTime = timings.reduce((a, b) => a + b) / timings.length;
const maxVariance = avgTime * 0.5; // 50% tolerance (2x)

for (const timing of timings) {
  const variance = Math.abs(timing - avgTime);
  expect(variance).toBeLessThan(maxVariance); // FAILS in CI
}
```

**Why It Fails in CI:**
- GitHub Actions runners are shared and have variable performance
- CI runners experience CPU contention, disk I/O delays
- Timing tests need higher tolerance in shared environments
- The ACTUAL code uses `crypto.timingSafeEqual()` correctly (secure ✓)

**False Positive:** Test failure doesn't indicate security vulnerability, just environment variance.

### Solutions Implemented

#### Fix 1A: Conditional Environment Validation

```typescript
// client/vite.config.ts (commit 14477f82, Oct 21)
if (mode === 'production' && !process.env.CI) {
  // Strict validation only for actual deployments (Vercel)
  const requiredEnvVars = ['VITE_API_BASE_URL', 'VITE_SUPABASE_URL', 'VITE_SUPABASE_ANON_KEY'];
  const missingVars = requiredEnvVars.filter(varName => !env[varName]);
  if (missingVars.length > 0) {
    throw new Error('Cannot build without required environment variables');
  }
} else if (mode === 'production' && process.env.CI) {
  console.warn('⚠️  CI environment detected - skipping strict env validation');
  console.warn('   Production builds on Vercel will still enforce strict validation');
}
```

**Benefits:**
- ✅ CI smoke-test can build without env vars
- ✅ Vercel still enforces strict validation
- ✅ No duplication of secrets across platforms
- ✅ Clean, surgical fix

#### Fix 1B: Remove Dead Workflow

```bash
git rm .github/workflows/playwright-smoke.yml
```

**Rationale:**
- Config and tests don't exist
- E2E tests not currently run in CI
- Workflow has been broken since commit ea89695
- Blocks CI fixes from merging

**Future Work:** If smoke/e2e tests are needed, create new workflow that references correct paths.

#### Fix 1C: Environment-Based Timing Tolerance

```typescript
// server/tests/security/webhook.proof.test.ts (commit 14477f82, Oct 21)
const avgTime = timings.reduce((a, b) => a + b) / timings.length;
const varianceTolerance = process.env.CI ? 3.0 : 2.0; // 3x for CI, 2x for local
const maxVariance = avgTime * varianceTolerance;

for (const timing of timings) {
  const variance = Math.abs(timing - avgTime);
  expect(variance).toBeLessThan(maxVariance);
}
```

**Benefits:**
- ✅ CI tests pass with realistic tolerance
- ✅ Local dev still has strict validation
- ✅ Security remains intact (`crypto.timingSafeEqual` is constant-time)
- ✅ Test design improved for CI environments

### Impact Assessment

**Business Impact:**
- 16 days of blocked merges
- All PRs failed regardless of changes
- Development velocity significantly reduced
- Features delayed waiting for infrastructure fixes

**Technical Impact:**
- Unknown test pass rate during period (tests couldn't run)
- Accumulating technical debt (PRs waiting)
- Developer frustration (infrastructure blocking work)
- Lost confidence in CI/CD pipeline

**Developer Experience:**
- "Is my PR actually broken or is it just CI?"
- "Should we pave over this debt?" (considered bypassing CI)
- "How long will this block us?"
- Workarounds attempted but failed

### Post-Mortem

**What Went Well:**
- Root cause identified systematically
- Surgical fixes that addressed core issues
- Documentation created for future reference
- Avoided "pave over debt" temptation

**What Went Wrong:**
- Env validation added without considering CI context
- Workflow not updated when tests were refactored
- Timing test tolerance too strict for shared runners
- 16 days is too long to identify and fix infrastructure issues

**Action Items:**
1. ✅ Always consider multiple build contexts when adding validation
2. ✅ Use `process.env.CI` to detect CI environments
3. ✅ Delete workflows when tests/configs are moved
4. ✅ Use environment-based thresholds for timing tests
5. ✅ Document environment requirements in code comments
6. ✅ Set SLA: infrastructure issues P0, fix within 24 hours

### Related Files

- `client/vite.config.ts` - Conditional env validation
- `server/tests/security/webhook.proof.test.ts` - CI timing tolerance
- `.github/workflows/playwright-smoke.yml` - REMOVED
- `docs/CI_INFRASTRUCTURE_ISSUES.md` - Full documentation

### Related Commits

- `0a90587` (Oct 5) - Added strict env validation (introduced issue)
- `14477f82` (Oct 21) - Fixed CI infrastructure failures (resolved issue)

---

## Incident #2: Test Quarantine Crisis

**Status:** ✅ RESOLVED
**Duration:** 3 days (October 30 - November 2, 2025)
**Severity:** P1 (High - Development Blocked)

### Timeline

| Date | Event |
|------|-------|
| **Oct 28-30** | Baseline: ~73% pass rate, scattered test failures |
| **Oct 30-31** | Refactoring breaks 24 tests (RBAC, auth, order flow) |
| **Oct 30 - Nov 2** | Whack-a-mole test skipping (52 commits over 3 days) |
| **Nov 2** | Crisis point: 65% pass rate, PR #132 blocked |
| **Nov 2** | Systematic quarantine system implemented (commit 31217345) |
| **Nov 2** | Pass rate jumps to 87.3% (with 24 tests quarantined) |
| **Nov 3-7** | Phased recovery: 87.3% → 97.6% |
| **Nov 10** | Memory leak fixes: 97.6% → 99.8% |

### Symptoms

**Developer Experience:**
```bash
# Every test run reveals more failures:
$ npm test
❌ FAIL auth-context-timeout.test.tsx
❌ FAIL voice-integration.test.tsx
❌ FAIL order-payload-schema.test.ts
❌ FAIL checkout-simple.test.tsx
❌ ... (20 more)

# No visibility into:
- Total number of failures
- Priority of failures
- Root causes
- Recovery plan
```

**Commit Pattern (52 commits in 3 days):**
```bash
bd0dfc8d test: skip auth context timeout and voice integration test
4864d373 test: skip two more pre-existing test failures
3971da97 test: skip two more pre-existing test failures
a2722c2b test: skip failing order payload schema validation
0e326ca0 test: rename failing auth test files to .skip
d425316a test: skip failing order payload schema validation
349068fb test: rename hold to record button test file to skip
beb60fba test: quarantine recording indicator test (missing component file)
... (44 more similar commits)
```

**Pass Rate Decline:**
```
Oct 28: ~73% pass rate (baseline)
Oct 30: ~70% pass rate (refactoring breaks tests)
Oct 31: ~67% pass rate (cascading failures)
Nov 1:  ~66% pass rate (more failures discovered)
Nov 2:  65% pass rate (CRISIS POINT)
```

### Root Cause Analysis

**Trigger Event:** October 30-31 refactoring without test updates

**Changes Made:**
1. **RBAC Updates:** Role-Based Access Control permissions changed
   - `orders.auth.test.ts` expects 201 Created, gets 403 Forbidden
   - Customer/server roles no longer allowed to create orders directly

2. **Authentication Middleware Refactoring:**
   - `auth-restaurant-id.test.ts` spy assertions fail
   - Middleware implementation changed, expectations outdated

3. **Order Flow API Changes:**
   - `order.contract.test.ts` schema validation fails
   - ADR-001 snake_case enforcement broke camelCase tests

4. **Component Structure Updates:**
   - `checkout-simple.test.tsx` selectors fail
   - `CheckoutPage` structure changed since tests written

**What Wasn't Done:** Test updates

**Why Whack-a-Mole Failed:**
1. **No Visibility:** Can't answer "what's broken?" or "how broken are we?"
2. **No Prioritization:** Don't know which tests are critical vs nice-to-have
3. **No Recovery Plan:** No roadmap to fix tests, just accumulating debt
4. **Scattered Changes:** 52 commits across different files, no central tracking
5. **Cascading Failures:** Each skip reveals another failing test
6. **Lost Context:** Why did we skip this? What needs to be fixed?

**Breaking Point:** November 2, 2025
- PR #132 (documentation update) blocked by test failures
- 24 tests quarantined (scattered, untracked)
- 65% pass rate (crisis threshold)
- 3 days of blocked development
- No clear path to recovery

### Quarantined Tests Breakdown

#### Priority 1: CRITICAL (1 test)

| ID | File | Reason | Fix Strategy |
|----|------|--------|--------------|
| auth-005 | `server/tests/routes/orders.auth.test.ts` | 403 Forbidden instead of 201 Created | Review RBAC changes from Oct 30-31 |

#### Priority 2: HIGH (7 tests)

| ID | File | Reason | Fix Strategy |
|----|------|--------|--------------|
| auth-003 | `server/tests/middleware/auth-restaurant-id.test.ts.skip` | Spy assertion failure | Review middleware implementation changes |
| voice-001 | `client/src/modules/voice/services/__tests__/WebRTCVoiceClient.test.ts.skip` | Method configureSession() does not exist | Implement method or rewrite tests |
| voice-002 | `client/src/modules/voice/services/orderIntegration.integration.test.tsx.skip` | useAuth must be used within AuthProvider | Add AuthProvider wrapper |
| orders-001 | `client/src/modules/order-system/__tests__/checkout-simple.test.tsx` | Unable to find element with text /checkout/i | Update selectors to match current structure |
| orders-002 | `client/src/pages/__tests__/CheckoutPage.demo.test.tsx` | mockNavigate never called | Fix navigation mocking setup |
| orders-004 | `client/src/modules/order-system/__tests__/checkout.e2e.test.tsx` | Unable to find element with text: Checkout | Update E2E test to match current structure |
| orders-005 | `server/tests/contracts/order.contract.test.ts` | OrderPayload schema doesn't accept snake_case | Align Zod schema with ADR-001 |

#### Priority 3: MEDIUM (4 tests)

| ID | File | Reason | Fix Strategy |
|----|------|--------|--------------|
| auth-004 | `client/src/pages/__tests__/WorkspaceDashboard.test.tsx` | Spy not called on Enter key press | Fix keyboard event handling |
| voice-003 | `client/src/modules/voice/components/HoldToRecordButton.test.tsx.skip` | Multiple text assertion failures | Update text assertions to match current state |
| voice-004 | `client/src/modules/voice/components/RecordingIndicator.test.tsx` | CI-specific failure | Investigate CI vs local differences |
| orders-003 | `client/src/pages/__tests__/CheckoutPage.demo.test.tsx` | Found multiple elements with /required/i | Use more specific selectors |

#### Module Health

| Module | Total Tests | Passing | Quarantined | Pass Rate | Health |
|--------|-------------|---------|-------------|-----------|--------|
| **Auth** | 120 | 111 | 9 | 92.5% | ⚠️ DEGRADED |
| **Voice** | 95 | 71 | 24 | 74.7% | ❌ CRITICAL |
| **Orders** | 87 | 81 | 6 | 93.1% | ⚠️ DEGRADED |
| **Shared** | 75 | 66 | 0 | 88.0% | ✅ HEALTHY |
| **TOTAL** | 377 | 329 | 24 | 87.3% | ⚠️ DEGRADED |

### Solution: Systematic Quarantine System

**Implementation Date:** November 2, 2025 (Commit 31217345)

**Infrastructure Created:**
1. **Central Registry:** `test-quarantine/test-health.json`
   - Version tracking
   - Summary metrics (pass rate, health score)
   - Detailed quarantine list with metadata
   - Module-level health tracking
   - Prioritized remediation plan

2. **Management Script:** `scripts/test-quarantine.js`
   - `--dashboard`: Generate auto-updated TEST_HEALTH.md
   - `--status`: Show current health metrics
   - `--run-healthy`: Run only non-quarantined tests

3. **Auto-Generated Dashboard:** `TEST_HEALTH.md`
   - Visual health indicators (✅ ⚠️ ❌)
   - Quick stats table
   - Module health breakdown
   - Priority-grouped quarantine list
   - Remediation plan with target dates

4. **Consistent Naming:** `.skip` file extension
   - Clear quarantine markers
   - Git-trackable changes
   - Vitest automatically excludes

**New Commands:**
```bash
npm run test:healthy              # Run only passing tests (CI-safe)
npm run test:quarantine:status    # Show health metrics
npm run test:quarantine:dashboard # Regenerate dashboard
npm run health                    # System-wide health check
```

**CI Integration:**
```yaml
# .github/workflows/quick-tests.yml (updated Nov 2)
- name: Run healthy tests
  run: npm run test:healthy  # Changed from test:quick
```

### Phased Recovery

#### Phase 1: Critical Auth Fixes (Target: Nov 3)
**Goal:** Fix Priority 1 tests blocking production

**Tests Fixed:**
- `auth-001`: Auth context provider tests
- `auth-002`: Restaurant ID middleware tests
- `auth-005`: Orders auth tests (403 → 201)

**Result:** 87.3% → 90.1% pass rate (+2.8%)
**Status:** ✅ COMPLETED Nov 3

#### Phase 2: Order Flow Restoration (Target: Nov 5)
**Goal:** Fix Priority 2 order flow tests affecting revenue

**Tests Fixed:**
- `orders-001`: checkout-simple.test.tsx (selector updates)
- `orders-002`: CheckoutPage.demo.test.tsx (navigation mocking)
- `orders-003`: CheckoutPage.demo.test.tsx (specific selectors)
- `orders-004`: checkout.e2e.test.tsx (E2E structure updates)
- `orders-005`: order.contract.test.ts (snake_case schema alignment)

**Result:** 90.1% → 95.2% pass rate (+5.1%)
**Status:** ✅ COMPLETED Nov 5

#### Phase 3: Voice Integration (Target: Nov 7)
**Goal:** Fix Priority 3 voice integration tests

**Tests In Progress:**
- `voice-001`: WebRTCVoiceClient.test.ts (configureSession API)
- `voice-002`: orderIntegration.integration.test.tsx (AuthProvider wrapper)
- `voice-003`: HoldToRecordButton.test.tsx (text assertions)
- `voice-004`: RecordingIndicator.test.tsx (CI environment handling)

**Result:** 95.2% → 97.6% pass rate (+2.4%)
**Status:** ⏳ IN PROGRESS (2 tests remaining as of Nov 19)

### Impact Assessment

**Before Quarantine System:**
- 52 commits over 3 days (whack-a-mole)
- 65% pass rate (crisis point)
- No visibility into test health
- No recovery plan
- Development blocked

**After Quarantine System:**
- Single source of truth (test-health.json)
- 87.3% pass rate immediately (with tracking)
- Clear visibility and priorities
- Phased recovery plan
- CI unblocked (test:healthy)
- Pass rate improved to 97.6% in 5 days

**Recovery Metrics:**

| Metric | Nov 2 (Before) | Nov 2 (After) | Nov 7 (Phase 3) | Nov 19 (Current) |
|--------|----------------|---------------|-----------------|------------------|
| **Pass Rate** | 65% | 87.3% | 97.6% | 85%+ |
| **Passing Tests** | 245 | 329 | 368 | 365+ |
| **Quarantined** | 24 (untracked) | 24 (tracked) | 9 (tracked) | 2 (tracked) |
| **Health Score** | CRITICAL | DEGRADED | HEALTHY | HEALTHY |

### Post-Mortem

**What Went Well:**
- Recognized whack-a-mole pattern early
- Stopped to implement systematic solution
- Phased recovery with clear priorities
- Infrastructure reusable for future issues

**What Went Wrong:**
- Oct 30-31 refactoring didn't include test updates
- No pre-commit hook to catch test breakage
- No CI gate for pass rate threshold
- 3 days of whack-a-mole before systematic solution

**Action Items:**
1. ✅ Test update checklist for refactoring PRs
2. ✅ Pre-commit hook for test-affecting changes
3. ✅ CI gate for test pass rate (<85% fails build)
4. ✅ Test review as part of code review
5. ✅ Weekly test health review
6. ⏳ Achieve 95%+ pass rate (current: 85%+)

### Related Files

- `test-quarantine/test-health.json` - Central registry
- `scripts/test-quarantine.js` - Management script
- `TEST_HEALTH.md` - Auto-generated dashboard (moved to `docs/reference/testing/TEST_HEALTH.md`)
- `.github/workflows/quick-tests.yml` - CI integration

### Related Commits

- `31217345` (Nov 2) - Systematic quarantine implementation
- `21f8a445` (Nov 3) - Phase 1: Critical auth fixes
- `b4280140` (Nov 5) - Phase 2: Order flow restoration
- `d54de1a1` (Nov 7) - Remove quarantine markers for restored tests

---

## Incident #3: Memory Leaks in Test Infrastructure

**Status:** ✅ RESOLVED
**Duration:** Unknown onset - November 10, 2025 (detection and resolution)
**Severity:** P2 (Medium - CI Instability, Not Blocking)

### Timeline

| Date | Event |
|------|-------|
| **Unknown** | Memory leaks accumulating in test infrastructure |
| **Oct-Nov** | Occasional CI instability (OOM errors) |
| **Nov 10** | Memory leaks discovered during stabilization initiative |
| **Nov 10** | Root causes identified (VoiceWebSocketServer, AuthRateLimiter) |
| **Nov 10** | Fixes implemented with 16 new tests (commit 9c7b548d) |
| **Nov 10** | Memory leak reduction: 90-95% (1-20 MB/day → <1 MB/day) |

### Symptoms

**CI Environment:**
- Occasional Out-Of-Memory (OOM) errors
- Test suite performance degradation over time
- Node process memory usage growing over test runs
- Flaky test timeouts in long-running suites

**Local Development:**
- Memory usage growing during `npm run test:watch`
- Node process consuming more RAM over time
- Dev server restart required after extensive testing

**Metrics:**
- Memory leak rate: 1-20 MB/day
- Peak memory usage: 3GB+ in long test runs
- CI runner OOM: ~2-3 times per week

### Root Cause Analysis

#### Issue 3A: VoiceWebSocketServer Cleanup Intervals

**The Code:**
```typescript
// server/src/voice/websocket-server.ts (before fix)
export class VoiceWebSocketServer {
  constructor(server: Server, config: VoiceConfig) {
    this.server = server;
    this.config = config;
    this.setupWebSocketServer();
    this.startCleanupInterval(); // ❌ Interval created but never tracked
  }

  private startCleanupInterval() {
    setInterval(() => {
      this.cleanupStaleConnections();
    }, 60000); // Runs every minute, NEVER CLEARED
  }
}
```

**The Problem:**
1. Cleanup interval created in constructor
2. Interval reference not stored
3. No shutdown method to clear interval
4. On server restart (common in tests), old intervals persist
5. Multiple intervals accumulate over test runs

**Impact:**
- Each test creates new VoiceWebSocketServer instance
- Each instance creates new cleanup interval
- Old intervals never cleared
- 60s intervals × N tests = N timers running forever

#### Issue 3B: AuthRateLimiter Cleanup Intervals

**The Code:**
```typescript
// server/src/middleware/authRateLimiter.ts (before fix)
export class AuthRateLimiter {
  private attempts: Map<string, RateLimitAttempt[]> = new Map();

  constructor() {
    this.startCleanupInterval(); // ❌ Hourly cleanup never cleared
  }

  private startCleanupInterval() {
    setInterval(() => {
      this.pruneExpiredAttempts();
    }, 3600000); // Hourly cleanup, NEVER CLEARED
  }
}
```

**The Problem:**
1. Hourly cleanup interval created on instantiation
2. Interval reference not stored
3. No shutdown method
4. Rate limiter recreated on server restart
5. Old intervals persist and leak

**Impact:**
- Tests restart server frequently for isolation
- Each restart creates new AuthRateLimiter
- Old hourly intervals continue running
- Memory leak: N intervals × 3600s = significant leak

#### Issue 3C: Test Isolation

**The Pattern:**
```typescript
// ❌ MEMORY LEAK: No cleanup in tests
describe('Voice WebSocket', () => {
  let server: VoiceWebSocketServer;

  beforeEach(() => {
    server = new VoiceWebSocketServer(httpServer, config);
  });

  it('handles connections', async () => {
    // Test logic...
  });

  // No afterEach cleanup!
  // Server instance and intervals leak
});
```

**The Problem:**
1. Tests create server instances
2. Server instances create cleanup intervals
3. Tests don't clean up after themselves
4. Intervals persist after test completes
5. Memory leaks accumulate across test suite

### Solutions Implemented

#### Fix 3A: VoiceWebSocketServer Cleanup Tracking

```typescript
// server/src/voice/websocket-server.ts (after fix)
export class VoiceWebSocketServer {
  private cleanupInterval?: NodeJS.Timeout; // ✅ Track interval

  constructor(server: Server, config: VoiceConfig) {
    this.server = server;
    this.config = config;
    this.setupWebSocketServer();
    this.startCleanupInterval();
  }

  private startCleanupInterval() {
    this.cleanupInterval = setInterval(() => { // ✅ Store reference
      this.cleanupStaleConnections();
    }, 60000);
  }

  shutdown() { // ✅ Cleanup method
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = undefined;
    }
    // Close WebSocket connections
    this.wss.close();
  }
}
```

#### Fix 3B: AuthRateLimiter Cleanup Tracking

```typescript
// server/src/middleware/authRateLimiter.ts (after fix)
export class AuthRateLimiter {
  private attempts: Map<string, RateLimitAttempt[]> = new Map();
  private cleanupInterval?: NodeJS.Timeout; // ✅ Track interval

  constructor() {
    this.startCleanupInterval();
  }

  private startCleanupInterval() {
    this.cleanupInterval = setInterval(() => { // ✅ Store reference
      this.pruneExpiredAttempts();
    }, 3600000);
  }

  shutdown() { // ✅ Cleanup method
    if (this.cleanupInterval) {
      clearInterval(this.cleanupInterval);
      this.cleanupInterval = undefined;
    }
    this.attempts.clear();
  }
}
```

#### Fix 3C: Graceful Shutdown Integration

```typescript
// server/src/server.ts (after fix)
export async function gracefulShutdown(
  server: Server,
  voiceServer?: VoiceWebSocketServer,
  rateLimiter?: AuthRateLimiter
) {
  logger.info('Starting graceful shutdown...');

  // Close voice WebSocket server
  if (voiceServer) {
    await voiceServer.shutdown(); // ✅ Clear intervals
  }

  // Cleanup rate limiter
  if (rateLimiter) {
    await rateLimiter.shutdown(); // ✅ Clear intervals
  }

  // Close HTTP server
  await new Promise<void>((resolve) => {
    server.close(() => {
      logger.info('HTTP server closed');
      resolve();
    });
  });
}
```

#### Fix 3D: Test Cleanup

```typescript
// ✅ PROPER CLEANUP: Tests clean up after themselves
describe('Voice WebSocket', () => {
  let server: VoiceWebSocketServer;
  let httpServer: Server;

  beforeEach(() => {
    httpServer = createServer();
    server = new VoiceWebSocketServer(httpServer, config);
  });

  afterEach(async () => { // ✅ Cleanup after each test
    await server.shutdown();
    await new Promise<void>(resolve => httpServer.close(() => resolve()));
  });

  it('handles connections', async () => {
    // Test logic...
  });
});
```

#### Fix 3E: Memory Leak Prevention Tests

**Added:** `server/tests/memory-leak-prevention.test.ts` (16 tests)

```typescript
describe('Memory Leak Prevention', () => {
  describe('VoiceWebSocketServer', () => {
    it('tracks cleanup interval', () => {
      const server = new VoiceWebSocketServer(httpServer, config);
      expect(server['cleanupInterval']).toBeDefined();
    });

    it('clears cleanup interval on shutdown', async () => {
      const server = new VoiceWebSocketServer(httpServer, config);
      await server.shutdown();
      expect(server['cleanupInterval']).toBeUndefined();
    });

    it('closes WebSocket connections on shutdown', async () => {
      const server = new VoiceWebSocketServer(httpServer, config);
      const closeSpy = vi.spyOn(server['wss'], 'close');
      await server.shutdown();
      expect(closeSpy).toHaveBeenCalled();
    });
  });

  describe('AuthRateLimiter', () => {
    it('tracks cleanup interval', () => {
      const limiter = new AuthRateLimiter();
      expect(limiter['cleanupInterval']).toBeDefined();
    });

    it('clears cleanup interval on shutdown', async () => {
      const limiter = new AuthRateLimiter();
      await limiter.shutdown();
      expect(limiter['cleanupInterval']).toBeUndefined();
    });

    it('clears attempts map on shutdown', async () => {
      const limiter = new AuthRateLimiter();
      limiter.recordAttempt('192.168.1.1');
      await limiter.shutdown();
      expect(limiter['attempts'].size).toBe(0);
    });
  });

  describe('Graceful Shutdown', () => {
    it('calls shutdown on all components', async () => {
      const voiceServerShutdown = vi.fn();
      const rateLimiterShutdown = vi.fn();

      await gracefulShutdown(
        httpServer,
        { shutdown: voiceServerShutdown } as any,
        { shutdown: rateLimiterShutdown } as any
      );

      expect(voiceServerShutdown).toHaveBeenCalled();
      expect(rateLimiterShutdown).toHaveBeenCalled();
    });

    it('increases timeout from 3s to 5s for complete cleanup', async () => {
      const start = Date.now();
      // Simulate slow cleanup
      await gracefulShutdown(httpServer);
      const duration = Date.now() - start;
      expect(duration).toBeLessThan(5000); // Should complete within 5s
    });
  });
});
```

### Results

| Metric | Before | After | Improvement |
|--------|--------|-------|-------------|
| **Memory Leak Rate** | 1-20 MB/day | <1 MB/day | 95% reduction |
| **Peak Memory Usage** | 3GB+ | 1.5GB | 50% reduction |
| **CI OOM Errors** | 2-3/week | 0 | 100% elimination |
| **Test Pass Rate** | 97.6% | 99.8% | +2.2% |
| **Leak Prevention Tests** | 0 | 16 | New coverage |
| **Shutdown Timeout** | 3s | 5s | +67% (safer cleanup) |

### Impact Assessment

**Before Fixes:**
- Memory leaking 1-20 MB/day
- CI instability (OOM errors)
- Long-running test suites consuming 3GB+
- Developer workaround: restart dev server

**After Fixes:**
- Memory leak <1 MB/day (95% reduction)
- Zero CI OOM errors
- Test suite memory stable at ~1.5GB
- No manual restarts required
- Pass rate increased from 97.6% to 99.8%

### Post-Mortem

**What Went Well:**
- Discovered during proactive stabilization initiative
- Comprehensive fix covering all leak sources
- Added 16 tests to prevent regressions
- Documented analysis in P0_MEMORY_LEAK_ANALYSIS.md

**What Went Wrong:**
- Memory leaks undetected for extended period
- No memory monitoring in CI
- No cleanup tests for infrastructure code
- Assumption that test infrastructure "just works"

**Action Items:**
1. ✅ Add memory leak prevention tests for all infrastructure
2. ✅ Implement shutdown methods for all long-lived services
3. ✅ Track all intervals and timers
4. ✅ Cleanup in test afterEach hooks
5. ⏳ Add memory monitoring to CI (alert on >2GB usage)
6. ⏳ Regular memory profiling of test suite
7. ⏳ Document cleanup patterns for new services

### Related Files

- `server/src/voice/websocket-server.ts` - VoiceWebSocketServer cleanup
- `server/src/middleware/authRateLimiter.ts` - AuthRateLimiter cleanup
- `server/src/server.ts` - Graceful shutdown integration
- `server/tests/memory-leak-prevention.test.ts` - Prevention tests (16 tests)
- `docs/investigations/P0_MEMORY_LEAK_ANALYSIS.md` - Technical analysis
- `docs/investigations/P0.8_MEMORY_LEAK_COMPLETION_SUMMARY.md` - Executive summary

### Related Commits

- `9c7b548d` (Nov 10) - Memory leak resolution with 16 prevention tests

---

## Summary: Incident Comparison

| Incident | Duration | Severity | Impact | Tests Affected | Resolution Time |
|----------|----------|----------|--------|----------------|-----------------|
| **CI Infrastructure** | 16 days | P0 | All PRs blocked | Unknown (tests couldn't run) | 1 day (after identification) |
| **Test Quarantine** | 3 days | P1 | Development blocked | 24 tests (6% of suite) | 8 days (full recovery) |
| **Memory Leaks** | Unknown | P2 | CI instability | N/A (infrastructure issue) | 1 day (detection to fix) |

### Key Learnings

1. **Infrastructure issues cascade:** CI failures block visibility into test health
2. **Systematic approaches scale:** Whack-a-mole doesn't work, tracking does
3. **Test updates must accompany refactoring:** Code changes break tests, update them
4. **Test infrastructure needs testing:** Memory leaks in test code are just as bad
5. **Environment awareness is critical:** CI and local environments differ significantly

---

**Total Impact:** 19+ days of reduced development velocity, 24 tests broken, significant memory leaks resolved through systematic identification, tracking, and phased remediation.
